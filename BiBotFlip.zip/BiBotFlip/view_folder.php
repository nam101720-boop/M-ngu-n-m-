<?php 
// 1. Kích hoạt Session để lấy thông tin tài khoản đang thao tác
session_start();
include 'config/db.php'; 

// Kiểm tra bảo mật: Nếu chưa đăng nhập thì chặn lại đẩy về trang login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Đồng bộ thông tin người dùng thực tế
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$is_admin = ($user_role === 'admin');

// 1. Lấy ID của bộ thẻ từ URL
$folder_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 2. Truy vấn thông tin bộ thẻ
$folder_sql = "SELECT * FROM folders WHERE id = $folder_id";
$folder_res = $conn->query($folder_sql);
$folder = $folder_res->fetch_assoc();

if (!$folder) {
    die("<div style='text-align:center; padding:50px; font-family:sans-serif;'><h2>Bộ thẻ không tồn tại!</h2><a href='index.php'>Quay lại trang chủ</a></div>");
}

// THUẬT TOÁN KIỂM TRA QUYỀN CHỈNH SỬA THƯ MỤC
// Quyền thêm/sửa được mở nếu: Người đăng nhập là ADMIN HOẶC thư mục này do chính SINH VIÊN này tạo ra (trùng user_id)
$can_edit_folder = ($is_admin || $folder['user_id'] == $user_id);

// 3. Xử lý logic: Nếu chưa có bài học nào, tự động thêm một số bài học hệ thống mẫu (Chỉ chạy khi folder trống)
$check_lesson = $conn->query("SELECT id FROM lessons WHERE folder_id = $folder_id");
if ($check_lesson->num_rows == 0) {
    $folder_name = $folder['name'];
    $conn->query("INSERT INTO lessons (folder_id, name, type) VALUES 
        ($folder_id, 'Bài 1: Từ vựng cốt lõi về $folder_name', 'system'),
        ($folder_id, 'Bài 2: Cụm từ và cấu trúc thông dụng', 'system'),
        ($folder_id, 'Bài 3: Từ vựng nâng cao', 'system')");
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($folder['name']); ?> - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-title: #1e293b;
            --text-body: #64748b;
            --border: #f1f5f9;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
        }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: var(--bg); 
            margin: 0; padding: 40px 20px;
            color: var(--text-title);
        }

        .container { max-width: 900px; margin: auto; }

        /* Header */
        .header { margin-bottom: 40px; position: relative; }
        .btn-back { 
            text-decoration: none; color: var(--text-body); 
            font-weight: 600; display: inline-flex; align-items: center; gap: 8px;
            margin-bottom: 20px; transition: 0.3s;
        }
        .btn-back:hover { color: var(--primary); transform: translateX(-5px); }
        h1 { font-size: 32px; font-weight: 800; margin: 0; color: var(--text-title); }
        .description { color: var(--text-body); margin-top: 10px; font-size: 16px; border-left: 4px solid var(--primary); padding-left: 15px; }

        /* Nút tạo bài học mới */
        .btn-create-lesson {
            position: absolute; right: 0; top: 50px;
            background: var(--primary); color: white; text-decoration: none;
            padding: 12px 20px; border-radius: 12px; font-weight: 700;
            display: flex; align-items: center; gap: 8px; transition: 0.3s;
        }
        .btn-create-lesson:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(99, 102, 241, 0.2); }

        /* Lesson Card */
        .lesson-list { display: flex; flex-direction: column; gap: 20px; margin-top: 30px; }
        
        .lesson-card {
            background: var(--white);
            border-radius: 24px;
            padding: 25px;
            border: 1px solid var(--border);
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
            transition: 0.3s;
        }
        .lesson-card:hover { transform: translateY(-5px); box-shadow: 0 20px 25px -5px rgba(0,0,0,0.05); border-color: var(--primary); }

        .lesson-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; }
        .type-badge { font-size: 10px; font-weight: 800; text-transform: uppercase; padding: 4px 10px; border-radius: 6px; background: #e0e7ff; color: var(--primary); margin-bottom: 10px; display: inline-block; }
        .type-badge.personal { background: #fef3c7; color: #d97706; } /* Thêm CSS màu cho tag Cá nhân */
        
        .lesson-title { font-size: 20px; font-weight: 700; margin: 0; }
        .lesson-stats { font-size: 13px; color: var(--text-body); margin-top: 5px; }

        /* Button Group - Hỗ trợ cả khi có 3 cột hoặc 4 cột linh hoạt */
        .action-group { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; }
        
        .action-btn {
            display: flex; align-items: center; justify-content: center; gap: 8px;
            padding: 12px; border-radius: 12px; text-decoration: none; font-weight: 700;
            font-size: 13px; transition: 0.2s;
        }

        .btn-add-card { background: #f1f5f9; color: #475569; }
        .btn-add-card:hover { background: #e2e8f0; }

        .btn-study { background: #eef2ff; color: var(--primary); }
        .btn-study:hover { background: var(--primary); color: white; }

        .btn-practice { background: #ecfdf5; color: var(--success); }
        .btn-practice:hover { background: var(--success); color: white; }

        .btn-test { background: #fff1f2; color: var(--danger); }
        .btn-test:hover { background: var(--danger); color: white; }

        @media (max-width: 800px) {
            .action-group { grid-template-columns: 1fr 1fr; }
            .btn-create-lesson { position: relative; top: 0; margin-top: 20px; display: inline-flex; }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <a href="index.php" class="btn-back">
            <i class="fa-solid fa-arrow-left"></i> Quay lại Thư viện
        </a>
        <h1><?php echo htmlspecialchars($folder['name']); ?></h1>
        <p class="description"><?php echo htmlspecialchars($folder['description']); ?></p>
        
        <?php if ($can_edit_folder): ?>
            <a href="add_lesson.php?f_id=<?php echo $folder_id; ?>" class="btn-create-lesson">
                <i class="fa-solid fa-folder-plus"></i> Tạo bài học mới
            </a>
        <?php endif; ?>
    </div>

    <h3 style="font-size: 22px; display: flex; align-items: center; gap: 10px; margin-top: 60px;">
        <i class="fa-solid fa-graduation-cap" style="color: var(--primary);"></i>
        Lộ trình bài học
    </h3>
    
    <div class="lesson-list">
        <?php
        // Truy vấn danh sách bài học
        $sql = "SELECT l.*, (SELECT COUNT(c.id) FROM cards c WHERE c.lesson_id = l.id) as card_count 
                FROM lessons l WHERE l.folder_id = $folder_id ORDER BY l.id ASC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                // Xác định class màu cho tag dựa trên type của bài học
                $badge_class = ($row['type'] == 'system') ? 'system' : 'personal';
                $badge_text = ($row['type'] == 'system') ? 'Bài học hệ thống' : 'Cá nhân';
                ?>
                <div class="lesson-card">
                    <div class="lesson-header">
                        <div>
                            <span class="type-badge <?php echo $badge_class; ?>"><?php echo $badge_text; ?></span>
                            <h3 class="lesson-title"><?php echo htmlspecialchars($row['name']); ?></h3>
                            <div class="lesson-stats">
                                <i class="fa-solid fa-clone"></i> <?php echo $row['card_count']; ?> thẻ ghi nhớ
                            </div>
                        </div>
                        <div style="color: var(--success); font-size: 24px;">
                            <i class="fa-solid fa-circle-check"></i>
                        </div>
                    </div>
                
                    <div class="action-group">
                        <?php if ($can_edit_folder): ?>
                            <a href="add_card.php?l_id=<?php echo $row['id']; ?>&f_id=<?php echo $folder_id; ?>" class="action-btn btn-add-card">
                                <i class="fa-solid fa-plus"></i> Thêm thẻ
                            </a>
                        <?php endif; ?>

                        <a href="study_flashcard.php?lesson_id=<?php echo $row['id']; ?>&f_id=<?php echo $folder_id; ?>" class="action-btn btn-study">
                            <i class="fa-solid fa-play"></i> Học thẻ
                        </a>
                        
                        <a href="practice.php?lesson_id=<?php echo $row['id']; ?>&f_id=<?php echo $folder_id; ?>" class="action-btn btn-practice">
                            <i class="fa-solid fa-pen-nib"></i> Luyện tập
                        </a>

                        <a href="test.php?lesson_id=<?php echo $row['id']; ?>&f_id=<?php echo $folder_id; ?>" class="action-btn btn-test">
                            <i class="fa-solid fa-stopwatch"></i> Kiểm tra
                        </a>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<div style='text-align: center; padding: 40px; color: var(--text-body); background: var(--white); border-radius: 24px; border: 1px dashed var(--border);'>
                    <i class='fa-solid fa-book-open' style='font-size: 32px; margin-bottom: 10px;'></i>
                    <p style='margin:0;'>Chưa có bài học nào trong thư mục này.</p>
                  </div>";
        }
        ?>
    </div>
</div>

</body>
</html>