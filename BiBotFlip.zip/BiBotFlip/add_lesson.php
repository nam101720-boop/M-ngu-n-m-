<?php
include 'config/db.php';

// Lấy folder_id từ URL
$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0;

if (isset($_POST['submit_lesson'])) {
    $folder_id = intval($_POST['folder_id']);
    $lesson_name = $conn->real_escape_string($_POST['lesson_name']);

    // 1. Lưu bài học mới vào bảng lessons (mặc định type là system để tránh lỗi cũ)
    $sql = "INSERT INTO lessons (folder_id, name, type) VALUES ($folder_id, '$lesson_name', 'system')";

    if ($conn->query($sql) === TRUE) {
        // Sau khi tạo tên bài học xong, quay về view_folder để thấy bài học mới xuất hiện
        header("Location: view_folder.php?id=" . $folder_id);
        exit();
    } else {
        echo "Lỗi: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tạo bài học mới</title>
    <style>
        body { font-family: sans-serif; background: #f8fafc; display: flex; justify-content: center; padding-top: 100px; }
        .form-box { background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); width: 350px; }
        h3 { margin-top: 0; color: #1e293b; }
        input { width: 100%; padding: 12px; margin: 15px 0; border: 1px solid #ddd; border-radius: 10px; box-sizing: border-box; outline: none; }
        button { width: 100%; padding: 12px; background: #6366f1; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: bold; }
        .back-link { display: block; text-align: center; margin-top: 15px; color: #64748b; text-decoration: none; font-size: 14px; }
    </style>
</head>
<body>
    <div class="form-box">
        <h3><i class="fa-solid fa-book"></i> Tạo bài học mới</h3>
        <form method="POST">
            <input type="hidden" name="folder_id" value="<?php echo $f_id; ?>">
            <label style="font-size: 14px; color: #64748b;">Tên bài học:</label>
            <input type="text" name="lesson_name" placeholder="Ví dụ: Bài 7: Từ vựng kế toán" required autofocus>
            <button type="submit" name="submit_lesson">Lưu bài học</button>
            <a href="view_folder.php?id=<?php echo $f_id; ?>" class="back-link">Hủy bỏ</a>
        </form>
    </div>
</body>
</html>