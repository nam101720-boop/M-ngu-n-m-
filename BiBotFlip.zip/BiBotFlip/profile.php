<?php 
session_start();
include 'config/db.php'; 

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$display_name = $_SESSION['display_name']; 
$user_role = $_SESSION['role'];
$initials = $_SESSION['initials'];
$user_id = $_SESSION['user_id'];

// Thống kê hệ thống
$total_users = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$total_folders = $conn->query("SELECT COUNT(*) as total FROM folders")->fetch_assoc()['total'];
$total_exam_questions = $conn->query("SELECT COUNT(*) as total FROM exam_questions")->fetch_assoc()['total'];

// Thống kê cá nhân
$total_cards = $conn->query("SELECT COUNT(*) as total FROM cards")->fetch_assoc()['total'];
$mastered_cards = $conn->query("SELECT COUNT(*) as total FROM cards WHERE mastery_level >= 3")->fetch_assoc()['total'];
$progress_percent = ($total_cards > 0) ? round(($mastered_cards / $total_cards) * 100) : 0;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ cá nhân - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --bg: #f8fafc;
            --text-title: #1e293b;
            --text-body: #64748b;
            --admin-color: #1e293b;
        }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: var(--bg); 
            margin: 0; color: var(--text-title);
        }

        .container { max-width: 1000px; margin: 50px auto; padding: 0 20px; }

        .back-link {
            display: inline-flex; align-items: center; gap: 8px;
            text-decoration: none; color: var(--text-body);
            font-weight: 700; margin-bottom: 25px; transition: 0.2s;
        }
        .back-link:hover { color: var(--primary); transform: translateX(-5px); }

        .profile-header {
            background: white; border-radius: 30px; padding: 40px;
            display: flex; align-items: center; gap: 35px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.02);
            border: 1px solid #f1f5f9;
        }

        .avatar-large {
            width: 130px; height: 130px; 
            background: <?php echo ($user_role == 'admin') ? 'var(--admin-color)' : 'var(--primary)'; ?>;
            color: white; border-radius: 40px; 
            display: flex; align-items: center; justify-content: center;
            font-size: 45px; font-weight: 800;
            box-shadow: 0 15px 30px rgba(99, 102, 241, 0.2);
        }

        .role-badge {
            display: inline-block; padding: 6px 16px; border-radius: 20px;
            font-size: 12px; font-weight: 800; text-transform: uppercase;
            margin-bottom: 12px;
            background: <?php echo ($user_role == 'admin') ? '#f1f5f9' : '#eef2ff'; ?>;
            color: <?php echo ($user_role == 'admin') ? '#475569' : 'var(--primary)'; ?>;
        }

        .profile-info h1 { margin: 0; font-size: 32px; font-weight: 800; }
        .profile-info p { margin: 8px 0 0 0; color: var(--text-body); font-weight: 500; }

        .stats-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px; margin-top: 30px;
        }

        .stat-card {
            background: white; padding: 30px; border-radius: 24px;
            border: 1px solid #f1f5f9; text-align: center;
            transition: 0.3s;
        }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.03); }
        .stat-icon { font-size: 24px; color: var(--primary); margin-bottom: 15px; display: block; }
        .stat-value { display: block; font-size: 36px; font-weight: 800; margin-bottom: 5px; }
        .stat-label { font-size: 14px; color: var(--text-body); font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }

        .progress-section {
            background: white; border-radius: 24px; padding: 35px;
            margin-top: 30px; border: 1px solid #f1f5f9;
        }
        .progress-info { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .progress-info h3 { margin: 0; font-size: 18px; }
        .progress-bar-container { background: #f1f5f9; height: 14px; border-radius: 10px; overflow: hidden; }
        
        /* CHỖ NÀY ĐÃ ĐƯỢC SỬA: Dùng biến CSS --p để tránh báo lỗi đỏ */
        .progress-bar-fill { 
            background: linear-gradient(90deg, var(--primary), #818cf8);
            height: 100%; 
            width: var(--p, 0%);
            transition: 1s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .footer-note { margin-top: 20px; font-size: 13px; color: var(--text-body); display: flex; align-items: center; gap: 8px; }
    </style>
</head>
<body>

    <div class="container">
        <a href="index.php" class="back-link">
            <i class="fa-solid fa-arrow-left"></i> Quay lại Dashboard
        </a>

        <div class="profile-header">
            <div class="avatar-large">
                <?php echo $initials; ?>
            </div>
            <div class="profile-info">
                <div class="role-badge">
                    <i class="fa-solid <?php echo ($user_role == 'admin') ? 'fa-shield-halved' : 'fa-graduation-cap'; ?>"></i> 
                    <?php echo ($user_role == 'admin') ? 'Quản trị viên hệ thống' : 'Tài khoản Sinh viên'; ?>
                </div>
                <h1><?php echo htmlspecialchars($display_name); ?></h1>
                <p>
                    <i class="fa-solid fa-circle-check" style="color: #10b981;"></i> 
                    <?php echo ($user_role == 'admin') ? 'Đang điều hành phiên làm việc' : 'Đang trong lộ trình học tập'; ?>
                </p>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <i class="fa-solid fa-users stat-icon"></i>
                <span class="stat-value"><?php echo $total_users; ?></span>
                <span class="stat-label">Tổng người dùng</span>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-folder-tree stat-icon"></i>
                <span class="stat-value"><?php echo $total_folders; ?></span>
                <span class="stat-label">Bộ thẻ hệ thống</span>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-file-invoice stat-icon"></i>
                <span class="stat-value"><?php echo $total_exam_questions; ?></span>
                <span class="stat-label">Câu hỏi trắc nghiệm</span>
            </div>
        </div>

        <div class="progress-section">
            <div class="progress-info">
                <h3>Tiến độ hoàn thành Flashcard</h3>
                <span style="font-weight: 800; color: var(--primary);"><?php echo $progress_percent; ?>%</span>
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar-fill" style="--p: <?php echo $progress_percent; ?>%;"></div>
            </div>
            <div class="footer-note">
                <i class="fa-solid fa-circle-info"></i>
                Hệ thống ghi nhận bạn đã thuộc lòng <?php echo $mastered_cards; ?> trên tổng số <?php echo $total_cards; ?> thẻ vựng.
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('.stat-value').forEach(el => {
            const target = +el.innerText;
            if (target === 0) return;
            let count = 0;
            const update = () => {
                const speed = target / 50;
                if(count < target) {
                    count += speed;
                    el.innerText = Math.ceil(count);
                    setTimeout(update, 20);
                } else {
                    el.innerText = target;
                }
            }
            update();
        });
    </script>

</body>
</html>