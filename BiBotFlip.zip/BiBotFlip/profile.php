<?php 
session_start();
include 'config/db.php'; 

// 1. Kiểm tra bảo mật đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$display_name = $_SESSION['display_name']; 
$initials = $_SESSION['initials'];

// 2. Lấy thông tin mới nhất của User từ Database để đổ vào Form
$user_query = $conn->query("SELECT * FROM users WHERE id = $user_id LIMIT 1");
$user_data = $user_query->fetch_assoc();

// Thiết lập ảnh đại diện (Nếu trong DB chưa có hoặc file không tồn tại thì dùng ảnh mặc định)
$avatar_path = !empty($user_data['avatar']) && file_exists($user_data['avatar']) 
               ? $user_data['avatar'] 
               : 'assets/default-avatar.png'; 

// 3. XỬ LÝ FORM 1: Cập nhật thông tin cá nhân (Email & Mật khẩu)
$msg_info = "";
if (isset($_POST['update_info'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    
    // Nếu điền họ tên mới (Dành cho tài khoản muốn giữ tên thật, Admin)
    $fullname_update = isset($_POST['fullname']) ? $conn->real_escape_string($_POST['fullname']) : $user_data['fullname'];

    if (!empty($password)) {
        // Nếu người dùng có nhập mật khẩu mới
        $sql_update = "UPDATE users SET fullname = '$fullname_update', email = '$email', password = '$password' WHERE id = $user_id";
    } else {
        // Nếu để trống mật khẩu thì giữ nguyên mật khẩu cũ
        $sql_update = "UPDATE users SET fullname = '$fullname_update', email = '$email' WHERE id = $user_id";
    }

    if ($conn->query($sql_update)) {
        // Cập nhật lại tên hiển thị trong Session nếu là Admin đổi tên
        if ($user_role === 'admin') {
            $_SESSION['display_name'] = $fullname_update;
        }
        echo "<script>alert('Cập nhật thông tin cá nhân thành công!'); window.location.href='profile.php';</script>";
        exit();
    } else {
        $msg_info = "<p style='color:red;'>Lỗi cập nhật: " . $conn->error . "</p>";
    }
}

// 4. XỬ LÝ FORM 2: Thay đổi ảnh đại diện (Avatar Upload)
if (isset($_POST['upload_avatar']) && isset($_FILES['avatar_file'])) {
    $file = $_FILES['avatar_file'];
    
    // Kiểm tra xem người dùng đã chọn file chưa
    if ($file['error'] === 0) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];

        // Kiểm tra định dạng file ảnh hợp lệ
        if (in_array($ext, $allowed)) {
            // Kiểm tra dung lượng file (Giới hạn dưới 2MB)
            if ($file['size'] <= 2 * 1024 * 1024) {
                
                // Tạo thư mục lưu trữ nếu chưa có
                if (!file_exists('uploads/avatars')) {
                    mkdir('uploads/avatars', 0777, true);
                }

                // Đặt tên file duy nhất theo ID người dùng để không bị trùng lặp
                $new_file_name = "uploads/avatars/user_" . $user_id . "_" . time() . "." . $ext;

                if (move_uploaded_file($file['tmp_name'], $new_file_name)) {
                    // Xóa file ảnh cũ của user này nếu có để đỡ nặng máy chủ
                    if (!empty($user_data['avatar']) && file_exists($user_data['avatar'])) {
                        unlink($user_data['avatar']);
                    }

                    // Lưu đường dẫn file ảnh mới vào Database
                    $conn->query("UPDATE users SET avatar = '$new_file_name' WHERE id = $user_id");
                    echo "<script>alert('Thay đổi ảnh đại diện thành công!'); window.location.href='profile.php';</script>";
                    exit();
                }
            } else {
                echo "<script>alert('Dung lượng ảnh quá lớn! Vui lòng chọn ảnh dưới 2MB.');</script>";
            }
        } else {
            echo "<script>alert('Định dạng file không hỗ trợ! Chỉ chấp nhận JPG, PNG, GIF.');</script>";
        }
    }
}

// 5. Các câu lệnh thống kê dữ liệu hệ thống (Giữ nguyên logic cũ của bạn)
$total_users = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$total_folders = $conn->query("SELECT COUNT(*) as total FROM folders")->fetch_assoc()['total'];
$total_exam_questions = $conn->query("SELECT COUNT(*) as total FROM exam_questions")->fetch_assoc()['total'];
$total_cards = $conn->query("SELECT COUNT(*) as total FROM cards")->fetch_assoc()['total'];
$mastered_cards = $conn->query("SELECT COUNT(*) as total FROM cards WHERE mastery_level >= 3")->fetch_assoc()['total'];
$progress_percent = ($total_cards > 0) ? round(($mastered_cards / $total_cards) * 100) : 0;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ cá nhân - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --primary-hover: #4f46e5; --bg: #f8fafc; --text: #1e293b; --border: #e2e8f0; --admin-color: #1e293b; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: var(--bg); margin: 0; color: var(--text); }
        .container { max-width: 1000px; margin: 50px auto; padding: 0 20px; }
        
        .back-link { display: inline-flex; align-items: center; gap: 8px; text-decoration: none; color: #64748b; font-weight: 700; margin-bottom: 25px; transition: 0.2s; }
        .back-link:hover { color: var(--primary); transform: translateX(-5px); }

        /* Khối Header Profile */
        .profile-header { background: white; border-radius: 30px; padding: 40px; display: flex; align-items: center; gap: 35px; border: 1px solid #f1f5f9; box-shadow: 0 10px 30px rgba(0,0,0,0.01); }
        
        /* CSS Khu vực Avatar tích hợp nút Upload ẩn */
        .avatar-wrapper { position: relative; width: 130px; height: 130px; cursor: pointer; }
        .avatar-img { width: 130px; height: 130px; border-radius: 40px; object-fit: cover; border: 4px solid white; box-shadow: 0 10px 25px rgba(0,0,0,0.08); }
        .avatar-placeholder { width: 130px; height: 130px; background: <?php echo ($user_role == 'admin') ? 'var(--admin-color)' : 'var(--primary)'; ?>; color: white; border-radius: 40px; display: flex; align-items: center; justify-content: center; font-size: 45px; font-weight: 800; box-shadow: 0 10px 25px rgba(99, 102, 241, 0.2); }
        .avatar-hover-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.5); border-radius: 40px; display: flex; align-items: center; justify-content: center; color: white; font-size: 20px; opacity: 0; transition: 0.2s; }
        .avatar-wrapper:hover .avatar-hover-overlay { opacity: 1; }

        .role-badge { display: inline-block; padding: 6px 16px; border-radius: 20px; font-size: 12px; font-weight: 800; text-transform: uppercase; margin-bottom: 12px; background: <?php echo ($user_role == 'admin') ? '#f1f5f9' : '#eef2ff'; ?>; color: <?php echo ($user_role == 'admin') ? '#475569' : 'var(--primary)'; ?>; }
        
        /* Layout chia hai khu vực quản trị và chỉnh sửa */
        .profile-body-grid { display: grid; grid-template-columns: 1.2fr 1fr; gap: 30px; margin-top: 30px; }
        .section-box { background: white; padding: 35px; border-radius: 24px; border: 1px solid #f1f5f9; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.01); }
        
        h2 { font-size: 20px; font-weight: 800; margin-top: 0; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; }
        label { display: block; font-weight: 700; margin-bottom: 8px; font-size: 14px; color: #475569; }
        input[type="text"], input[type="email"], input[type="password"] { width: 100%; padding: 12px 16px; margin-bottom: 20px; border: 2px solid #f1f5f9; border-radius: 12px; outline: none; box-sizing: border-box; font-family: inherit; font-size: 15px; }
        input:focus { border-color: var(--primary); }
        
        .btn { background: var(--primary); color: white; border: none; padding: 14px 24px; border-radius: 12px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; font-size: 15px; width: 100%; justify-content: center; }
        .btn:hover { background: var(--primary-hover); }

        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; }
        .stat-card { background: #f8fafc; padding: 20px; border-radius: 16px; text-align: center; border: 1px solid #e2e8f0; }
        .stat-value { display: block; font-size: 24px; font-weight: 800; }
        .stat-label { font-size: 11px; color: #64748b; font-weight: 700; text-transform: uppercase; margin-top: 4px; }
    </style>
</head>
<body>

    <div class="container">
        <a href="index.php" class="back-link"><i class="fa-solid fa-arrow-left"></i> Quay lại Dashboard</a>

        <!-- 1. KHỐI HEADER HỒ SƠ -->
        <div class="profile-header">
            <!-- Form upload ảnh ngầm ẩn khi click vào ảnh -->
            <form id="avatarForm" method="POST" enctype="multipart/form-data">
                <div class="avatar-wrapper" onclick="document.getElementById('fileInput').click();">
                    <?php if(!empty($user_data['avatar']) && file_exists($user_data['avatar'])): ?>
                        <img src="<?php echo $user_data['avatar']; ?>" class="avatar-img" alt="Avatar">
                    <?php else: ?>
                        <div class="avatar-placeholder"><?php echo $initials; ?></div>
                    <?php endif; ?>
                    <div class="avatar-hover-overlay"><i class="fa-solid fa-camera"></i></div>
                </div>
                <!-- Input chọn file ẩn đi -->
                <input type="file" id="fileInput" name="avatar_file" style="display:none;" onchange="document.getElementById('submitAvatarBtn').click();">
                <button type="submit" id="submitAvatarBtn" name="upload_avatar" style="display:none;"></button>
            </form>

            <div class="profile-info">
                <div class="role-badge">
                    <i class="fa-solid <?php echo ($user_role == 'admin') ? 'fa-shield-halved' : 'fa-graduation-cap'; ?>"></i> 
                    <?php echo ($user_role == 'admin') ? 'Quản trị viên hệ thống' : 'Tài khoản Sinh viên'; ?>
                </div>
                <h1 style="margin: 0; font-size: 28px; font-weight: 800;"><?php echo htmlspecialchars($display_name); ?></h1>
                <p style="margin: 5px 0 0 0; color: #64748b; font-size: 14px;"><i class="fa-regular fa-envelope"></i> <?php echo htmlspecialchars($user_data['email'] ?? 'Chưa cập nhật email'); ?></p>
            </div>
        </div>

        <!-- 2. KHỐI NỘI DUNG CHIA LÀM HAI BÊN -->
        <div class="profile-body-grid">
            
            <!-- BÊN TRÁI: FORM CẬP NHẬT THÔNG TIN CÁ NHÂN -->
            <div class="section-box">
                <h2><i class="fa-regular fa-id-card" style="color: var(--primary);"></i> Chỉnh sửa thông tin</h2>
                <?php echo $msg_info; ?>
                
                <form method="POST">
                    <!-- Nếu là tài khoản Admin thì cho sửa Họ và Tên, Sinh viên hiển thị mã định danh cố định -->
                    <?php if ($user_role === 'admin'): ?>
                        <label>Họ và Tên Quản Trị Viên</label>
                        <input type="text" name="fullname" value="<?php echo htmlspecialchars($user_data['fullname']); ?>" required>
                    <?php else: ?>
                        <label>Tên định danh (Tự động cấp quyền)</label>
                        <input type="text" value="<?php echo htmlspecialchars($display_name); ?>" disabled style="background: #f1f5f9; color: #94a3b8; cursor: not-allowed;">
                    <?php endif; ?>

                    <label>Địa chỉ Email</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>" placeholder="nhapemail@student.vn" required>

                    <label>Mật khẩu mới (Để trống nếu giữ nguyên)</label>
                    <input type="password" name="password" placeholder="••••••••">

                    <button type="submit" name="update_info" class="btn"><i class="fa-solid fa-circle-check"></i> Lưu thay đổi</button>
                </form>
            </div>

            <!-- BÊN PHẢI: BẢNG SỐ LIỆU THỐNG KÊ HỆ THỐNG -->
            <div class="section-box" style="display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                    <h2><i class="fa-solid fa-chart-pie" style="color: #10b981;"></i> Thống kê hoạt động</h2>
                    
                    <div class="stats-grid">
                        <div class="stat-card">
                            <span class="stat-value" style="color: var(--primary);"><?php echo $total_users; ?></span>
                            <span class="stat-label">Thành viên</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value" style="color: #f59e0b;"><?php echo $total_folders; ?></span>
                            <span class="stat-label">Bộ từ vựng</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value" style="color: #10b981;"><?php echo $total_exam_questions; ?></span>
                            <span class="stat-label">Câu hỏi</span>
                        </div>
                    </div>
                </div>

                <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 25px; border-radius: 16px;">
                    <div style="display:flex; justify-content: space-between; font-weight:800; font-size:14px; margin-bottom:10px;">
                        <span>Tiến độ Flashcard</span>
                        <span style="color: var(--primary);"><?php echo $progress_percent; ?>%</span>
                    </div>
                    <div style="background: #e2e8f0; height: 10px; border-radius: 10px; overflow: hidden;">
                        <div style="background: var(--primary); height: 100%; width: <?php echo $progress_percent; ?>%;"></div>
                    </div>
                    <p style="font-size: 12px; color: #64748b; margin-top: 10px; font-weight: 500; line-height: 1.4;">
                        <i class="fa-solid fa-info-circle"></i> Hệ thống ghi nhận bạn đã thuộc lòng <?php echo $mastered_cards; ?> / <?php echo $total_cards; ?> thẻ ghi nhớ.
                    </p>
                </div>
            </div>

        </div>
    </div>

</body>
</html>