<?php
session_start();
include 'config/db.php';

// 1. Bảo mật: Chỉ Admin mới được phép vào chỉnh sửa
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("<div style='padding:20px; color:red; font-weight:bold;'>Bạn không có quyền truy cập trang quản trị này!</div>");
}

$exam_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 2. Lấy thông tin chung của đề thi
$exam_query = "SELECT * FROM exams WHERE id = $exam_id LIMIT 1";
$exam_result = $conn->query($exam_query);
if ($exam_result->num_rows == 0) {
    die("<div style='padding:20px;'>Không tìm thấy đề thi yêu cầu!</div>");
}
$exam = $exam_result->fetch_assoc();

// 3. XỬ LÝ FORM: Khi Admin nhấn nút lưu thay đổi thông tin chung
if (isset($_POST['update_exam_info'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $desc = $conn->real_escape_string($_POST['description']);
    $duration = intval($_POST['duration']);

    $sql_update_info = "UPDATE exams SET title = '$title', description = '$desc', duration = $duration WHERE id = $exam_id";
    if ($conn->query($sql_update_info)) {
        echo "<script>alert('Cập nhật thông tin đề thi thành công!'); window.location.href='admin_edit_exam.php?id=$exam_id';</script>";
        exit();
    }
}

// 4. XỬ LÝ FORM: Khi Admin cập nhật một câu hỏi cụ thể trong đề
if (isset($_POST['update_question'])) {
    $q_id = intval($_POST['question_id']);
    $q_text = $conn->real_escape_string($_POST['question_text']);
    $a = $conn->real_escape_string($_POST['option_a']);
    $b = $conn->real_escape_string($_POST['option_b']);
    $c = $conn->real_escape_string($_POST['option_c']);
    $d = $conn->real_escape_string($_POST['option_d']);
    $correct = $conn->real_escape_string($_POST['correct_option']);

    $sql_update_q = "UPDATE exam_questions SET 
                    question_text = '$q_text', 
                    option_a = '$a', 
                    option_b = '$b', 
                    option_c = '$c', 
                    option_d = '$d', 
                    correct_option = '$correct' 
                    WHERE id = $q_id AND exam_id = $exam_id";
    if ($conn->query($sql_update_q)) {
        echo "<script>alert('Cập nhật câu hỏi thành công!'); window.location.href='admin_edit_exam.php?id=$exam_id';</script>";
        exit();
    }
}

// 5. XỬ LÝ FORM: Khi Admin muốn XÓA hẳn một câu hỏi ra khỏi đề thi
if (isset($_GET['action']) && $_GET['action'] == 'delete_q') {
    $delete_q_id = intval($_GET['q_id']);
    $sql_delete_q = "DELETE FROM exam_questions WHERE id = $delete_q_id AND exam_id = $exam_id";
    if ($conn->query($sql_delete_q)) {
        header("Location: admin_edit_exam.php?id=$exam_id");
        exit();
    }
}

// 6. THÀNH PHẦN THÊM MỚI LOGIC: Xử lý khi Admin nhấn THÊM CÂU HỎI MỚI
if (isset($_POST['add_new_question'])) {
    $q_text = $conn->real_escape_string($_POST['new_question_text']);
    $a = $conn->real_escape_string($_POST['new_option_a']);
    $b = $conn->real_escape_string($_POST['new_option_b']);
    $c = $conn->real_escape_string($_POST['new_option_c']);
    $d = $conn->real_escape_string($_POST['new_option_d']);
    $correct = $conn->real_escape_string($_POST['new_correct_option']);

    $sql_add_q = "INSERT INTO exam_questions (exam_id, question_text, option_a, option_b, option_c, option_d, correct_option) 
                  VALUES ($exam_id, '$q_text', '$a', '$b', '$c', '$d', '$correct')";
    if ($conn->query($sql_add_q)) {
        echo "<script>alert('Thêm câu hỏi mới thành công!'); window.location.href='admin_edit_exam.php?id=$exam_id';</script>";
        exit();
    }
}

// 7. Lấy toàn bộ danh sách câu hỏi hiện tại thuộc đề thi này
$questions_query = "SELECT * FROM exam_questions WHERE exam_id = $exam_id ORDER BY id ASC";
$questions_result = $conn->query($questions_query);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Đề thi & Câu hỏi - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --primary-hover: #4f46e5; --bg: #f8fafc; --text: #1e293b; --border: #e2e8f0; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding: 40px; color: var(--text); }
        .container { max-width: 900px; margin: auto; }
        
        .section-box { background: white; padding: 35px; border-radius: 24px; border: 1px solid #f1f5f9; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); margin-bottom: 30px; }
        h2 { font-size: 24px; font-weight: 800; margin-top: 0; display: flex; align-items: center; gap: 10px; color: var(--text); }
        
        label { display: block; font-weight: 700; margin-bottom: 8px; font-size: 14px; }
        input[type="text"], input[type="number"], textarea, select { 
            width: 100%; padding: 12px 16px; margin-bottom: 20px; border: 2px solid #f1f5f9; border-radius: 12px; outline: none; box-sizing: border-box; font-family: inherit; font-size: 15px;
        }
        input:focus, textarea:focus, select:focus { border-color: var(--primary); }
        
        .btn { background: var(--primary); color: white; border: none; padding: 14px 24px; border-radius: 12px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; font-size: 15px; }
        .btn:hover { background: var(--primary-hover); }
        .btn-danger { background: #ef4444; }
        .btn-danger:hover { background: #dc2626; }
        
        /* Cấu trúc thẻ câu hỏi */
        .question-item { background: #f8fafc; padding: 25px; border-radius: 16px; border: 1px solid #e2e8f0; margin-bottom: 25px; position: relative; }
        .question-number { background: #e0e7ff; color: var(--primary); width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px; margin-bottom: 15px; }
        .options-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px; }
        .q-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 20px; border-top: 1px dashed #e2e8f0; padding-top: 15px; }
        
        /* Chỉnh riêng màu sắc nhận diện khối thêm câu hỏi mới */
        .new-question-box { border: 2px dashed #6366f1; background: #fafaff; }
    </style>
</head>
<body>

<div class="container">
    <div style="margin-bottom: 25px;">
        <a href="online_exams.php" style="text-decoration:none; color:#64748b; font-weight:700;"><i class="fa-solid fa-arrow-left"></i> Quay lại danh sách đề thi</a>
    </div>

    <!-- PHẦN 1: SỬA THÔNG TIN CHUNG CỦA ĐỀ THI -->
    <div class="section-box">
        <h2><i class="fa-solid fa-gear" style="color: var(--primary);"></i> Cấu hình thông tin đề thi</h2>
        <form method="POST">
            <label>Tên đề thi</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($exam['title']); ?>" required>

            <label>Mô tả đề thi</label>
            <textarea name="description" rows="3"><?php echo htmlspecialchars($exam['description']); ?></textarea>

            <label>Thời gian làm bài (phút)</label>
            <input type="number" name="duration" value="<?php echo $exam['duration']; ?>" required style="width: 150px;">

            <button type="submit" name="update_exam_info" class="btn"><i class="fa-solid fa-floppy-disk"></i> Lưu thông tin chung</button>
        </form>
    </div>

    <!-- PHẦN 2: QUẢN LÝ / SỬA CÁC CÂU HỎI TRONG ĐỀ THI -->
    <div class="section-box">
        <h2><i class="fa-solid fa-list-check" style="color: #10b981;"></i> Danh sách câu hỏi trong đề (<?php echo $questions_result->num_rows; ?> câu)</h2>
        
        <?php if ($questions_result->num_rows > 0): ?>
            <?php $index = 1; ?>
            <?php while($q = $questions_result->fetch_assoc()): ?>
                
                <form method="POST" class="question-item">
                    <input type="hidden" name="question_id" value="<?php echo $q['id']; ?>">
                    <div class="question-number"><?php echo $index++; ?></div>
                    
                    <label>Nội dung câu hỏi</label>
                    <textarea name="question_text" rows="2" required><?php echo htmlspecialchars($q['question_text']); ?></textarea>
                    
                    <div class="options-grid">
                        <div>
                            <label style="color: #64748b;">Đáp án A</label>
                            <input type="text" name="option_a" value="<?php echo htmlspecialchars($q['option_a']); ?>" required>
                        </div>
                        <div>
                            <label style="color: #64748b;">Đáp án B</label>
                            <input type="text" name="option_b" value="<?php echo htmlspecialchars($q['option_b']); ?>" required>
                        </div>
                        <div>
                            <label style="color: #64748b;">Đáp án C</label>
                            <input type="text" name="option_c" value="<?php echo htmlspecialchars($q['option_c']); ?>" required>
                        </div>
                        <div>
                            <label style="color: #64748b;">Đáp án D</label>
                            <input type="text" name="option_d" value="<?php echo htmlspecialchars($q['option_d']); ?>" required>
                        </div>
                    </div>
                    
                    <div style="width: 250px;">
                        <label style="color: #10b981;"><i class="fa-solid fa-square-check"></i> Đáp án đúng</label>
                        <select name="correct_option">
                            <option value="A" <?php echo ($q['correct_option'] == 'A') ? 'selected' : ''; ?>>Đáp án A</option>
                            <option value="B" <?php echo ($q['correct_option'] == 'B') ? 'selected' : ''; ?>>Đáp án B</option>
                            <option value="C" <?php echo ($q['correct_option'] == 'C') ? 'selected' : ''; ?>>Đáp án C</option>
                            <option value="D" <?php echo ($q['correct_option'] == 'D') ? 'selected' : ''; ?>>Đáp án D</option>
                        </select>
                    </div>
                    
                    <div class="q-actions">
                        <a href="admin_edit_exam.php?id=<?php echo $exam_id; ?>&action=delete_q&q_id=<?php echo $q['id']; ?>" 
                           onclick="return confirm('Bạn có chắc chắn muốn xóa hẳn câu hỏi này ra khỏi đề thi không?');" 
                           class="btn btn-danger" style="padding: 8px 16px; font-size: 13px; text-decoration: none;">
                            <i class="fa-solid fa-trash-can"></i> Xóa câu này
                        </a>
                        
                        <button type="submit" name="update_question" class="btn" style="background: #10b981; padding: 8px 16px; font-size: 13px;">
                            <i class="fa-solid fa-circle-check"></i> Cập nhật câu này
                        </button>
                    </div>
                </form>

            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align: center; color: #94a3b8; padding: 20px;">Đề thi này hiện tại chưa có câu hỏi nào.</p>
        <?php endif; ?>
    </div>

    <!-- THÀNH PHẦN THÊM MỚI GIAO DIỆN: KHỐI THÊM CÂU HỎI MỚI VÀO ĐỀ -->
    <div class="section-box">
        <h2><i class="fa-solid fa-circle-plus" style="color: var(--primary);"></i> Thêm câu hỏi mới vào đề thi</h2>
        
        <form method="POST" class="question-item new-question-box">
            <label>Nội dung câu hỏi mới</label>
            <textarea name="new_question_text" rows="2" placeholder="Nhập nội dung câu hỏi trắc nghiệm mới tại đây..." required></textarea>
            
            <div class="options-grid">
                <div>
                    <label style="color: #64748b;">Đáp án A</label>
                    <input type="text" name="new_option_a" placeholder="Nhập lựa chọn A..." required>
                </div>
                <div>
                    <label style="color: #64748b;">Đáp án B</label>
                    <input type="text" name="new_option_b" placeholder="Nhập lựa chọn B..." required>
                </div>
                <div>
                    <label style="color: #64748b;">Đáp án C</label>
                    <input type="text" name="new_option_c" placeholder="Nhập lựa chọn C..." required>
                </div>
                <div>
                    <label style="color: #64748b;">Đáp án D</label>
                    <input type="text" name="new_option_d" placeholder="Nhập lựa chọn D..." required>
                </div>
            </div>
            
            <div style="width: 250px;">
                <label style="color: var(--primary);"><i class="fa-solid fa-square-check"></i> Chọn đáp án chính xác</label>
                <select name="new_correct_option">
                    <option value="A">Đáp án A</option>
                    <option value="B">Đáp án B</option>
                    <option value="C">Đáp án C</option>
                    <option value="D">Đáp án D</option>
                </select>
            </div>
            
            <div style="text-align: right; margin-top: 20px; border-top: 1px dashed var(--primary); padding-top: 15px;">
                <button type="submit" name="add_new_question" class="btn">
                    <i class="fa-solid fa-plus"></i> Lưu câu hỏi mới này
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>