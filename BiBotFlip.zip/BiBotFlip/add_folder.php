<?php
include 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    // 1. Lấy dữ liệu từ Form và làm sạch
    $folder_name = $conn->real_escape_string($_POST['folder_name']);
    
    // Tạo mô tả mặc định hoặc để trống tùy bạn (vì bảng của bạn có cột description)
    $description = "Bộ sưu tập các bài học về " . $folder_name;

    // 2. Câu lệnh SQL INSERT vào bảng folders
    // Lưu ý: Các cột id, created_at thường tự động, ta chỉ cần chèn name và description
    $sql = "INSERT INTO folders (name, description) VALUES ('$folder_id', '$description')";
    
    // Nếu bạn muốn chuẩn hơn để phân biệt hệ thống/cá nhân, bạn có thể chèn cả cột type nếu có
    // $sql = "INSERT INTO folders (name, description, type) VALUES ('$folder_name', '$description', 'personal')";

    if ($conn->query($sql) === TRUE) {
        // 3. Thành công thì quay về trang chủ (index.php)
        header("Location: index.php");
        exit();
    } else {
        echo "Lỗi: " . $conn->error;
    }
} else {
    // Nếu ai đó truy cập trực tiếp file này mà không qua Form
    header("Location: index.php");
    exit();
}
?>