<?php
session_start();
include 'config/db.php';

// Kiểm tra bảo mật: Chặn nếu chưa đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    
    // 1. Lấy dữ liệu và làm sạch chuỗi chống tấn công SQL Injection
    $folder_name = trim($_POST['folder_name']);
    $folder_name = $conn->real_escape_string($folder_name);
    
    // Tạo phần mô tả ngắn gắn liền với tên thư mục
    $description = "Bộ sưu tập các bài học về " . $folder_name;

    // Lấy ID tài khoản đang thao tác bấm tạo từ Session
    $user_id = $_SESSION['user_id'];

    // 2. Câu lệnh SQL INSERT chuẩn xác (chèn đúng tên $folder_name đã đặt và lưu vết user_id)
    $sql = "INSERT INTO folders (name, description, user_id) 
            VALUES ('$folder_name', '$description', $user_id)";

    if ($conn->query($sql) === TRUE) {
        // Thành công: Quay trở về trang chủ lập tức để thấy thư mục mới hiển thị
        header("Location: index.php");
        exit();
    } else {
        echo "Lỗi hệ thống: " . $conn->error;
    }
} else {
    header("Location: index.php");
    exit();
}
?>