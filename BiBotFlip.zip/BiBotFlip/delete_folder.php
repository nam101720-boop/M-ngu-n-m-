<?php
session_start();
include 'config/db.php';

// 1. Kiểm tra bảo mật cơ bản: Nếu chưa đăng nhập thì không cho chạy file này
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// 2. Kiểm tra nếu có ID thư viện truyền lên thanh URL để xóa
if (isset($_GET['id'])) {
    $folder_id = intval($_GET['id']);
    $user_id = $_SESSION['user_id'];
    $user_role = $_SESSION['role'];

    // 3. XỬ LÝ PHÂN QUYỀN BẢO MẬT HẬU ĐÀI (BACKEND)
    if ($user_role === 'admin') {
        // Luồng ADMIN: Kiểm tra xem thư viện này có tồn tại trong hệ thống hay không là cho xóa
        $check_sql = "SELECT id FROM folders WHERE id = $folder_id LIMIT 1";
    } else {
        // Luồng SINH VIÊN / KHÁC: Ép điều kiện bắt buộc folder phải là 'personal' (Cá nhân) 
        // và ID người tạo (user_id) phải trùng khớp với người đang đăng nhập bấm nút xóa.
        $check_sql = "SELECT id FROM folders WHERE id = $folder_id AND user_id = $user_id AND type = 'personal' LIMIT 1";
    }

    $check_result = $conn->query($check_sql);

    // 4. TIẾN HÀNH XÓA NẾU KHỚP QUYỀN TRUY CẬP
    if ($check_result && $check_result->num_rows > 0) {
        
        // Bước A: Tìm và xóa sạch các thẻ ghi nhớ (cards) nằm bên trong các bài học của thư viện này
        $delete_cards_sql = "DELETE FROM cards WHERE lesson_id IN (SELECT id FROM lessons WHERE folder_id = $folder_id)";
        $conn->query($delete_cards_sql);
        
        // Bước B: Xóa sạch toàn bộ các bài học (lessons) nằm trong thư viện này
        $delete_lessons_sql = "DELETE FROM lessons WHERE folder_id = $folder_id";
        $conn->query($delete_lessons_sql);

        // Bước C: Cuối cùng, xóa chính thư mục thư viện (folders) ra khỏi database
        $delete_folder_sql = "DELETE FROM folders WHERE id = $folder_id";
        $conn->query($delete_folder_sql);

        // Xóa xong thì tự động đẩy người dùng quay trở lại trang chủ Dashboard công việc
        header("Location: index.php");
        exit();
    } else {
        // Trường hợp sinh viên cố tình đổi ID trên URL để "hack" xóa bài của người khác hoặc của Admin
        die("<div style='padding:30px; color:red; font-family:sans-serif; font-weight:bold;'>
                <i class='fa-solid fa-triangle-exclamation'></i> Bạn không có quyền thực hiện hành động xóa thư viện này!
             </div>");
    }
} else {
    // Nếu truy cập file bừa bãi mà không truyền ID thì đẩy về trang chủ
    header("Location: index.php");
    exit();
}
?>