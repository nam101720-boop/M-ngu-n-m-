<?php
session_start();
include 'config/db.php';

// Kiểm tra bảo mật cơ bản đầu vào
if (!isset($_SESSION['user_id']) || !isset($_GET['id']) || !isset($_GET['new_name'])) {
    header("Location: index.php");
    exit();
}

$folder_id = intval($_GET['id']);
$new_name = trim($_GET['new_name']);
$new_name = $conn->real_escape_string($new_name);

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Tạo mô tả mới cập nhật đồng bộ theo tên mới sửa
$new_description = "Bộ sưu tập các bài học về " . $new_name;

// PHÂN QUYỀN BẢO MẬT BACKEND: Admin sửa được mọi thứ, Sinh viên chỉ được sửa bài của mình tạo
if ($user_role === 'admin') {
    $sql = "UPDATE folders SET name = '$new_name', description = '$new_description' WHERE id = $folder_id";
} else {
    $sql = "UPDATE folders SET name = '$new_name', description = '$new_description' WHERE id = $folder_id AND user_id = $user_id";
}

$conn->query($sql);

// Sửa đổi hoàn tất, chuyển hướng người dùng quay trở lại Dashboard chính
header("Location: index.php");
exit();
?>