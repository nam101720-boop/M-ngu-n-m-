<?php 
include 'config/db.php'; 

$exam_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 1. Lấy thông tin đề thi
$exam_query = $conn->query("SELECT * FROM exams WHERE id = $exam_id");
$exam = $exam_query->fetch_assoc();

if (!$exam) {
    die("Không tìm thấy đề thi!");
}

// 2. Lấy danh sách câu hỏi (Xáo trộn ngẫu nhiên để chống gian lận)
// Lưu ý: Đổi tên cột 'question' thành 'question_text' nếu DB của bạn lỗi cột này nhé. Ở đây mình giữ nguyên 'question' theo file cũ của bạn.
$questions_query = $conn->query("SELECT * FROM exam_questions WHERE exam_id = $exam_id ORDER BY RAND()");
$questions = [];
while($row = $questions_query->fetch_assoc()) {
    $questions[] = $row;
}

if (empty($questions)) {
    die("Đề thi này chưa có câu hỏi nào. Vui lòng quay lại sau!");
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?php echo $exam['title']; ?> - BiBotFlip Exam</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { 
            --primary: #6366f1; 
            --primary-hover: #4f46e5;
            --bg: #f8fafc; 
            --text: #1e293b; 
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
        }
        * { box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding: 20px; }
        
        /* Layout chia hai cột */
        .main-layout { display: flex; max-width: 1200px; margin: 30px auto; gap: 25px; align-items: flex-start; }
        
        /* Cột bên trái: Nội dung câu hỏi */
        .exam-container { flex: 1; background: white; padding: 40px; border-radius: 24px; box-shadow: 0 10px 25px rgba(0,0,0,0.02); border: 1px solid #f1f5f9; }
        
        /* Cột bên phải: Danh sách câu hỏi tiện ích */
        .sidebar-container { width: 320px; background: white; padding: 30px; border-radius: 24px; box-shadow: 0 10px 25px rgba(0,0,0,0.02); border: 1px solid #f1f5f9; position: sticky; top: 20px; }

        .exam-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; border-bottom: 2px solid #f1f5f9; padding-bottom: 20px; }
        .timer { background: #fee2e2; color: var(--danger); padding: 10px 20px; border-radius: 12px; font-weight: 800; font-size: 18px; display: flex; align-items: center; gap: 8px; }
        
        /* Nút thoát */
        .btn-exit { background: #f1f5f9; color: #64748b; border: 1px solid #cbd5e1; padding: 10px 18px; border-radius: 12px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 14px; }
        .btn-exit:hover { background: #fef2f2; color: var(--danger); border-color: #fca5a5; }

        /* Câu hỏi */
        .question-box { display: none; }
        .question-box.active { display: block; animation: fadeIn 0.4s ease; }
        .q-text { font-size: 22px; font-weight: 700; color: var(--text); margin-bottom: 25px; line-height: 1.4; }
        
        /* Đáp án */
        .options { display: grid; grid-template-columns: 1fr; gap: 12px; }
        .option-item { 
            padding: 18px 25px; border: 2px solid #f1f5f9; border-radius: 15px; 
            cursor: pointer; transition: 0.2s; display: flex; align-items: center; gap: 15px; font-weight: 600;
        }
        .option-item:hover { border-color: var(--primary); background: #f5f3ff; }
        .option-item.selected { background: var(--primary); color: white; border-color: var(--primary); }
        .option-label { width: 30px; height: 30px; background: #eee; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; color: var(--text); }
        .selected .option-label { background: rgba(255,255,255,0.2); color: white; }

        /* Khối chức năng điều hướng */
        .exam-footer { display: flex; justify-content: space-between; margin-top: 40px; align-items: center; }
        .btn-nav { padding: 12px 22px; border-radius: 12px; border: none; font-weight: 700; cursor: pointer; transition: 0.2s; font-size: 15px; }
        .btn-prev { background: #e2e8f0; color: #64748b; }
        .btn-next { background: var(--primary); color: white; }
        .btn-next:hover { background: var(--primary-hover); }
        .btn-submit { background: var(--success); color: white; display: none; }

        /* Nút đánh dấu làm sau */
        .btn-bookmark { background: #fffbeb; color: var(--warning); border: 2px solid #fde68a; }
        .btn-bookmark:hover { background: #fef3c7; }
        .btn-bookmark.bookmarked { background: var(--warning); color: white; border-color: var(--warning); }

        /* Grid hiển thị số câu hỏi bên Sidebar */
        .question-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin-top: 20px; }
        .grid-number { 
            height: 42px; border-radius: 10px; background: #f1f5f9; color: #64748b; 
            display: flex; align-items: center; justify-content: center; 
            font-weight: 700; font-size: 14px; cursor: pointer; border: 2px solid transparent;
        }
        .grid-number:hover { border-color: var(--primary); }
        .grid-number.current { border-color: var(--text); background: #e2e8f0; color: var(--text); }
        .grid-number.answered { background: var(--success) !important; color: white !important; }
        .grid-number.review { background: var(--warning) !important; color: white !important; }

        /* Giao diện kết quả màn hình đơn */
        .result-container { max-width: 600px; margin: 60px auto; background: white; padding: 50px; border-radius: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.05); text-align: center; display: none; }
        .score-circle { width: 140px; height: 140px; border-radius: 50%; background: var(--primary); color: white; display: flex; flex-direction: column; align-items: center; justify-content: center; margin: 0 auto 25px; box-shadow: 0 10px 20px rgba(99, 102, 241, 0.2); }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body>

<!-- GIAO DIỆN LÀM BÀI -->
<div class="main-layout" id="exam-ui">
    <!-- Cột chính bên trái -->
    <div class="exam-container">
        <div class="exam-header">
            <div>
                <h2 style="margin:0; font-size: 24px; font-weight: 800;"><?php echo htmlspecialchars($exam['title']); ?></h2>
                <span id="progress-text" style="color:#94a3b8; font-weight:600; display:inline-block; margin-top:5px;">Câu hỏi 1 / <?php echo count($questions); ?></span>
            </div>
            
            <div style="display: flex; align-items: center; gap: 12px;">
                <div class="timer"><i class="fa-solid fa-clock"></i> <span id="time-left">00:00</span></div>
                <!-- THÊM NÚT THOÁT -->
                <button type="button" onclick="exitExam();" class="btn-exit">
                    <i class="fa-solid fa-right-from-bracket"></i> Thoát
                </button>
            </div>
        </div>

        <form id="quiz-form">
            <?php foreach($questions as $index => $q): ?>
            <div class="question-box <?php echo $index === 0 ? 'active' : ''; ?>" data-index="<?php echo $index; ?>" id="qbox-<?php echo $index; ?>">
                <p class="q-text"><?php echo ($index + 1) . ". " . htmlspecialchars($q['question']); ?></p>
                <div class="options">
                    <label class="option-item" onclick="selectOption(<?php echo $index; ?>)">
                        <input type="radio" name="q<?php echo $q['id']; ?>" value="A" style="display:none;" data-correct="<?php echo $q['correct_option']; ?>">
                        <span class="option-label">A</span> <?php echo htmlspecialchars($q['option_a']); ?>
                    </label>
                    <label class="option-item" onclick="selectOption(<?php echo $index; ?>)">
                        <input type="radio" name="q<?php echo $q['id']; ?>" value="B" style="display:none;" data-correct="<?php echo $q['correct_option']; ?>">
                        <span class="option-label">B</span> <?php echo htmlspecialchars($q['option_b']); ?>
                    </label>
                    <label class="option-item" onclick="selectOption(<?php echo $index; ?>)">
                        <input type="radio" name="q<?php echo $q['id']; ?>" value="C" style="display:none;" data-correct="<?php echo $q['correct_option']; ?>">
                        <span class="option-label">C</span> <?php echo htmlspecialchars($q['option_c']); ?>
                    </label>
                    <label class="option-item" onclick="selectOption(<?php echo $index; ?>)">
                        <input type="radio" name="q<?php echo $q['id']; ?>" value="D" style="display:none;" data-correct="<?php echo $q['correct_option']; ?>">
                        <span class="option-label">D</span> <?php echo htmlspecialchars($q['option_d']); ?>
                    </label>
                </div>
            </div>
            <?php endforeach; ?>

            <div class="exam-footer">
                <button type="button" class="btn-nav btn-prev" onclick="changeQuestion(-1)" id="prev-btn" disabled>Câu trước</button>
                
                <!-- THÊM NÚT ĐÁNH DẤU LÀM SAU -->
                <button type="button" class="btn-nav btn-bookmark" onclick="toggleBookmark()" id="bookmark-btn">
                    <i class="fa-regular fa-bookmark"></i> Đánh dấu làm sau
                </button>
                
                <button type="button" class="btn-nav btn-next" onclick="changeQuestion(1)" id="next-btn">Câu tiếp theo</button>
                <button type="button" class="btn-nav btn-submit" onclick="submitExam()" id="submit-btn">Nộp bài thi</button>
            </div>
        </form>
    </div>

    <!-- CỘT PHẢI SIDEBAR: THỐNG KÊ SỐ CÂU HỎI -->
    <div class="sidebar-container">
        <h3 style="margin-top:0; font-size:18px; font-weight:800; color:var(--text);">Bảng tiến độ</h3>
        <!-- THÔNG TIN TIẾN ĐỘ LÀM ĐƯỢC BAO NHIÊU CÂU -->
        <p style="font-size:14px; font-weight:600; color:#64748b;" id="done-count-text">Đã làm: 0 / <?php echo count($questions); ?> câu</p>
        
        <div class="question-grid">
            <?php for($i = 0; $i < count($questions); $i++): ?>
                <div class="grid-number <?php echo $i === 0 ? 'current' : ''; ?>" id="grid-num-<?php echo $i; ?>" onclick="jumpToQuestion(<?php echo $i; ?>)">
                    <?php echo $i + 1; ?>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</div>

<!-- GIAO DIỆN MÀN HÌNH KẾT QUẢ -->
<div class="result-container" id="result-screen">
    <div class="score-circle">
        <span style="font-size: 38px; font-weight: 800;" id="final-score">0</span>
        <span style="font-size: 13px; font-weight:600; opacity:0.9;">Điểm số</span>
    </div>
    <h2 id="result-msg" style="font-size:26px; font-weight:800; margin-bottom:10px;">Hoàn thành bài thi!</h2>
    <p style="color: #64748b; font-size:16px; font-weight:600;" id="correct-count">Bạn trả lời đúng 0 / 0 câu.</p>
    <a href="online_exams.php" class="btn-nav btn-next" style="display:inline-block; margin-top:25px; text-decoration:none; padding: 14px 30px;">Quay lại danh sách đề</a>
</div>

<script>
    let currentQ = 0;
    const totalQ = <?php echo count($questions); ?>;
    let timeLeft = <?php echo $exam['duration']; ?> * 60;
    
    // Mảng lưu trạng thái câu hỏi đã đánh dấu làm sau hay chưa (false: chưa, true: rồi)
    let bookmarkedArray = new Array(totalQ).fill(false);

    // 1. Xử lý bộ đếm ngược thời gian
    const timerDisplay = document.getElementById('time-left');
    const countdown = setInterval(() => {
        let mins = Math.floor(timeLeft / 60);
        let secs = timeLeft % 60;
        timerDisplay.innerText = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        if (timeLeft <= 0) {
            clearInterval(countdown);
            submitExam();
        }
        timeLeft--;
    }, 1000);

    // 2. Click chọn đáp án
    document.querySelectorAll('.option-item').forEach(item => {
        item.addEventListener('click', function() {
            const parent = this.parentElement;
            parent.querySelectorAll('.option-item').forEach(i => i.classList.remove('selected'));
            this.classList.add('selected');
        });
    });

    // 3. Logic khi click chọn đáp án (cập nhật trạng thái ô vuông màu sắc)
    function selectOption(index) {
        // Nếu đang đánh dấu làm sau, việc chọn đáp án sẽ ưu tiên chuyển sang màu xanh lá đã làm
        bookmarkedArray[index] = false; 
        updateSidebarStatus();
    }

    // 4. Tính năng "Đánh dấu làm sau"
    function toggleBookmark() {
        // Đảo trạng thái ngược lại của câu hiện tại
        bookmarkedArray[currentQ] = !bookmarkedArray[currentQ];
        updateSidebarStatus();
        updateBookmarkButtonUI();
    }

    // Cập nhật giao diện nút Đánh dấu
    function updateBookmarkButtonUI() {
        const btn = document.getElementById('bookmark-btn');
        if (bookmarkedArray[currentQ]) {
            btn.classList.add('bookmarked');
            btn.innerHTML = `<i class="fa-solid fa-bookmark"></i> Đã đánh dấu`;
        } else {
            btn.classList.remove('bookmarked');
            btn.innerHTML = `<i class="fa-regular fa-bookmark"></i> Đánh dấu làm sau`;
        }
    }

    // 5. Đồng bộ màu sắc ô vuông Sidebar và đếm số câu đã làm
    function updateSidebarStatus() {
        let answeredCount = 0;
        
        for (let i = 0; i < totalQ; i++) {
            const gridNum = document.getElementById(`grid-num-${i}`);
            const qBox = document.getElementById(`qbox-${i}`);
            const isChecked = qBox.querySelector('input[type="radio"]:checked');

            // Reset class định dạng cũ
            gridNum.classList.remove('current', 'answered', 'review');

            if (i === currentQ) {
                gridNum.classList.add('current');
            }

            if (isChecked) {
                gridNum.classList.add('answered'); // Màu xanh lá
                answeredCount++;
            } else if (bookmarkedArray[i]) {
                gridNum.classList.add('review'); // Màu vàng cam
            }
        }

        // Hiển thị text đếm tiến độ: Đã làm X / Y câu
        document.getElementById('done-count-text').innerText = `Đã làm: ${answeredCount} / ${totalQ} câu`;
    }

    // 6. Chuyển đổi câu hỏi (Câu trước / Câu sau)
    function changeQuestion(step) {
        const boxes = document.querySelectorAll('.question-box');
        boxes[currentQ].classList.remove('active');
        currentQ += step;
        boxes[currentQ].classList.add('active');

        updateUIAfterNavigation();
    }

    // 7. Nhảy nhanh đến câu bất kỳ khi click ô số bên Sidebar
    function jumpToQuestion(targetIndex) {
        const boxes = document.querySelectorAll('.question-box');
        boxes[currentQ].classList.remove('active');
        currentQ = targetIndex;
        boxes[currentQ].classList.add('active');

        updateUIAfterNavigation();
    }

    // Cập nhật lại giao diện nút bấm, tiến độ sau khi chuyển câu
    function updateUIAfterNavigation() {
        document.getElementById('progress-text').innerText = `Câu hỏi ${currentQ + 1} / ${totalQ}`;
        document.getElementById('prev-btn').disabled = (currentQ === 0);
        
        if (currentQ === totalQ - 1) {
            document.getElementById('next-btn').style.display = 'none';
            document.getElementById('submit-btn').style.display = 'block';
        } else {
            document.getElementById('next-btn').style.display = 'block';
            document.getElementById('submit-btn').style.display = 'none';
        }

        updateSidebarStatus();
        updateBookmarkButtonUI();
    }

    // 8. Chức năng Nút Thoát
    function exitExam() {
        if (confirm("Bạn có chắc chắn muốn thoát không? Kết quả của bài thi này sẽ bị hủy bỏ hoàn toàn!")) {
            window.location.href = "online_exams.php";
        }
    }

    // 9. Tính điểm và Nộp bài
    function submitExam() {
        clearInterval(countdown);
        let correct = 0;
        const form = document.getElementById('quiz-form');
        const inputs = form.querySelectorAll('input[type="radio"]:checked');

        inputs.forEach(input => {
            if (input.value === input.getAttribute('data-correct')) {
                correct++;
            }
        });

        const score = ((correct / totalQ) * 10).toFixed(1);

        document.getElementById('exam-ui').style.display = 'none';
        document.getElementById('result-screen').style.display = 'block';
        document.getElementById('final-score').innerText = score;
        document.getElementById('correct-count').innerText = `Bạn trả lời đúng ${correct} / ${totalQ} câu.`;
        
        if (score >= 8) document.getElementById('result-msg').innerText = "Xuất sắc! 🎉";
        else if (score >= 5) document.getElementById('result-msg').innerText = "Làm tốt lắm! 👍";
        else document.getElementById('result-msg').innerText = "Cần cố gắng thêm nhé! 💪";
    }
</script>

</body>
</html>