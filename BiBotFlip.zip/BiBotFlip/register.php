<?php
include 'config/db.php';
session_start();

$error = "";
$success = "";

if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($conn, trim($_POST['username']));
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // 1. Kiểm tra độ khớp mật khẩu cơ bản
    if ($password !== $confirm_password) {
        $error = "Mật khẩu nhập lại không trùng khớp!";
    } else {
        // 2. Kiểm tra xem tên đăng nhập này đã bị trùng trong DB chưa
        $check_sql = "SELECT id FROM users WHERE username = '$username' LIMIT 1";
        $check_result = $conn->query($check_sql);

        if ($check_result && $check_result->num_rows > 0) {
            $error = "Tên đăng nhập này đã có người sử dụng!";
        } else {
            // Tự động sinh tên hiển thị cá nhân ngẫu nhiên dạng SVxxxxxx cho tài khoản mới
            $display_name = "SV" . rand(100000, 999999);
            $password_clean = mysqli_real_escape_string($conn, $password);

            // 3. Thực hiện chèn người dùng mới vào hệ thống với role mặc định là 'student'
            $ins_sql = "INSERT INTO users (username, password, role, display_name) 
                        VALUES ('$username', '$password_clean', 'student', '$display_name')";
            
            if ($conn->query($ins_sql) === TRUE) {
                $success = "Đăng ký thành công! Đang chuyển hướng...";
                // Đăng ký thành công thì tự động chuyển hướng về trang login sau 2 giây
                header("refresh:2; url=login.php");
            } else {
                $error = "Lỗi hệ thống khi đăng ký: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký tài khoản - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --bg: #f8fafc; --success-color: #10b981; }
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background: var(--bg); height: 100vh; margin: 0;
            display: flex; align-items: center; justify-content: center;
        }
        .login-card {
            background: white; padding: 40px; border-radius: 24px;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
            width: 100%; max-width: 400px; border: 1px solid #f1f5f9;
        }
        .logo { 
            text-align: center; color: var(--primary); 
            font-size: 30px; font-weight: 800; margin-bottom: 25px; 
        }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-weight: 700; margin-bottom: 8px; color: #1e293b; }
        .form-group input {
            width: 100%; padding: 12px 16px; border: 2px solid #f1f5f9;
            border-radius: 12px; outline: none; box-sizing: border-box;
        }
        .form-group input:focus { border-color: var(--primary); }
        .btn-register {
            width: 100%; background: var(--primary); color: white;
            border: none; padding: 14px; border-radius: 12px;
            font-weight: 800; cursor: pointer; font-size: 16px; margin-top: 10px;
        }
        .error-msg { background: #fef2f2; color: #ef4444; padding: 12px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; text-align: center; font-weight: 600; border: 1px solid #fee2e2; }
        .success-msg { background: #ecfdf5; color: var(--success-color); padding: 12px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; text-align: center; font-weight: 600; border: 1px solid #d1fae5; }
        .auth-links { text-align: center; margin-top: 25px; font-size: 13px; font-weight: 600; }
        .auth-links a { color: var(--primary); text-decoration: none; }
        .auth-links a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="logo"><i class="fa-solid fa-user-plus"></i> Đăng ký</div>
    
    <?php if(!empty($error)): ?>
        <div class="error-msg"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if(!empty($success)): ?>
        <div class="success-msg"><?php echo $success; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Tên đăng nhập mới</label>
            <input type="text" name="username" placeholder="Nhập tên tài khoản..." required>
        </div>
        <div class="form-group">
            <label>Mật khẩu</label>
            <input type="password" name="password" placeholder="Tối thiểu 6 ký tự..." required>
        </div>
        <div class="form-group">
            <label>Xác nhận lại mật khẩu</label>
            <input type="password" name="confirm_password" placeholder="Nhập lại mật khẩu phía trên..." required>
        </div>
        <button type="submit" name="register" class="btn-register">Tạo tài khoản</button>
    </form>

    <div class="auth-links">
        <span>Đã có tài khoản? </span><a href="login.php">Đăng nhập ngay</a>
    </div>
</div>

</body>
</html>