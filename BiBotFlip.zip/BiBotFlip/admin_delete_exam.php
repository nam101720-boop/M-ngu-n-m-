<?php
session_start();
include 'config/db.php';

// Bảo mật: Chỉ admin mới được quyền xóa
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Bạn không có quyền thực hiện hành động này!");
}

if (isset($_GET['id'])) {
    $exam_id = intval($_GET['id']);

    // 1. Xóa tất cả các câu hỏi thuộc đề thi này trước để tránh lỗi khóa ngoại (Foreign Key)
    $sql_delete_questions = "DELETE FROM exam_questions WHERE exam_id = $exam_id";
    $conn->query($sql_delete_questions);

    // 2. Xóa đề thi khỏi bảng exams
    $sql_delete_exam = "DELETE FROM exams WHERE id = $exam_id";
    
    if ($conn->query($sql_delete_exam)) {
        header("Location: online_exams.php");
        exit();
    } else {
        echo "Lỗi khi xóa đề thi: " . $conn->error;
    }
} else {
    header("Location: online_exams.php");
    exit();
}
?>