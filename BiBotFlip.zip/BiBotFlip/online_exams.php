<?php 
include 'config/db.php'; 

// Truy vấn danh sách đề thi từ bảng exams
$sql = "SELECT e.*, 
        (SELECT COUNT(q.id) FROM exam_questions q WHERE q.exam_id = e.id) as q_count 
        FROM exams e 
        ORDER BY e.created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đề thi Online - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --bg: #f8fafc; --text: #1e293b; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding: 40px; }
        .container { max-width: 1000px; margin: auto; }
        
        /* Header & Action Bar */
        .header-section { display: flex; justify-content: space-between; align-items: center; margin-bottom: 40px; }
        .header-title h1 { font-size: 32px; font-weight: 800; margin: 0; color: var(--text); }
        
        /* Nút thêm đề thi mới */
        .btn-add-exam {
            background: white;
            color: var(--primary);
            padding: 12px 24px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 2px solid var(--primary);
            transition: 0.3s;
        }
        .btn-add-exam:hover {
            background: var(--primary);
            color: white;
            box-shadow: 0 10px 15px -3px rgba(99, 102, 241, 0.3);
        }

        /* Grid */
        .exam-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 25px; }
        
        .exam-card { 
            background: white; padding: 30px; border-radius: 24px; 
            border: 1px solid #f1f5f9; position: relative;
            transition: 0.3s ease; text-decoration: none; color: inherit;
            display: flex; flex-direction: column;
        }
        .exam-card:hover { transform: translateY(-10px); box-shadow: 0 20px 25px -5px rgba(0,0,0,0.05); border-color: var(--primary); }
        
        .exam-icon { width: 50px; height: 50px; background: #eef2ff; color: var(--primary); border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 20px; }
        .exam-title { font-size: 20px; font-weight: 800; margin: 0 0 10px 0; }
        .exam-desc { font-size: 14px; color: #64748b; margin-bottom: 25px; line-height: 1.5; flex-grow: 1; }
        
        .exam-meta { display: flex; gap: 15px; border-top: 1px solid #f8fafc; padding-top: 20px; font-size: 13px; font-weight: 600; color: #94a3b8; }
        .btn-start { background: var(--primary); color: white; border-radius: 12px; padding: 12px; text-align: center; margin-top: 20px; font-weight: 700; }
    </style>
</head>
<body>

<div class="container">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="text-decoration:none; color:#64748b; font-weight:700;"><i class="fa-solid fa-arrow-left"></i> Trang chủ</a>
    </div>

    <div class="header-section">
    <div class="header-title">
        <h1>Đề thi Online</h1>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="admin_import_exam.php" class="btn-add-exam" style="border-color: #10b981; color: #10b981;">
            <i class="fa-solid fa-file-import"></i> Nhập từ file
        </a>
        <a href="admin_add_exam.php" class="btn-add-exam">
            <i class="fa-solid fa-plus"></i> Thêm đề thi
        </a>
    </div>
</div>
    <div class="exam-grid">
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <a href="take_exam.php?id=<?php echo $row['id']; ?>" class="exam-card">
                    <div class="exam-icon"><i class="fa-solid fa-file-lines"></i></div>
                    <h3 class="exam-title"><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p class="exam-desc"><?php echo htmlspecialchars($row['description']); ?></p>
                    <div class="exam-meta">
                        <span><i class="fa-solid fa-circle-question"></i> <?php echo $row['q_count']; ?> câu</span>
                        <span><i class="fa-solid fa-clock"></i> <?php echo $row['duration']; ?> phút</span>
                    </div>
                    <div class="btn-start">Bắt đầu thi</div>
                </a>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="grid-column: 1/-1; text-align: center; padding: 80px; background: white; border-radius: 30px; border: 2px dashed #e2e8f0;">
                <i class="fa-solid fa-folder-open" style="font-size: 40px; color: #cbd5e1; margin-bottom: 20px;"></i>
                <p style="color: #94a3b8;">Chưa có đề thi nào. Hãy nhấn "Thêm đề thi mới" để bắt đầu!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>