<?php 
include 'config/db.php'; 

// Lấy lesson_id và f_id từ URL truyền sang
$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : 0;
$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0; 

// Truy vấn dữ liệu luyện tập
$sql = "SELECT term, definition, example FROM cards WHERE lesson_id = $lesson_id ORDER BY RAND()";
$result = $conn->query($sql);
$cards = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Luyện tập - BiBotFlip</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #10b981; --bg: #f8fafc; --white: #ffffff; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
        
        .practice-container { width: 500px; background: var(--white); padding: 40px; border-radius: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.05); text-align: center; }
        
        .hint-def { font-size: 24px; font-weight: 800; color: #1e293b; margin-bottom: 10px; }
        .hint-ex { font-size: 16px; color: #64748b; font-style: italic; margin-bottom: 30px; line-height: 1.5; }
        
        input[type="text"] {
            width: 100%; padding: 15px; border: 2px solid #e2e8f0; border-radius: 15px;
            font-size: 18px; text-align: center; outline: none; transition: 0.3s;
        }
        input[type="text"]:focus { border-color: var(--primary); box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.1); }
        input.error { border-color: #ef4444; background: #fef2f2; animation: shake 0.5s; }
        input.success { border-color: #10b981; background: #f0fdf4; }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }

        .feedback { margin-top: 20px; font-weight: 700; min-height: 24px; }
        .btn-exit { position: absolute; top: 30px; left: 30px; text-decoration: none; color: #64748b; font-weight: 700; }
        
        .progress-bar { width: 100%; height: 8px; background: #e2e8f0; border-radius: 10px; margin-bottom: 30px; overflow: hidden; }
        .progress-fill { height: 100%; background: var(--primary); transition: 0.3s; width: 0%; }
    </style>
</head>
<body>

    <a href="view_folder.php?id=<?php echo $f_id; ?>" class="btn-exit">
    <i class="fa-solid fa-xmark"></i> Thoát luyện tập
</a>

    <div class="practice-container">
        <div class="progress-bar"><div class="progress-fill" id="progress"></div></div>
        
        <div id="game-area">
            <div class="hint-def" id="display-def">...</div>
            <div class="hint-ex" id="display-ex">...</div>
            
            <input type="text" id="user-input" placeholder="Gõ từ tiếng Anh tương ứng..." autocomplete="off">
            <div class="feedback" id="feedback"></div>
        </div>
        
        <div id="result-area" style="display:none;">
            <i class="fa-solid fa-circle-check" style="font-size: 60px; color: var(--primary);"></i>
            <h2>Xuất sắc!</h2>
            <p>Bạn đã hoàn thành tất cả các từ trong bài tập này.</p>
            <a href="view_folder.php?id=<?php echo $f_id; ?>" style="display:inline-block; margin-top:20px; padding:12px 30px; background:var(--primary); color:white; text-decoration:none; border-radius:12px; font-weight:700;">Tiếp tục bài khác</a>
        </div>
    </div>

    <script>
        const cards = <?php echo json_encode($cards); ?>;
        let index = 0;

        const input = document.getElementById('user-input');
        const feedback = document.getElementById('feedback');

        function updateUI() {
            if(index >= cards.length) {
                document.getElementById('game-area').style.display = 'none';
                document.getElementById('result-area').style.display = 'block';
                return;
            }

            const current = cards[index];
            // Hiển thị nghĩa và ví dụ ẩn từ tiếng Anh
            document.getElementById('display-def').innerText = current.definition;
            
            // Ẩn từ vựng trong câu ví dụ (thay bằng ____)
            let hiddenEx = current.example || "";
            // Xóa phần phiên âm trong term nếu có để so sánh đáp án
            let cleanTerm = current.term.split('/')[0].trim(); 
            
            document.getElementById('display-ex').innerText = hiddenEx;
            input.value = "";
            input.className = "";
            feedback.innerText = "";
            
            const progress = ((index) / cards.length) * 100;
            document.getElementById('progress').style.width = progress + "%";
        }

        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                checkAnswer();
            }
        });

        function checkAnswer() {
    const currentCard = cards[index];
    const currentTerm = currentCard.term.split('/')[0].trim().toLowerCase();
    const userTerm = input.value.trim().toLowerCase();
    
    let status = "";

    if (userTerm === currentTerm) {
        input.className = "success";
        status = "correct";
        // Chuyển câu sau 1s
        setTimeout(() => { index++; updateUI(); }, 1000);
    } else {
        input.className = "error";
        status = "wrong";
        // Hiện đáp án cho người dùng thấy
        feedback.innerHTML = `<span style='color:#ef4444'>Sai rồi! Đáp án: ${currentCard.term}</span>`;
    }

    // GỬI DỮ LIỆU CẬP NHẬT DATABASE (AJAX)
    fetch('update_mastery.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `card_id=${currentCard.id}&status=${status}`
    });
}

        updateUI();
    </script>
</body>
</html>