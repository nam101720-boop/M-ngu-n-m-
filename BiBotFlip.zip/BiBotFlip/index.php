<?php 
// 1. Kích hoạt Session để lấy thông tin phân quyền thực tế
session_start();
include 'config/db.php'; 

// Kiểm tra bảo mật: Nếu chưa đăng nhập thì chặn lại đẩy về trang login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Đồng bộ thông tin người dùng từ Session đã xử lý ở trang login
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['display_name']; 
$user_initials = $_SESSION['initials'];
$user_role = $_SESSION['role'];

$is_admin = ($user_role === 'admin');

// 2. XỬ LÝ TRUY VẤN TÁCH LUỒNG DỮ LIỆU ĐỂ HIỂN THỊ 2 KHU VỰC CHO CẢ ADMIN VÀ SINH VIÊN
if ($is_admin) {
    // Luồng ADMIN - KHU VỰC 1: Chỉ lấy các bộ thẻ do chính Admin này tạo (Đồ của hệ thống chuẩn)
    $sql_admin_own = "SELECT f.*, 
                     (SELECT COUNT(l.id) FROM lessons l WHERE l.folder_id = f.id) as total_lessons 
                     FROM folders f
                     WHERE f.user_id = $user_id OR f.user_id = 999 OR f.user_id = 0 OR f.user_id = 1
                     ORDER BY f.created_at DESC";
    $result_admin_own = $conn->query($sql_admin_own);

    // Luồng ADMIN - KHU VỰC 2: Gom tất cả các bộ thẻ Cá nhân của toàn bộ Sinh viên khác để quản lý giám sát
    // JOIN với bảng users để lấy đúng tên hiển thị và mã SV thực tế của sinh viên đó
    $sql_student_all = "SELECT f.*, u.display_name as sv_name, u.username as sv_code
                        FROM folders f
                        LEFT JOIN users u ON f.user_id = u.id
                        WHERE f.user_id != $user_id AND f.user_id != 999 AND f.user_id != 0 AND f.user_id != 1 AND f.user_id IS NOT NULL
                        ORDER BY f.created_at DESC";
    $result_student_all = $conn->query($sql_student_all);

} else {
    // Luồng SINH VIÊN: Giữ nguyên logic chạy chuẩn đang có của em
    
    // Truy vấn 1: "Thư viện của bạn" - Chỉ lấy bộ thẻ do chính sinh viên này tạo
    $sql_personal = "SELECT f.*, 
                    (SELECT COUNT(l.id) FROM lessons l WHERE l.folder_id = f.id) as total_lessons 
                    FROM folders f 
                    WHERE f.user_id = $user_id
                    ORDER BY f.created_at DESC";
    $result_personal = $conn->query($sql_personal);

    // Truy vấn 2: "Thư viện đề xuất" - Lấy toàn bộ thư mục của ADMIN hoặc hệ thống tạo sẵn
    $sql_system = "SELECT f.*, 
            (SELECT COUNT(l.id) FROM lessons l WHERE l.folder_id = f.id) as total_lessons 
            FROM folders f 
            WHERE f.user_id != $user_id OR f.user_id IS NULL
            ORDER BY f.created_at DESC";
    $result_system = $conn->query($sql_system);
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BiBotFlip - Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --primary-hover: #4f46e5;
            --bg: #f8fafc;
            --sidebar-bg: #ffffff;
            --card-bg: #ffffff;
            --text-title: #1e293b;
            --text-body: #64748b;
            --border: #f1f5f9;
            --danger: #ef4444;
            --success: #10b981;
        }

        * { box-sizing: border-box; transition: all 0.2s ease-in-out; }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: var(--bg); 
            margin: 0; display: flex; min-height: 100vh;
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: 280px; background: var(--sidebar-bg);
            border-right: 1px solid var(--border);
            display: flex; flex-direction: column;
            position: fixed; height: 100vh; padding: 25px 15px; z-index: 100;
        }

        .logo {
            font-size: 26px; font-weight: 800; color: var(--primary);
            padding: 0 15px 30px 15px; display: flex; align-items: center; gap: 10px;
        }

        .sidebar-nav { flex: 1; display: flex; flex-direction: column; overflow-y: auto; }

        .menu-label {
            font-size: 11px; text-transform: uppercase; color: #94a3b8;
            font-weight: 700; margin: 20px 0 10px 15px; letter-spacing: 1px;
        }

        .menu-item {
            display: flex; align-items: center; padding: 12px 15px;
            color: var(--text-body); text-decoration: none; border-radius: 12px;
            margin-bottom: 4px; font-weight: 600;
        }

        .menu-item i { margin-right: 12px; width: 20px; font-size: 18px; text-align: center; }
        .menu-item:hover, .menu-item.active { background: #f1f5f9; color: var(--primary); }

        .sidebar-footer { margin-top: auto; padding-top: 20px; border-top: 1px solid var(--border); }

        .user-profile {
            display: flex; align-items: center; gap: 12px; padding: 12px;
            text-decoration: none; color: var(--text-title); border-radius: 12px;
        }
        .user-profile:hover { background: #f1f5f9; }

        .avatar {
            width: 40px; height: 40px; background: var(--primary);
            color: white; border-radius: 50%; display: flex;
            align-items: center; justify-content: center; font-weight: 800;
        }

        .logout-link { color: var(--danger); }
        .logout-link:hover { background: #fef2f2; }

        /* --- MAIN CONTENT --- */
        .main-content { margin-left: 280px; flex: 1; padding: 40px; }

        .header-section { margin-bottom: 35px; }
        .header-section h1 { font-size: 28px; margin: 0; color: var(--text-title); font-weight: 800; }
        .header-section p { color: var(--text-body); margin-top: 5px; }

        /* Form Thêm Bộ Thẻ */
        .add-box {
            background: var(--card-bg); padding: 20px; border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); margin-bottom: 25px;
            border: 1px solid var(--border);
        }
        .add-box form { display: flex; gap: 12px; }
        .add-box input {
            flex: 1; padding: 14px 20px; border: 2px solid var(--border);
            border-radius: 12px; outline: none; font-size: 15px;
        }
        .add-box input:focus { border-color: var(--primary); }
        .add-box button {
            background: var(--primary); color: white; border: none;
            padding: 0 25px; border-radius: 12px; font-weight: 700; cursor: pointer;
        }
        .add-box button:hover { background: var(--primary-hover); }

        /* Thanh tìm kiếm nhanh */
        .search-box { position: relative; margin-bottom: 40px; }
        .search-box input {
            width: 100%; padding: 14px 20px 14px 50px; border: 2px solid var(--border);
            border-radius: 12px; outline: none; font-size: 15px; background: var(--card-bg);
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.03);
        }
        .search-box input:focus { border-color: var(--primary); }
        .search-box i { position: absolute; left: 20px; top: 50%; transform: translateY(-50%); color: var(--text-body); font-size: 18px; }

        /* Đề mục phân chia khu vực */
        .section-title { font-size: 22px; font-weight: 800; color: var(--text-title); margin: 30px 0 20px 0; display: flex; align-items: center; gap: 10px; }

        /* Folder Grid */
        .folder-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }

        .folder-card {
            background: var(--card-bg); border-radius: 20px; padding: 25px;
            text-decoration: none; border: 1px solid var(--border);
            display: flex; flex-direction: column;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
            position: relative;
        }
        .folder-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
            border-color: var(--primary);
        }

        .folder-card h3 { 
            margin: 10px 0 8px 0; 
            font-size: 22px; 
            color: var(--text-title); 
            font-weight: 800; 
            padding-right: 70px; 
            line-height: 1.3;
        }
        .folder-card p { font-size: 14px; color: var(--text-body); margin-bottom: 20px; flex: 1; line-height: 1.5; }

        /* Định dạng cho thẻ Tag Cá nhân / Hệ thống */
        .type-badge {
            align-self: flex-start; font-size: 10px; font-weight: 800;
            text-transform: uppercase; padding: 4px 10px; border-radius: 6px;
            margin-bottom: 5px;
        }
        .type-badge.system { background: #e0e7ff; color: var(--primary); }
        .type-badge.personal { background: #fef3c7; color: #d97706; }

        /* Nút xóa thư viện ở góc phải trên */
        .btn-delete-folder {
            position: absolute; top: 22px; right: 22px;
            width: 32px; height: 32px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            color: #94a3b8; background: #f8fafc;
            font-size: 14px; cursor: pointer; z-index: 10;
            border: 1px solid #e2e8f0;
        }
        .btn-delete-folder:hover {
            background: #fee2e2; color: var(--danger); border-color: #fca5a5;
            transform: scale(1.1);
        }

        /* Nút sửa thư viện */
        .btn-edit-folder {
            position: absolute; top: 22px; right: 60px;
            width: 32px; height: 32px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            color: #94a3b8; background: #f8fafc;
            font-size: 13px; cursor: pointer; z-index: 10;
            border: 1px solid #e2e8f0;
        }
        .btn-edit-folder:hover {
            background: #eef2ff; color: var(--primary); border-color: #c7d2fe;
            transform: scale(1.1);
        }

        .card-meta { display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #f8fafc; padding-top: 15px; }
        .count { font-size: 13px; font-weight: 600; color: var(--text-body); }
        .action-text { color: var(--primary); font-weight: 700; font-size: 14px; }

        @media (max-width: 900px) {
            .sidebar { width: 80px; padding: 25px 10px; }
            .logo span, .menu-label, .menu-item span, .user-profile div { display: none; }
            .main-content { margin-left: 80px; }
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo"><i class="fa-solid fa-bolt"></i> <span>BiBotFlip</span></div>
        <div class="sidebar-nav">
            <a href="index.php" class="menu-item active"><i class="fa-solid fa-house"></i> <span>Trang chủ</span></a>
            <div class="menu-label">Thư viện của bạn</div>
            <a href="all_cards.php" class="menu-item"><i class="fa-solid fa-book-bookmark"></i> <span>Tất cả Flashcard</span></a>
            <a href="online_exams.php" class="menu-item"><i class="fa-solid fa-folder-plus"></i> <span>Đề thi online</span></a>
            <div class="menu-label">Thẻ ghi nhớ</div>
            <a href="all_cards.php?filter=mastered" class="menu-item" style="color: var(--success);"><i class="fa-solid fa-circle-check"></i> <span>Đã ghi nhớ</span></a>
            <a href="all_cards.php?filter=unlearned" class="menu-item" style="color: var(--danger);"><i class="fa-solid fa-circle-minus"></i> <span>Chưa ghi nhớ</span></a>
            <div class="sidebar-footer">
                <div class="menu-label">Tài khoản</div>
                <a href="profile.php" class="user-profile">
                    <div class="avatar"><?php echo $_SESSION['initials']; ?></div>
                    <div style="display: flex; flex-direction: column;">
                        <span style="font-weight: 700; font-size: 14px;"><?php echo $_SESSION['display_name']; ?></span>
                        <span style="font-size: 11px; color: var(--text-body);"><?php echo ($is_admin) ? 'Chế độ Quản trị' : 'Thành viên học tập'; ?></span>
                    </div>
                </a>
                <a href="logout.php" class="menu-item logout-link"><i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Đăng xuất</span></a>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="header-section">
            <h1>Khám phá Thư viện</h1>
            <p>Chào mừng bạn quay trở lại. Hôm nay bạn muốn học gì?</p>
        </div>

        <div class="add-box">
            <form action="add_folder.php" method="POST">
                <input type="text" name="folder_name" placeholder="Nhập tên bộ thẻ mới (VD: Tiếng Anh giao tiếp)..." required>
                <button type="submit" name="submit">Tạo ngay</button>
            </form>
        </div>

        <div class="search-box">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="searchInput" placeholder="Tìm kiếm nhanh thư viện (Nhập tên bộ thẻ cần tìm)...">
        </div>

        <?php if ($is_admin): ?>
            
            <div class="section-title"><i class="fa-solid fa-star" style="color: var(--primary);"></i> Thư viện của bạn</div>
            <div class="folder-grid" style="margin-bottom: 50px;">
                <?php if ($result_admin_own->num_rows > 0): ?>
                    <?php while($row = $result_admin_own->fetch_assoc()): ?>
                        <a href="view_folder.php?id=<?php echo $row['id']; ?>" class="folder-card">
                            <span class="type-badge system">Hệ thống</span>
                            <span class="btn-edit-folder" title="Sửa tên thư viện" onclick="event.preventDefault(); let newName = prompt('Nhập tên mới cho thư viện:', '<?php echo htmlspecialchars($row['name']); ?>'); if(newName) { window.location.href='edit_folder.php?id=<?php echo $row['id']; ?>&new_name=' + encodeURIComponent(newName); }"><i class="fa-solid fa-pen"></i></span>
                            <span class="btn-delete-folder" title="Xóa thư viện này" onclick="event.preventDefault(); if(confirm('Bạn có chắc chắn muốn xóa thư viện này? Tất cả bài học và thẻ bên trong cũng sẽ bị mất!')) { window.location.href='delete_folder.php?id=<?php echo $row['id']; ?>'; }"><i class="fa-solid fa-trash-can"></i></span>
                            <h3 class="folder-title"><?php echo htmlspecialchars($row['name']); ?></h3>
                            <p><?php echo htmlspecialchars($row['description'] ?? 'Nhấn để xem các bài học trong bộ thẻ này.'); ?></p>
                            <div class="card-meta">
                                <span class="count"><i class="fa-solid fa-layer-group"></i> <?php echo $row['total_lessons']; ?> bài học</span>
                                <span class="action-text">Quản lý <i class="fa-solid fa-chevron-right"></i></span>
                            </div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style='grid-column: 1/-1; padding: 25px; background: #ffffff; border-radius:16px; border: 1px dashed #cbd5e1; color: var(--text-body); font-size:14px;'>Bạn chưa tạo bộ thẻ hệ thống nào.</div>
                <?php endif; ?>
            </div>

            <div class="section-title"><i class="fa-solid fa-user-graduate" style="color: #f59e0b;"></i> Thư viện của sinh viên đóng góp</div>
            <div class="folder-grid">
                <?php if ($result_student_all->num_rows > 0): ?>
                    <?php while($row = $result_student_all->fetch_assoc()): ?>
                        <?php 
                        // Lấy tên sinh viên và mã tài khoản động từ DB ra để in trực tiếp lên nhãn Badge phụ hoặc tiêu đề mô tả
                        $sv_identifier = htmlspecialchars($row['sv_name'] ?? 'Ẩn danh') . " (" . htmlspecialchars($row['sv_code'] ?? 'Mã SV') . ")";
                        ?>
                        <a href="view_folder.php?id=<?php echo $row['id']; ?>" class="folder-card" style="border-left: 4px solid #f59e0b;">
                            <span class="type-badge personal" style="font-size: 9px; padding: 4px 8px;">Tác giả: <?php echo $sv_identifier; ?></span>
                            
                            <span class="btn-delete-folder" title="Xóa thư viện này (Quyền lực Admin)" onclick="event.preventDefault(); if(confirm('Bạn có chắc chắn muốn xóa thư viện của sinh viên này không?')) { window.location.href='delete_folder.php?id=<?php echo $row['id']; ?>'; }"><i class="fa-solid fa-trash-can"></i></span>
                            <h3 class="folder-title"><?php echo htmlspecialchars($row['name']); ?></h3>
                            <p style="color: var(--primary); font-weight: 700; font-size: 13px; margin-bottom: 10px;">Thư mục Cá nhân của <?php echo htmlspecialchars($row['sv_name'] ?? 'Học viên'); ?></p>
                            <p><?php echo htmlspecialchars($row['description'] ?? 'Nhấn để xem nội dung bài học sinh viên biên soạn.'); ?></p>
                            <div class="card-meta">
                                <span class="count"><i class="fa-solid fa-user"></i> Người tạo: <?php echo htmlspecialchars($row['sv_code'] ?? 'SV'); ?></span>
                                <span class="action-text" style="color: #f59e0b;">Kiểm tra <i class="fa-solid fa-chevron-right"></i></span>
                            </div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style='grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-body);'><i class='fa-solid fa-folder-open' style='font-size: 40px; margin-bottom: 10px;'></i><p>Hiện chưa có sinh viên nào tự tạo bộ thẻ cá nhân trên hệ thống.</p></div>
                <?php endif; ?>
            </div>

        <?php else: ?>
            
            <div class="section-title"><i class="fa-solid fa-user-graduate" style="color: var(--primary);"></i> Thư viện của bạn</div>
            <div class="folder-grid">
                <?php if ($result_personal->num_rows > 0): ?>
                    <?php while($row = $result_personal->fetch_assoc()): ?>
                        <a href="view_folder.php?id=<?php echo $row['id']; ?>" class="folder-card">
                            <span class="type-badge personal">Cá nhân</span>
                            <span class="btn-edit-folder" title="Sửa tên thư viện" onclick="event.preventDefault(); let newName = prompt('Nhập tên mới:', '<?php echo htmlspecialchars($row['name']); ?>'); if(newName) { window.location.href='edit_folder.php?id=<?php echo $row['id']; ?>&new_name=' + encodeURIComponent(newName); }"><i class="fa-solid fa-pen"></i></span>
                            <span class="btn-delete-folder" title="Xóa thư viện này" onclick="event.preventDefault(); if(confirm('Bạn có chắc chắn muốn xóa thư viện cá nhân này?')) { window.location.href='delete_folder.php?id=<?php echo $row['id']; ?>'; }"><i class="fa-solid fa-trash-can"></i></span>
                            <h3 class="folder-title"><?php echo htmlspecialchars($row['name']); ?></h3>
                            <p><?php echo htmlspecialchars($row['description'] ?? 'Thư mục cá nhân do bạn tạo ra.'); ?></p>
                            <div class="card-meta">
                                <span class="count"><i class="fa-solid fa-layer-group"></i> <?php echo $row['total_lessons']; ?> bài học</span>
                                <span class="action-text">Học ngay <i class="fa-solid fa-chevron-right"></i></span>
                            </div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style='grid-column: 1/-1; padding: 25px; background: #ffffff; border-radius:16px; border: 1px dashed #cbd5e1; color: var(--text-body); font-size:14px;'><i class="fa-regular fa-lightbulb" style="color: #f59e0b; margin-right: 5px;"></i> Bạn chưa tạo bộ thẻ cá nhân nào. Hãy nhập tên ở ô trên để tự tạo không gian học tập nhé!</div>
                <?php endif; ?>
            </div>

            <div class="section-title" style="margin-top: 50px;"><i class="fa-solid fa-star" style="color: #f59e0b;"></i> Thư viện đề xuất cho bạn</div>
            <div class="folder-grid">
                <?php if ($result_system->num_rows > 0): ?>
                    <?php while($row = $result_system->fetch_assoc()): ?>
                        <a href="view_folder.php?id=<?php echo $row['id']; ?>" class="folder-card" style="border-left: 4px solid var(--primary);">
                            <span class="type-badge system">Hệ thống</span>
                            <h3 class="folder-title"><?php echo htmlspecialchars($row['name']); ?></h3>
                            <p><?php echo htmlspecialchars($row['description'] ?? 'Nhấn để xem các bài học mẫu chuẩn từ hệ thống.'); ?></p>
                            <div class="card-meta">
                                <span class="count"><i class="fa-solid fa-layer-group"></i> <?php echo $row['total_lessons']; ?> bài học</span>
                                <span class="action-text" style="color: #10b981;">Học ngay <i class="fa-solid fa-circle-play"></i></span>
                            </div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style='grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-body);'><i class="fa-solid fa-folder-open" style="font-size: 30px; color: #cbd5e1; margin-bottom: 10px;"></i><p>Chưa có thư viện có sẵn nào để hiển thị.</p></div>
                <?php endif; ?>
            </div>

        <?php endif; ?>
    </div>

    <script>
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let cards = document.querySelectorAll('.folder-card');
            cards.forEach(function(card) {
                let titleElement = card.querySelector('.folder-title');
                if (titleElement) {
                    let titleText = titleElement.textContent || titleElement.innerText;
                    if (titleText.toLowerCase().indexOf(filter) > -1) {
                        card.style.display = "";
                    } else {
                        card.style.display = "none";
                    }
                }
            });
        });
    </script>

</body>
</html>