<?php
include 'config/db.php';
session_start();

$error = "";
$success = "";

if (isset($_POST['reset_password'])) {
    $username = mysqli_real_escape_string($conn, trim($_POST['username']));
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $error = "Mật khẩu mới nhập lại chưa trùng khớp!";
    } else {
        // Kiểm tra xem tài khoản này thực sự có tồn tại trên hệ thống không
        $check_sql = "SELECT id FROM users WHERE username = '$username' LIMIT 1";
        $check_result = $conn->query($check_sql);

        if ($check_result && $check_result->num_rows > 0) {
            $new_password_clean = mysqli_real_escape_string($conn, $new_password);
            
            // Tiến hành cập nhật mật khẩu mới vào DB
            $update_sql = "UPDATE users SET password = '$new_password_clean' WHERE username = '$username'";
            if ($conn->query($update_sql) === TRUE) {
                $success = "Đặt lại mật khẩu thành công! Đang quay về đăng nhập...";
                header("refresh:2; url=login.php");
            } else {
                $error = "Lỗi hệ thống khi cập nhật mật khẩu: " . $conn->error;
            }
        } else {
            $error = "Tên đăng nhập này không tồn tại trong hệ thống!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quên mật khẩu - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --bg: #f8fafc; --success-color: #10b981; }
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background: var(--bg); height: 100vh; margin: 0;
            display: flex; align-items: center; justify-content: center;
        }
        .login-card {
            background: white; padding: 40px; border-radius: 24px;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
            width: 100%; max-width: 400px; border: 1px solid #f1f5f9;
        }
        .logo { 
            text-align: center; color: var(--primary); 
            font-size: 30px; font-weight: 800; margin-bottom: 25px; 
        }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-weight: 700; margin-bottom: 8px; color: #1e293b; }
        .form-group input {
            width: 100%; padding: 12px 16px; border: 2px solid #f1f5f9;
            border-radius: 12px; outline: none; box-sizing: border-box;
        }
        .form-group input:focus { border-color: var(--primary); }
        .btn-reset {
            width: 100%; background: var(--primary); color: white;
            border: none; padding: 14px; border-radius: 12px;
            font-weight: 800; cursor: pointer; font-size: 16px; margin-top: 10px;
        }
        .error-msg { background: #fef2f2; color: #ef4444; padding: 12px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; text-align: center; font-weight: 600; border: 1px solid #fee2e2; }
        .success-msg { background: #ecfdf5; color: var(--success-color); padding: 12px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; text-align: center; font-weight: 600; border: 1px solid #d1fae5; }
        .auth-links { text-align: center; margin-top: 25px; font-size: 13px; font-weight: 600; }
        .auth-links a { color: var(--primary); text-decoration: none; }
        .auth-links a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="logo"><i class="fa-solid fa-key"></i> Đặt lại mật khẩu</div>
    
    <?php if(!empty($error)): ?>
        <div class="error-msg"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if(!empty($success)): ?>
        <div class="success-msg"><?php echo $success; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Xác nhận tên đăng nhập của bạn</label>
            <input type="text" name="username" placeholder="Nhập tên tài khoản cần khôi phục..." required>
        </div>
        <div class="form-group">
            <label>Mật khẩu mới</label>
            <input type="password" name="new_password" placeholder="Nhập mật khẩu mới..." required>
        </div>
        <div class="form-group">
            <label>Xác nhận lại mật khẩu mới</label>
            <input type="password" name="confirm_password" placeholder="Nhập lại mật khẩu mới..." required>
        </div>
        <button type="submit" name="reset_password" class="btn-reset">Cập nhật mật khẩu</button>
    </form>

    <div class="auth-links">
        <a href="login.php"><i class="fa-solid fa-arrow-left"></i> Quay lại Đăng nhập</a>
    </div>
</div>

</body>
</html>