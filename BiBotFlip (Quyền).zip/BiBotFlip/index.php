<?php 
session_start();
include 'auth.php';
include 'config/db.php'; 

// Giả lập thông tin người dùng (Có thể thay bằng dữ liệu từ bảng users nếu có)
$user_name = "Sinh Viên"; 
$user_initials = "SV";

// 1. Truy vấn toàn bộ Folder từ Database
// Câu lệnh đếm số lượng bài học (lessons) trong mỗi folder
$sql = "SELECT f.*, 
        (SELECT COUNT(l.id) FROM lessons l WHERE l.folder_id = f.id) as total_lessons 
        FROM folders f 
        ORDER BY f.created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BiBotFlip - Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --primary-hover: #4f46e5;
            --bg: #f8fafc;
            --sidebar-bg: #ffffff;
            --card-bg: #ffffff;
            --text-title: #1e293b;
            --text-body: #64748b;
            --border: #f1f5f9;
            --danger: #ef4444;
            --success: #10b981;
        }

        * { box-sizing: border-box; transition: all 0.2s ease-in-out; }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: var(--bg); 
            margin: 0; display: flex; min-height: 100vh;
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: 280px; background: var(--sidebar-bg);
            border-right: 1px solid var(--border);
            display: flex; flex-direction: column;
            position: fixed; height: 100vh; padding: 25px 15px; z-index: 100;
        }

        .logo {
            font-size: 26px; font-weight: 800; color: var(--primary);
            padding: 0 15px 30px 15px; display: flex; align-items: center; gap: 10px;
        }

        .sidebar-nav { flex: 1; display: flex; flex-direction: column; overflow-y: auto; }

        .menu-label {
            font-size: 11px; text-transform: uppercase; color: #94a3b8;
            font-weight: 700; margin: 20px 0 10px 15px; letter-spacing: 1px;
        }

        .menu-item {
            display: flex; align-items: center; padding: 12px 15px;
            color: var(--text-body); text-decoration: none; border-radius: 12px;
            margin-bottom: 4px; font-weight: 600;
        }

        .menu-item i { margin-right: 12px; width: 20px; font-size: 18px; text-align: center; }
        .menu-item:hover, .menu-item.active { background: #f1f5f9; color: var(--primary); }

        .sidebar-footer { margin-top: auto; padding-top: 20px; border-top: 1px solid var(--border); }

        .user-profile {
            display: flex; align-items: center; gap: 12px; padding: 12px;
            text-decoration: none; color: var(--text-title); border-radius: 12px;
        }
        .user-profile:hover { background: #f1f5f9; }

        .avatar {
            width: 40px; height: 40px; background: var(--primary);
            color: white; border-radius: 50%; display: flex;
            align-items: center; justify-content: center; font-weight: 800;
        }

        .logout-link { color: var(--danger); }
        .logout-link:hover { background: #fef2f2; }

        /* --- MAIN CONTENT --- */
        .main-content { margin-left: 280px; flex: 1; padding: 40px; }

        .header-section { margin-bottom: 35px; }
        .header-section h1 { font-size: 28px; margin: 0; color: var(--text-title); font-weight: 800; }
        .header-section p { color: var(--text-body); margin-top: 5px; }

        /* Form Thêm Bộ Thẻ */
        .add-box {
            background: var(--card-bg); padding: 20px; border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); margin-bottom: 40px;
            border: 1px solid var(--border);
        }
        .add-box form { display: flex; gap: 12px; }
        .add-box input {
            flex: 1; padding: 14px 20px; border: 2px solid var(--border);
            border-radius: 12px; outline: none; font-size: 15px;
        }
        .add-box input:focus { border-color: var(--primary); }
        .add-box button {
            background: var(--primary); color: white; border: none;
            padding: 0 25px; border-radius: 12px; font-weight: 700; cursor: pointer;
        }
        .add-box button:hover { background: var(--primary-hover); }

        /* Folder Grid */
        .folder-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }

        .folder-card {
            background: var(--card-bg); border-radius: 20px; padding: 25px;
            text-decoration: none; border: 1px solid var(--border);
            display: flex; flex-direction: column;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }
        .folder-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
            border-color: var(--primary);
        }

        .folder-card h3 { margin: 10px 0 5px 0; font-size: 18px; color: var(--text-title); font-weight: 700; }
        .folder-card p { font-size: 14px; color: var(--text-body); margin-bottom: 20px; flex: 1; line-height: 1.5; }

        .type-badge {
            align-self: flex-start; font-size: 10px; font-weight: 800;
            text-transform: uppercase; padding: 4px 10px; border-radius: 6px;
            background: #f1f5f9; color: #475569;
        }
        .type-badge.system { background: #e0e7ff; color: var(--primary); }

        .card-meta { display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #f8fafc; padding-top: 15px; }
        .count { font-size: 13px; font-weight: 600; color: var(--text-body); }
        .action-text { color: var(--primary); font-weight: 700; font-size: 14px; }

        @media (max-width: 900px) {
            .sidebar { width: 80px; padding: 25px 10px; }
            .logo span, .menu-label, .menu-item span, .user-profile div { display: none; }
            .main-content { margin-left: 80px; }
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo"><i class="fa-solid fa-bolt"></i> <span>BiBotFlip</span></div>
        
        <div class="sidebar-nav">
            <a href="index.php" class="menu-item active"><i class="fa-solid fa-house"></i> <span>Trang chủ</span></a>

            <div class="menu-label">Thư viện của bạn</div>
            <a href="all_cards.php" class="menu-item"><i class="fa-solid fa-book-bookmark"></i> <span>Tất cả Flashcard</span></a>
            <a href="online_exams.php" class="menu-item"><i class="fa-solid fa-folder-plus"></i> <span>Đề thi online</span></a>

            <div class="menu-label">Thẻ ghi nhớ</div>
            <a href="all_cards.php?filter=mastered" class="menu-item" style="color: var(--success);">
                <i class="fa-solid fa-circle-check"></i> <span>Đã ghi nhớ</span>
            </a>
            <a href="all_cards.php?filter=unlearned" class="menu-item" style="color: var(--danger);">
                <i class="fa-solid fa-circle-minus"></i> <span>Chưa ghi nhớ</span>
            </a>

            <div class="sidebar-footer">
    <div class="menu-label">Tài khoản</div>
    <a href="profile.php" class="user-profile">
        <div class="avatar"><?php echo $_SESSION['initials']; ?></div>
        <div style="display: flex; flex-direction: column;">
            <span style="font-weight: 700; font-size: 14px;">
    <?php echo $_SESSION['display_name'] ?? 'Sinh Viên'; ?></span>
            <span style="font-size: 11px; color: var(--text-body);">
                <?php echo (isset($_SESSION['role']) && $_SESSION['role'] == 'admin')  ? 'Chế độ Quản trị'  : 'Thành viên học tập'; ?>
            </span>
        </div>
    </a>
    <a href="logout.php" class="menu-item logout-link">
        <i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Đăng xuất</span>
    </a>
</div>
        </div>
    </div>

    <div class="main-content">
        <div class="header-section">
            <h1>Khám phá Thư viện</h1>
            <p>Chào mừng bạn quay trở lại. Hôm nay bạn muốn học gì?</p>
        </div>

        <div class="add-box">
            <form action="add_folder.php" method="POST">
                <input type="text" name="folder_name" placeholder="Nhập tên bộ thẻ mới (VD: Tiếng Anh giao tiếp)..." required>
                <button type="submit" name="submit">Tạo ngay</button>
            </form>
        </div>

        <div class="folder-grid">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    // Phân loại Hệ thống/Cá nhân dựa trên ID hoặc cột type (nếu có)
                    $is_system = (isset($row['type']) && $row['type'] == 'system') || ($row['id'] <= 10); 
                    ?>
                    <a href="view_folder.php?id=<?php echo $row['id']; ?>" class="folder-card">
                        <span class="type-badge <?php echo $is_system ? 'system' : ''; ?>">
                            <?php echo $is_system ? 'Hệ thống' : 'Cá nhân'; ?>
                        </span>
                        <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                        <p><?php echo htmlspecialchars($row['description'] ?? 'Nhấn để xem các bài học trong bộ thẻ này.'); ?></p>
                        <div class="card-meta">
                            <span class="count">
                                <i class="fa-solid fa-layer-group"></i> <?php echo $row['total_lessons']; ?> bài học
                            </span>
                            <span class="action-text">Học ngay <i class="fa-solid fa-chevron-right"></i></span>
                        </div>
                    </a>
                    <?php
                }
            } else {
                echo "<div style='grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-body);'>
                        <i class='fa-solid fa-folder-open' style='font-size: 40px; margin-bottom: 10px;'></i>
                        <p>Thư viện đang trống. Hãy tạo bộ thẻ đầu tiên ở trên!</p>
                      </div>";
            }
            ?>
        </div>
    </div>

</body>
</html>