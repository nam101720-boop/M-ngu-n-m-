<?php
// chỉ start nếu chưa có session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// nếu chưa login → quay về login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>