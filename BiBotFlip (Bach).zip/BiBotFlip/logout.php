<?php
session_start();
// Hủy bỏ tất cả các biến session
session_unset();
// Hủy bỏ phiên làm việc
session_destroy();

// Chuyển hướng về trang login
header("Location: login.php");
exit();
?>