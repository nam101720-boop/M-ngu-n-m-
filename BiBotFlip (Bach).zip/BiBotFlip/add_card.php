<?php
include 'config/db.php';

$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0;
$l_id = isset($_GET['l_id']) ? intval($_GET['l_id']) : 0;

/* =========================
   GET EXISTING CARDS
========================= */

$existing_cards = $conn->query("
    SELECT id, term, definition, example, image_url
    FROM cards
    ORDER BY id DESC
    LIMIT 100
");

/* =========================
   ADD CARD
========================= */

if (isset($_POST['submit_card'])) {

    $folder_id = intval($_POST['folder_id']);
    $lesson_id = intval($_POST['lesson_id']);

    $term = trim($_POST['term']);
    $definition = trim($_POST['definition']);
    $example = trim($_POST['example']);
    $image_url = trim($_POST['image_url']);

    // Validate
    if (empty($term) || empty($definition)) {
        die("Term và Definition không được để trống!");
    }

    if (!empty($image_url) && !filter_var($image_url, FILTER_VALIDATE_URL)) {
        die("Link ảnh không hợp lệ!");
    }

    // Prepared statement
    $stmt = $conn->prepare("
        INSERT INTO cards (
            folder_id,
            lesson_id,
            term,
            definition,
            example,
            image_url,
            mastery_level
        ) 
        VALUES (?, ?, ?, ?, ?, ?, 0)
    ");

    $stmt->bind_param(
        "iissss",
        $folder_id,
        $lesson_id,
        $term,
        $definition,
        $example,
        $image_url
    );

    if ($stmt->execute()) {

        header("Location: view_folder.php?id=" . $folder_id);
        exit();

    } else {

        echo "Lỗi: " . $stmt->error;

    }
}
?>

<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">

<title>Thêm thẻ mới</title>

<style>

body{
    font-family:sans-serif;
    background:#f8fafc;
    display:flex;
    justify-content:center;
    padding:40px 0;
}

.form-box{
    background:white;
    padding:30px;
    border-radius:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.05);
    width:450px;
}

.input-group{
    margin-bottom:15px;
}

label{
    display:block;
    margin-bottom:5px;
    font-weight:bold;
    color:#475569;
}

input,
textarea,
select{
    width:100%;
    padding:12px;
    border:1px solid #ddd;
    border-radius:10px;
    box-sizing:border-box;
}

textarea{
    min-height:100px;
    resize:vertical;
}

button{
    width:100%;
    padding:15px;
    background:#10b981;
    color:white;
    border:none;
    border-radius:12px;
    cursor:pointer;
    font-weight:bold;
    font-size:16px;
}

button:hover{
    opacity:0.9;
}

.back-link{
    display:block;
    text-align:center;
    margin-top:15px;
    color:#64748b;
    text-decoration:none;
}

.back-link:hover{
    color:#0f172a;
}

</style>

</head>

<body>

<div class="form-box">

    <h2 style="color:#10b981;">
        Thêm thẻ ghi nhớ mới
    </h2>

    <form method="POST">

        <input 
            type="hidden" 
            name="folder_id" 
            value="<?php echo $f_id; ?>"
        >

        <input 
            type="hidden" 
            name="lesson_id" 
            value="<?php echo $l_id; ?>"
        >

        <!-- CHỌN THẺ CÓ SẴN -->

        <div class="input-group">

            <label>Chọn thẻ có sẵn:</label>

            <select id="existing_card" onchange="fillCardData()">

                <option value="">
                    -- Chọn thẻ --
                </option>

                <?php while($card = $existing_cards->fetch_assoc()): ?>

                    <option
                        value="<?= $card['id'] ?>"
                        data-term="<?= htmlspecialchars($card['term']) ?>"
                        data-definition="<?= htmlspecialchars($card['definition']) ?>"
                        data-example="<?= htmlspecialchars($card['example']) ?>"
                        data-image="<?= htmlspecialchars($card['image_url']) ?>"
                    >
                        <?= htmlspecialchars($card['term']) ?>
                    </option>

                <?php endwhile; ?>

            </select>

        </div>

        <!-- TERM -->

        <div class="input-group">

            <label>Từ vựng (Term):</label>

            <input 
                type="text" 
                name="term" 
                required 
                autofocus
            >

        </div>

        <!-- DEFINITION -->

        <div class="input-group">

            <label>Định nghĩa (Definition):</label>

            <input 
                type="text" 
                name="definition" 
                required
            >

        </div>

        <!-- EXAMPLE -->

        <div class="input-group">

            <label>Ví dụ (Example):</label>

            <textarea name="example"></textarea>

        </div>

        <!-- IMAGE -->

        <div class="input-group">

            <label>Link ảnh (Image URL):</label>

            <input
                type="text"
                name="image_url"
                placeholder="https://example.com/image.jpg"
            >

        </div>

        <!-- SUBMIT -->

        <button type="submit" name="submit_card">

            Lưu thẻ này

        </button>

        <!-- BACK -->

        <a 
            href="view_folder.php?id=<?php echo $f_id; ?>"
            class="back-link"
        >
            ← Quay lại
        </a>

    </form>

</div>

<script>

function fillCardData(){

    const select = document.getElementById('existing_card');

    const option = select.options[select.selectedIndex];

    document.querySelector('input[name="term"]').value =
        option.dataset.term || '';

    document.querySelector('input[name="definition"]').value =
        option.dataset.definition || '';

    document.querySelector('textarea[name="example"]').value =
        option.dataset.example || '';

    document.querySelector('input[name="image_url"]').value =
        option.dataset.image || '';
}

</script>

</body>
</html>