<?php
session_start();
include 'config/db.php';

$message = "";

if (isset($_POST['register'])) {

    $username = trim($_POST['username']);
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($username == "" || $password == "") {
        $message = "❌ Vui lòng nhập đầy đủ thông tin!";
    } else {

        // kiểm tra username đã tồn tại chưa
        $check = "SELECT id FROM users WHERE username = '$username'";
        $result = $conn->query($check);

        if ($result->num_rows > 0) {
            $message = "❌ Tên đăng nhập đã tồn tại!";
        } else {

            // ❗ KHÔNG hash
            $sql = "INSERT INTO users (username, fullname, email, password, role)
                    VALUES ('$username', '$fullname', '$email', '$password', 'user')";

            if ($conn->query($sql) === TRUE) {
                $message = "✅ Đăng ký thành công! <a href='login.php'>Đăng nhập ngay</a>";
            } else {
                $message = "❌ Lỗi: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng ký</title>
<style>
body{font-family:Arial;background:#f8fafc;display:flex;justify-content:center;padding-top:50px;}
.box{background:white;padding:30px;border-radius:20px;width:400px;}
input{width:100%;padding:10px;margin:10px 0;border:1px solid #ddd;border-radius:10px;}
button{width:100%;padding:12px;background:#10b981;color:white;border:none;border-radius:10px;}
.msg{margin-bottom:10px;font-weight:bold;}
a{color:#6366f1;text-decoration:none;}
</style>
</head>
<body>

<div class="box">
<h2>Đăng ký tài khoản</h2>

<?php if($message) echo "<div class='msg'>$message</div>"; ?>

<form method="POST">
    <input type="text" name="username" placeholder="Tên đăng nhập" required>
    <input type="text" name="fullname" placeholder="Họ tên">
    <input type="email" name="email" placeholder="Email">
    <input type="password" name="password" placeholder="Mật khẩu" required>
    <button type="submit" name="register">Đăng ký</button>
</form>

<p style="text-align:center;margin-top:10px;">
    Đã có tài khoản? <a href="login.php">Đăng nhập</a>
</p>

</div>

</body>
</html>