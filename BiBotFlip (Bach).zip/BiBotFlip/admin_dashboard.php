<?php
session_start();
include 'config/db.php';

// 🔒 Chặn truy cập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// ================== QUERY ==================
$students = [];

$sql = "
    SELECT 
        u.id,
        u.username,

        COUNT(p.card_id) AS total_cards,

        SUM(CASE WHEN p.mastery_level >= 3 THEN 1 ELSE 0 END) AS mastered,

        COUNT(DISTINCT e.id) AS exams

    FROM users u

    LEFT JOIN user_card_progress p ON p.user_id = u.id
    LEFT JOIN exam_results e ON e.user_id = u.id

    WHERE u.role = 'student'

    GROUP BY u.id
    ORDER BY u.id DESC
";

$result = $conn->query($sql);

if (!$result) {
    die("Lỗi SQL: " . $conn->error);
}

while ($row = $result->fetch_assoc()) {

    $total = $row['total_cards'] ?? 0;
    $mastered = $row['mastered'] ?? 0;

    $row['progress'] = ($total > 0) 
        ? round(($mastered / $total) * 100) 
        : 0;

    $students[] = $row;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>

<style>
body {
    font-family: Arial;
    background: #f8fafc;
    padding: 30px;
}

h1 {
    margin-bottom: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 12px;
    overflow: hidden;
}

th, td {
    padding: 12px;
    text-align: center;
}

th {
    background: #6366f1;
    color: white;
}

tr:nth-child(even) {
    background: #f1f5f9;
}

.progress {
    color: #6366f1;
    font-weight: bold;
}
</style>

</head>
<body>

<h1>👑 Admin Dashboard</h1>

<table>
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Flashcard</th>
        <th>Thuộc</th>
        <th>Bài thi</th>
        <th>Hành động</th>
    </tr>

    <?php foreach ($students as $sv): ?>
<tr>
    <td><?php echo $sv['id']; ?></td>
    <td><?php echo $sv['username']; ?></td>
    <td><?php echo $sv['total_cards']; ?></td>
    <td><?php echo $sv['mastered']; ?></td>
    <td><?php echo $sv['exams']; ?></td>

    <td>
        <a href="student_detail.php?id=<?php echo $sv['id']; ?>" 
           style="background:#6366f1;color:white;padding:6px 12px;border-radius:6px;text-decoration:none;">
           Chi tiết
        </a>
    </td>
</tr>
<?php endforeach; ?>

</table>

</body>
</html>