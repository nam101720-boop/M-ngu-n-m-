<?php
include 'config/db.php';
session_start();

$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0;

$user_id = $_SESSION['user_id'] ?? 0;
$user_role = $_SESSION['role'] ?? 'student';

// lấy folder
$folder = $conn->query("SELECT * FROM folders WHERE id = $f_id")->fetch_assoc();
if (!$folder) {
    die("Folder không tồn tại");
}

if (isset($_POST['submit_lesson'])) {

    $folder_id = intval($_POST['folder_id']);
    $lesson_name = $conn->real_escape_string($_POST['lesson_name']);

    // =========================
    // LOGIC QUYỀN CHUẨN
    // =========================

    $type = 'personal';

    // Folder system → chỉ admin mới được thêm
    if ($folder['type'] === 'system') {
        if ($user_role !== 'admin') {
            die("Không có quyền thêm vào folder hệ thống");
        }
        $type = 'system';
    }

    // Folder personal
    else {
        if ($user_role === 'admin') {
            $type = $_POST['type'] ?? 'personal';
        } else {
            $type = 'personal';
        }
    }

    // INSERT có user_id
    $sql = "INSERT INTO lessons (folder_id, name, type, user_id)
            VALUES ($folder_id, '$lesson_name', '$type', $user_id)";

    if ($conn->query($sql)) {
        header("Location: view_folder.php?id=$folder_id");
        exit();
    } else {
        echo "Lỗi: " . $conn->error;
    }
}
?>