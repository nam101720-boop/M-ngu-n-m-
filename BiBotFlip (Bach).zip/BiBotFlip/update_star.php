<?php
include 'config/db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['card_id'])) {
    $card_id = intval($_POST['card_id']);
    // Câu lệnh đảo trạng thái: 1 - 0 = 1; 1 - 1 = 0
    $sql = "UPDATE cards SET is_starred = 1 - is_starred WHERE id = $card_id";
    $conn->query($sql);
    echo "Success";
}
?>