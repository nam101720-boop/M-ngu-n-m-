<?php 
session_start();
include 'config/db.php'; 

// ================== CHẶN LOGIN ==================
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// ================== LẤY THÔNG TIN USER ==================
$stmt = $conn->prepare("SELECT username, fullname, role FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$username = $user['username'];
$fullname = $user['fullname'];
$user_role = $user['role'];

$display_name = $fullname ? $fullname : $username;
$initials = strtoupper(substr($display_name, 0, 2));

// ================== THỐNG KÊ CÁ NHÂN ==================

// Flashcard đã học
$stmt = $conn->prepare("
    SELECT COUNT(*) AS total 
    FROM user_card_progress 
    WHERE user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_cards = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

// Flashcard đã thuộc
$stmt = $conn->prepare("
    SELECT COUNT(*) AS total 
    FROM user_card_progress 
    WHERE user_id = ? AND mastery_level >= 3
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$mastered_cards = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

// Bài thi đã làm
$stmt = $conn->prepare("
    SELECT COUNT(*) AS total 
    FROM exam_results 
    WHERE user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_exams = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

// Tiến độ
$progress_percent = ($total_cards > 0)
    ? round(($mastered_cards / $total_cards) * 100)
    : 0;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Profile</title>

<style>
body {
    font-family: Arial;
    background: #f8fafc;
    margin: 0;
    padding: 30px;
}

.container {
    max-width: 800px;
    margin: auto;
}

.card {
    background: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 10px 20px rgba(0,0,0,0.05);
}

.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.avatar {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    background: #6366f1;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.name-group h2 {
    margin: 0;
}

.role {
    font-size: 13px;
    color: #64748b;
}

.btn {
    padding: 8px 12px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: bold;
    font-size: 13px;
}

.btn-edit {
    background: #eef2ff;
    color: #6366f1;
}

.btn-admin {
    background: #111827;
    color: white;
}

.stats {
    margin-top: 25px;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.box {
    background: #f8fafc;
    padding: 15px;
    border-radius: 12px;
    text-align: center;
}

.box h3 {
    margin: 5px 0;
}

.progress {
    margin-top: 20px;
    background: #e2e8f0;
    height: 12px;
    border-radius: 10px;
    overflow: hidden;
}

.progress-bar {
    height: 100%;
    background: #6366f1;
    width: <?php echo $progress_percent; ?>%;
}
</style>

</head>
<body>

<div class="container">
    <a href="index.php" style="text-decoration:none; color:var(--primary); font-weight:700;"><i class="fa-solid fa-arrow-left"></i> Quay lại</a>

<div class="card">

    <!-- HEADER -->
    <div class="header">

        <div class="user-info">
            <div class="avatar"><?php echo $initials; ?></div>

            <div class="name-group">
                <h2>
                    <?php echo htmlspecialchars($display_name); ?>
                </h2>

                <div class="role">
                    <?php echo $user_role; ?>
                </div>
            </div>
        </div>

        <!-- NÚT SỬA + ADMIN -->
        <div style="display:flex; gap:10px;">

            <!-- SỬA -->
            <a href="edit_profile.php" class="btn btn-edit">
                ✏️ Sửa
            </a>

            <!-- ADMIN -->
            <?php if ($user_role === 'admin'): ?>
                <a href="admin_dashboard.php" class="btn btn-admin">
                    ⚙️ Admin
                </a>
            <?php endif; ?>

        </div>

    </div>

    <!-- STATS -->
    <div class="stats">

        <div class="box">
            <b>Flashcard</b>
            <h3><?php echo $total_cards; ?></h3>
        </div>

        <div class="box">
            <b>Thuộc</b>
            <h3><?php echo $mastered_cards; ?></h3>
        </div>

        <div class="box">
            <b>Bài thi</b>
            <h3><?php echo $total_exams; ?></h3>
        </div>

        <div class="box">
            <b>Tiến độ</b>
            <h3><?php echo $progress_percent; ?>%</h3>
        </div>

    </div>

    <!-- PROGRESS BAR -->
    <div class="progress">
        <div class="progress-bar"></div>
    </div>

</div>

</div>

</body>
</html>