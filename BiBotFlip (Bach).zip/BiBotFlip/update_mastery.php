<?php
include 'config/db.php';

$user_id = intval($_POST['user_id']);
$card_id = intval($_POST['card_id']);
$status = $_POST['status'];

$res = $conn->query("
SELECT mastery_level 
FROM user_card_progress 
WHERE user_id = $user_id AND card_id = $card_id
");

$row = $res->fetch_assoc();
$level = $row['mastery_level'] ?? 0;

if ($status == "correct") {
    $level = min(5, $level + 1);
} else {
    $level = max(0, $level - 1);
}

$conn->query("
INSERT INTO user_card_progress (user_id, card_id, mastery_level)
VALUES ($user_id, $card_id, $level)
ON DUPLICATE KEY UPDATE mastery_level = $level
");
?>