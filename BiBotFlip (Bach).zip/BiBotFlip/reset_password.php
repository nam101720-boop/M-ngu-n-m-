<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['reset_email'])) {
    header("Location: forgot_password.php");
    exit();
}

$email = $_SESSION['reset_email'];
$message = "";

if (isset($_POST['reset'])) {

    $code = $_POST['code'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    $sql = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        $message = "❌ Không tìm thấy user!";
    }
    elseif ($code != $user['reset_code']) {
        $message = "❌ Mã không đúng!";
    }
    elseif (strtotime($user['reset_expire']) < time()) {
        $message = "❌ Mã đã hết hạn!";
    }
    elseif (strlen($new_password) < 6) {
        $message = "❌ Mật khẩu phải >= 6 ký tự!";
    }
    elseif ($new_password != $confirm_password) {
        $message = "❌ Mật khẩu không khớp!";
    }
    else {

        // KHÔNG HASH (theo yêu cầu của bạn)
        $sql = "UPDATE users SET password=?, reset_code=NULL, reset_expire=NULL WHERE email=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $new_password, $email);

        if ($stmt->execute()) {
            session_destroy();
            header("Location: login.php");
            exit();
        } else {
            $message = "❌ Lỗi cập nhật!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đặt lại mật khẩu</title>
<style>
body{font-family:sans-serif;background:#f8fafc;display:flex;justify-content:center;align-items:center;height:100vh}
.card{background:white;padding:30px;border-radius:20px;width:350px}
input{width:100%;padding:10px;margin:10px 0;border:1px solid #ddd;border-radius:10px}
button{width:100%;padding:12px;background:#10b981;color:white;border:none;border-radius:10px}
.msg{color:red;margin-bottom:10px}
</style>
</head>
<body>

<div class="card">
<h2>Đặt lại mật khẩu</h2>

<?php if($message) echo "<div class='msg'>$message</div>"; ?>

<form method="POST">
<input type="text" name="code" placeholder="Nhập mã OTP" required>
<input type="password" name="new_password" placeholder="Mật khẩu mới" required>
<input type="password" name="confirm_password" placeholder="Nhập lại mật khẩu" required>
<button name="reset">Đổi mật khẩu</button>
</form>

</div>

</body>
</html>