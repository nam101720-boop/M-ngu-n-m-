<?php
session_start();
include 'config/db.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Lấy mật khẩu hiện tại từ DB
$sql = "SELECT password FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

  // 1. Kiểm tra mật khẩu cũ (so sánh trực tiếp)
if ($old_password != $user['password']) {
    $message = "❌ Mật khẩu cũ không đúng!";
}
// 2. Kiểm tra độ dài
elseif (strlen($new_password) < 6) {
    $message = "❌ Mật khẩu mới phải ít nhất 6 ký tự!";
}
// 3. Xác nhận mật khẩu
elseif ($new_password !== $confirm_password) {
    $message = "❌ Mật khẩu xác nhận không khớp!";
}
else {
    // 4. Lưu trực tiếp (KHÔNG hash)
    $sql = "UPDATE users SET password=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $new_password, $user_id);

    if ($stmt->execute()) {
        $message = "✅ Đổi mật khẩu thành công!";
    } else {
        $message = "❌ Có lỗi xảy ra!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đổi mật khẩu</title>
<style>
body{font-family:Arial;background:#f1f5f9;padding:40px;}
.box{max-width:500px;margin:auto;background:white;padding:30px;border-radius:20px;}
input{width:100%;padding:10px;margin:10px 0;border:1px solid #ddd;border-radius:10px;}
button{background:#ef4444;color:white;padding:12px;border:none;border-radius:10px;width:100%;}
a{display:inline-block;margin-bottom:15px;text-decoration:none;color:#6366f1;font-weight:700;}
.msg{margin-top:10px;font-weight:bold;}
</style>
</head>
<body>

<div class="box">

<a href="edit_profile.php">← Quay lại</a>

<h2>Đổi mật khẩu</h2>

<?php if($message) echo "<p class='msg'>$message</p>"; ?>

<form method="POST">
    <input type="password" name="old_password" placeholder="Mật khẩu cũ" required>
    <input type="password" name="new_password" placeholder="Mật khẩu mới" required>
    <input type="password" name="confirm_password" placeholder="Xác nhận mật khẩu mới" required>
    <button type="submit">Đổi mật khẩu</button>
</form>

</div>

</body>
</html>