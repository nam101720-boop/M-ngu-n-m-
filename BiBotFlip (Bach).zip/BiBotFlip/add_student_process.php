<?php

session_start();
include 'config/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$username = trim($_POST['username']);
$fullname = trim($_POST['fullname']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);

if (
    empty($username) ||
    empty($fullname) ||
    empty($email) ||
    empty($password)
) {
    die("Vui lòng nhập đầy đủ thông tin");
}

$username = $conn->real_escape_string($username);
$fullname = $conn->real_escape_string($fullname);
$email = $conn->real_escape_string($email);
$password = $conn->real_escape_string($password);

// CHECK USERNAME
$check = $conn->query("
    SELECT id 
    FROM users 
    WHERE username = '$username'
");

if ($check->num_rows > 0) {
    die("Tên đăng nhập đã tồn tại");
}

// INSERT
$sql = "
INSERT INTO users (
    username,
    fullname,
    email,
    password,
    role
)
VALUES (
    '$username',
    '$fullname',
    '$email',
    '$password',
    'student'
)
";

if ($conn->query($sql)) {

    header("Location: admin_students.php");
    exit();

} else {

    die("Lỗi: " . $conn->error);
}
?>