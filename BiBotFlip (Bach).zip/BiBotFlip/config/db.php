<?php
$host = "localhost";
$user = "root";
$pass = ""; // Mặc định của XAMPP là rỗng
$dbname = "BiBotFlip";

$conn = new mysqli($host, $user, $pass, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Thiết lập UTF-8 để không bị lỗi font tiếng Việt
$conn->set_charset("utf8mb4");
?>