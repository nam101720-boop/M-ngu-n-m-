<?php
session_start();
include 'auth.php';
include 'config/db.php';

/* =========================
   CHECK ADMIN
========================= */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

/* =========================
   SEARCH
========================= */
$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

/* =========================
   DELETE STUDENT
========================= */
if (isset($_GET['delete_id'])) {

    $delete_id = intval($_GET['delete_id']);

    $conn->query("
        DELETE FROM users
        WHERE id = $delete_id
        AND role = 'student'
    ");

    header("Location: admin_students.php");
    exit();
}

/* =========================
   ADD STUDENT
========================= */
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student'])) {

    $username = trim($_POST['username']);
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (
        empty($username) ||
        empty($fullname) ||
        empty($email) ||
        empty($password)
    ) {

        $message = "❌ Vui lòng nhập đầy đủ thông tin!";

    } else {

        $username = $conn->real_escape_string($username);
        $fullname = $conn->real_escape_string($fullname);
        $email = $conn->real_escape_string($email);
        $password = $conn->real_escape_string($password);

        // kiểm tra username
        $check_user = $conn->query("
            SELECT id
            FROM users
            WHERE username = '$username'
        ");

        if ($check_user->num_rows > 0) {

            $message = "❌ Tên đăng nhập đã tồn tại!";

        } else {

            // kiểm tra email
            $check_email = $conn->query("
                SELECT id
                FROM users
                WHERE email = '$email'
            ");

            if ($check_email->num_rows > 0) {

                $message = "❌ Email đã tồn tại!";

            } else {

                $sql_insert = "
                    INSERT INTO users
                    (
                        username,
                        fullname,
                        email,
                        password,
                        role
                    )
                    VALUES
                    (
                        '$username',
                        '$fullname',
                        '$email',
                        '$password',
                        'student'
                    )
                ";

                if ($conn->query($sql_insert)) {

                    $message = "✅ Thêm sinh viên thành công!";

                } else {

                    $message = "❌ Lỗi: " . $conn->error;
                }
            }
        }
    }
}

/* =========================
   EDIT STUDENT
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_student'])) {

    $id = intval($_POST['id']);

    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);

    $fullname = $conn->real_escape_string($fullname);
    $email = $conn->real_escape_string($email);

    $conn->query("
        UPDATE users
        SET
            fullname = '$fullname',
            email = '$email'
        WHERE id = $id
        AND role = 'student'
    ");

    header("Location: admin_students.php");
    exit();
}

/* =========================
   GET STUDENTS
========================= */
$sql = "
SELECT *
FROM users
WHERE role = 'student'
";

if (!empty($search)) {

    $search_safe = $conn->real_escape_string($search);

    $sql .= "
        AND (
            fullname LIKE '%$search_safe%'
            OR email LIKE '%$search_safe%'
            OR username LIKE '%$search_safe%'
        )
    ";
}

$sql .= " ORDER BY id DESC";

$result = $conn->query($sql);

$user_role = $_SESSION['role'] ?? 'user';
?>

<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Quản lý sinh viên</title>

<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

:root{
    --primary:#6366f1;
    --primary-hover:#4f46e5;
    --bg:#f8fafc;
    --sidebar-bg:#ffffff;
    --card-bg:#ffffff;
    --text-title:#1e293b;
    --text-body:#64748b;
    --border:#f1f5f9;
    --danger:#ef4444;
    --success:#10b981;
}

*{
    box-sizing:border-box;
    transition:all .2s ease;
}

body{
    font-family:'Plus Jakarta Sans', sans-serif;
    background:var(--bg);
    margin:0;
    display:flex;
    min-height:100vh;
}

/* ================= SIDEBAR ================= */

.sidebar{
    width:280px;
    background:var(--sidebar-bg);
    border-right:1px solid var(--border);
    display:flex;
    flex-direction:column;
    position:fixed;
    height:100vh;
    padding:25px 15px;
}

.logo{
    font-size:26px;
    font-weight:800;
    color:var(--primary);
    padding:0 15px 30px;
    display:flex;
    align-items:center;
    gap:10px;
}

.sidebar-nav{
    flex:1;
    display:flex;
    flex-direction:column;
}

.menu-label{
    font-size:11px;
    text-transform:uppercase;
    color:#94a3b8;
    font-weight:700;
    margin:20px 0 10px 15px;
    letter-spacing:1px;
}

.menu-item{
    display:flex;
    align-items:center;
    padding:12px 15px;
    color:var(--text-body);
    text-decoration:none;
    border-radius:12px;
    margin-bottom:4px;
    font-weight:600;
}

.menu-item i{
    margin-right:12px;
    width:20px;
    text-align:center;
}

.menu-item:hover,
.menu-item.active{
    background:#f1f5f9;
    color:var(--primary);
}

.sidebar-footer{
    margin-top:auto;
    padding-top:20px;
    border-top:1px solid var(--border);
}

.user-profile{
    display:flex;
    align-items:center;
    gap:12px;
    padding:12px;
    border-radius:12px;
    text-decoration:none;
    color:var(--text-title);
}

.user-profile:hover{
    background:#f1f5f9;
}

.avatar{
    width:40px;
    height:40px;
    border-radius:50%;
    background:var(--primary);
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    font-weight:800;
}

.logout-link{
    color:var(--danger);
}

.logout-link:hover{
    background:#fef2f2;
}

/* ================= MAIN ================= */

.main-content{
    margin-left:280px;
    flex:1;
    padding:40px;
}

.header-flex{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:35px;
    gap:20px;
    flex-wrap:wrap;
}

.header-section h1{
    margin:0;
    font-size:30px;
    color:var(--text-title);
    font-weight:800;
}

.header-section p{
    color:var(--text-body);
    margin-top:5px;
}

/* ================= SEARCH ================= */

.action-bar{
    margin-bottom:25px;
}

.search-box{
    background:white;
    border:1px solid var(--border);
    border-radius:16px;
    padding:5px;
}

.search-box form{
    display:flex;
    gap:10px;
}

.search-box input{
    flex:1;
    border:none;
    outline:none;
    background:transparent;
    padding:12px 15px;
    font-size:15px;
}

.btn-search{
    border:none;
    background:var(--primary);
    color:white;
    border-radius:12px;
    padding:0 22px;
    font-weight:700;
    cursor:pointer;
}

.btn-search:hover{
    background:var(--primary-hover);
}

/* ================= BUTTONS ================= */

.btn-add{
    background:var(--success);
    color:white;
    border:none;
    border-radius:14px;
    padding:14px 24px;
    font-weight:700;
    cursor:pointer;
    display:flex;
    align-items:center;
    gap:8px;
}

.btn-add:hover{
    opacity:.9;
}

/* ================= TABLE ================= */

.table-container{
    background:white;
    border-radius:20px;
    overflow:hidden;
    border:1px solid var(--border);
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#f8fafc;
    color:#64748b;
    font-size:12px;
    text-transform:uppercase;
    letter-spacing:1px;
    padding:16px 20px;
    text-align:left;
}

td{
    padding:16px 20px;
    border-top:1px solid var(--border);
}

tr:hover{
    background:#fcfdfe;
}

.btn-edit{
    color:var(--primary);
    margin-right:15px;
    font-size:18px;
    cursor:pointer;
}

.btn-delete{
    color:var(--danger);
    font-size:18px;
    cursor:pointer;
}

/* ================= MODAL ================= */

.modal{
    display:none;
    position:fixed;
    z-index:1000;
    left:0;
    top:0;
    width:100%;
    height:100%;
    background:rgba(0,0,0,.5);
}

.modal-content{
    background:white;
    width:420px;
    max-width:95%;
    margin:6% auto;
    padding:30px;
    border-radius:22px;
}

.modal-content h2{
    margin-top:0;
    color:var(--text-title);
}

.modal-content input{
    width:100%;
    padding:14px;
    margin:10px 0;
    border-radius:12px;
    border:1px solid var(--border);
    outline:none;
}

.modal-content input:focus{
    border-color:var(--primary);
}

.btn-save{
    width:100%;
    padding:14px;
    background:var(--primary);
    color:white;
    border:none;
    border-radius:12px;
    font-weight:700;
    cursor:pointer;
    margin-top:10px;
}

.btn-save:hover{
    background:var(--primary-hover);
}

.btn-cancel{
    width:100%;
    padding:12px;
    margin-top:10px;
    border:none;
    background:none;
    cursor:pointer;
    color:var(--text-body);
}

/* ================= MESSAGE ================= */

.message{
    margin-bottom:20px;
    padding:15px;
    border-radius:12px;
    font-weight:700;
    background:white;
    border:1px solid var(--border);
}

@media(max-width:900px){

    .sidebar{
        width:80px;
        padding:25px 10px;
    }

    .logo span,
    .menu-label,
    .menu-item span,
    .user-profile div{
        display:none;
    }

    .main-content{
        margin-left:80px;
    }
}

</style>

</head>

<body>

<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <div class="logo">
        <i class="fa-solid fa-bolt"></i>
        <span>BiBotFlip</span>
    </div>

    <div class="sidebar-nav">

        <a href="index.php" class="menu-item">
            <i class="fa-solid fa-house"></i>
            <span>Trang chủ</span>
        </a>

        <div class="menu-label">Thư viện của bạn</div>

        <a href="all_cards.php" class="menu-item">
            <i class="fa-solid fa-book-bookmark"></i>
            <span>Tất cả Flashcard</span>
        </a>

        <a href="online_exams.php" class="menu-item">
            <i class="fa-solid fa-folder-plus"></i>
            <span>Đề thi online</span>
        </a>

        <div class="menu-label">Quản trị hệ thống</div>

        <a href="admin_students.php" class="menu-item active">
            <i class="fa-solid fa-user-graduate"></i>
            <span>Quản lý sinh viên</span>
        </a>

        <div class="menu-label">Thẻ ghi nhớ</div>

        <a href="all_cards.php?filter=mastered" class="menu-item" style="color:var(--success);">
            <i class="fa-solid fa-circle-check"></i>
            <span>Đã ghi nhớ</span>
        </a>

        <a href="all_cards.php?filter=unlearned" class="menu-item" style="color:var(--danger);">
            <i class="fa-solid fa-circle-minus"></i>
            <span>Chưa ghi nhớ</span>
        </a>

        <div class="sidebar-footer">

            <a href="profile.php" class="user-profile">

                <div class="avatar">
                    <?php echo $_SESSION['initials'] ?? 'AD'; ?>
                </div>

                <div style="display:flex; flex-direction:column;">

                    <span style="font-weight:700; font-size:14px;">
                        <?php echo $_SESSION['display_name'] ?? 'Admin'; ?>
                    </span>

                    <span style="font-size:11px; color:var(--text-body);">
                        Quản trị viên
                    </span>

                </div>

            </a>

            <a href="logout.php" class="menu-item logout-link">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Đăng xuất</span>
            </a>

        </div>

    </div>

</div>

<!-- ================= MAIN ================= -->

<div class="main-content">

    <div class="header-flex">

        <div class="header-section">

            <h1>Quản lý sinh viên</h1>

            <p>
                Danh sách sinh viên đang hoạt động trên hệ thống
            </p>

        </div>

        <button class="btn-add" onclick="openModal('addModal')">

            <i class="fa-solid fa-plus"></i>

            Thêm sinh viên

        </button>

    </div>

    <?php if ($message != ""): ?>

        <div class="message">
            <?php echo $message; ?>
        </div>

    <?php endif; ?>

    <!-- SEARCH -->

    <div class="action-bar">

        <div class="search-box">

            <form method="GET">

                <input
                    type="text"
                    name="search"
                    placeholder="Tìm theo tên, email hoặc username..."
                    value="<?php echo htmlspecialchars($search); ?>"
                >

                <button type="submit" class="btn-search">
                    Tìm kiếm
                </button>

            </form>

        </div>

    </div>

    <!-- TABLE -->

    <div class="table-container">

        <table>

            <thead>

                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Họ tên</th>
                    <th>Email</th>
                    <th>Hành động</th>
                </tr>

            </thead>

            <tbody>

            <?php if ($result->num_rows > 0): ?>

                <?php while($row = $result->fetch_assoc()): ?>

                <tr>

                    <td>#<?php echo $row['id']; ?></td>

                    <td>
                        <?php echo htmlspecialchars($row['username']); ?>
                    </td>

                    <td style="font-weight:700;">
                        <?php echo htmlspecialchars($row['fullname']); ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars($row['email']); ?>
                    </td>

                    <td>

                        <a
                            class="btn-edit"
                            onclick="openEditModal(
                                '<?php echo $row['id']; ?>',
                                '<?php echo htmlspecialchars($row['fullname'], ENT_QUOTES); ?>',
                                '<?php echo htmlspecialchars($row['email'], ENT_QUOTES); ?>'
                            )"
                        >
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>

                        <a
                            href="?delete_id=<?php echo $row['id']; ?>"
                            class="btn-delete"
                            onclick="return confirm('Xóa sinh viên này?')"
                        >
                            <i class="fa-solid fa-trash"></i>
                        </a>

                    </td>

                </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td colspan="5" style="text-align:center; padding:40px;">
                        Không có dữ liệu
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<!-- ================= ADD MODAL ================= -->

<div id="addModal" class="modal">

    <div class="modal-content">

        <h2>Thêm sinh viên</h2>

        <form method="POST">

            <input
                type="text"
                name="username"
                placeholder="Tên đăng nhập"
                required
            >

            <input
                type="text"
                name="fullname"
                placeholder="Họ và tên"
                required
            >

            <input
                type="email"
                name="email"
                placeholder="Email"
                required
            >

            <input
                type="password"
                name="password"
                placeholder="Mật khẩu"
                required
            >

            <button
                type="submit"
                name="add_student"
                class="btn-save"
            >
                Lưu sinh viên
            </button>

            <button
                type="button"
                class="btn-cancel"
                onclick="closeModal('addModal')"
            >
                Hủy bỏ
            </button>

        </form>

    </div>

</div>

<!-- ================= EDIT MODAL ================= -->

<div id="editModal" class="modal">

    <div class="modal-content">

        <h2>Chỉnh sửa sinh viên</h2>

        <form method="POST">

            <input type="hidden" name="id" id="edit_id">

            <input
                type="text"
                name="fullname"
                id="edit_fullname"
                required
            >

            <input
                type="email"
                name="email"
                id="edit_email"
                required
            >

            <button
                type="submit"
                name="edit_student"
                class="btn-save"
            >
                Cập nhật
            </button>

            <button
                type="button"
                class="btn-cancel"
                onclick="closeModal('editModal')"
            >
                Hủy bỏ
            </button>

        </form>

    </div>

</div>

<script>

function openModal(id){

    document.getElementById(id).style.display = "block";
}

function closeModal(id){

    document.getElementById(id).style.display = "none";
}

function openEditModal(id, fullname, email){

    document.getElementById('edit_id').value = id;

    document.getElementById('edit_fullname').value = fullname;

    document.getElementById('edit_email').value = email;

    openModal('editModal');
}

window.onclick = function(event){

    if(event.target.className === 'modal'){

        event.target.style.display = "none";
    }
}

</script>

</body>
</html>