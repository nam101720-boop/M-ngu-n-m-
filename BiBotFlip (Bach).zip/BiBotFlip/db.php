<?php
// Bật hiển thị lỗi (chỉ dùng khi dev)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Thông tin kết nối database
$host = "localhost";
$username = "root";
$password = ""; // XAMPP mặc định là rỗng
$database = "BiBotFlip"; // đổi thành tên DB của bạn

// Tạo kết nối
$conn = new mysqli($host, $username, $password, $database);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối database thất bại: " . $conn->connect_error);
}

// Set charset để tránh lỗi tiếng Việt
$conn->set_charset("utf8mb4");

// (Tuỳ chọn) Set timezone
date_default_timezone_set("Asia/Ho_Chi_Minh");