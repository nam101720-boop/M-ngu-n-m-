<?php 
include 'config/db.php'; 

// Xử lý lưu đề thi
if (isset($_POST['add_exam'])) {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $duration = $_POST['duration'];

    $sql = "INSERT INTO exams (title, description, duration) VALUES ('$title', '$desc', '$duration')";
    if ($conn->query($sql)) {
        $exam_id = $conn->insert_id; // Lấy ID của đề vừa tạo để thêm câu hỏi
        echo "<script>alert('Đã tạo đề thi thành công! Bây giờ hãy thêm câu hỏi.'); window.location='admin_questions.php?exam_id=$exam_id';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Admin - Thêm đề thi</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f8fafc; padding: 50px; }
        .form-container { max-width: 600px; margin: auto; background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 15px rgba(0,0,0,0.05); }
        input, textarea { width: 100%; padding: 12px; margin: 10px 0 20px 0; border: 1px solid #e2e8f0; border-radius: 10px; box-sizing: border-box; }
        button { background: #6366f1; color: white; border: none; padding: 15px 30px; border-radius: 10px; font-weight: 700; cursor: pointer; width: 100%; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Tạo Đề Thi Mới (Admin)</h2>
    <form method="POST">
        <label>Tên đề thi:</label>
        <input type="text" name="title" placeholder="Ví dụ: Kiểm tra giữa kỳ Tiếng Anh" required>

        <label>Mô tả ngắn:</label>
        <textarea name="description" rows="3" placeholder="Mô tả nội dung đề thi..."></textarea>

        <label>Thời gian làm bài (phút):</label>
        <input type="number" name="duration" value="30" required>

        <button type="submit" name="add_exam">Tiếp theo: Thêm câu hỏi</button>
    </form>
</div>

</body>
</html>