<?php
include 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {

    $folder_name = $conn->real_escape_string($_POST['folder_name']);

    $description = "Bộ sưu tập các bài học về " . $folder_name;

    // THÊM TYPE
    $type = isset($_POST['type']) ? $conn->real_escape_string($_POST['type']) : 'personal';

    $sql = "INSERT INTO folders (name, description, type) 
            VALUES ('$folder_name', '$description', '$type')";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Lỗi: " . $conn->error;
    }

} else {
    header("Location: index.php");
    exit();
}
?>