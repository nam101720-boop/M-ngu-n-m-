<?php 
include 'config/db.php'; 

// 1. Lấy ID đề thi từ URL
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

// Lấy thông tin đề thi để hiển thị tiêu đề
$exam_info = $conn->query("SELECT title FROM exams WHERE id = $exam_id")->fetch_assoc();

if (!$exam_info) {
    die("Không tìm thấy đề thi!");
}

// 2. Xử lý khi nhấn nút Lưu câu hỏi
if (isset($_POST['save_question'])) {
    $question = $conn->real_escape_string($_POST['question']);
    $a = $conn->real_escape_string($_POST['option_a']);
    $b = $conn->real_escape_string($_POST['option_b']);
    $c = $conn->real_escape_string($_POST['option_c']);
    $d = $conn->real_escape_string($_POST['option_d']);
    $correct = $_POST['correct_option'];

    $sql = "INSERT INTO exam_questions (exam_id, question, option_a, option_b, option_c, option_d, correct_option) 
            VALUES ($exam_id, '$question', '$a', '$b', '$c', '$d', '$correct')";
    
    if ($conn->query($sql)) {
        // Sau khi lưu, load lại trang để nhập câu tiếp theo
        header("Location: admin_questions.php?exam_id=$exam_id&success=1");
        exit();
    }
}

// 3. Lấy danh sách câu hỏi đã có của đề này
$questions_result = $conn->query("SELECT * FROM exam_questions WHERE exam_id = $exam_id");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm câu hỏi - BiBotFlip Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --bg: #f8fafc; --text: #1e293b; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding: 40px; }
        .container { max-width: 900px; margin: auto; display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
        
        .box { background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 15px rgba(0,0,0,0.05); }
        h2 { font-size: 20px; margin-bottom: 20px; color: var(--text); }
        
        /* Form style */
        label { display: block; font-size: 13px; font-weight: 700; color: #64748b; margin-bottom: 5px; }
        input, textarea, select { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #e2e8f0; border-radius: 10px; box-sizing: border-box; font-family: inherit; }
        .option-group { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        
        .btn-save { background: var(--primary); color: white; border: none; padding: 15px; border-radius: 12px; font-weight: 700; cursor: pointer; width: 100%; transition: 0.3s; }
        .btn-save:hover { background: #4f46e5; }

        /* List style */
        .q-list { max-height: 500px; overflow-y: auto; }
        .q-item { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
        .q-item b { color: var(--primary); }
        
        .badge-success { background: #dcfce7; color: #10b981; padding: 10px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; text-align: center; }
    </style>
</head>
<body>

<div style="max-width: 900px; margin: 0 auto 20px auto;">
    <a href="online_exams.php" style="text-decoration: none; color: #64748b; font-weight: 600;">
        <i class="fa-solid fa-chevron-left"></i> Hoàn tất & Quay lại
    </a>
    <h1 style="margin-top: 10px;">Đề thi: <?php echo htmlspecialchars($exam_info['title']); ?></h1>
</div>

<div class="container">
    <div class="box">
        <h2><i class="fa-solid fa-plus-circle"></i> Thêm câu hỏi mới</h2>
        <?php if(isset($_GET['success'])) echo '<div class="badge-success">Đã lưu câu hỏi thành công!</div>'; ?>
        
        <form method="POST">
            <label>Nội dung câu hỏi:</label>
            <textarea name="question" rows="3" required placeholder="Nhập câu hỏi tại đây..."></textarea>

            <div class="option-group">
                <div>
                    <label>Đáp án A:</label>
                    <input type="text" name="option_a" required>
                </div>
                <div>
                    <label>Đáp án B:</label>
                    <input type="text" name="option_b" required>
                </div>
                <div>
                    <label>Đáp án C:</label>
                    <input type="text" name="option_c" required>
                </div>
                <div>
                    <label>Đáp án D:</label>
                    <input type="text" name="option_d" required>
                </div>
            </div>

            <label>Đáp án đúng:</label>
            <select name="correct_option" required>
                <option value="A">Câu A</option>
                <option value="B">Câu B</option>
                <option value="C">Câu C</option>
                <option value="D">Câu D</option>
            </select>

            <button type="submit" name="save_question" class="btn-save">
                <i class="fa-solid fa-floppy-disk"></i> Lưu & Tiếp tục câu khác
            </button>
        </form>
    </div>

    <div class="box">
        <h2><i class="fa-solid fa-list-ul"></i> Câu hỏi đã thêm (<?php echo $questions_result->num_rows; ?>)</h2>
        <div class="q-list">
            <?php if ($questions_result->num_rows > 0): ?>
                <?php $count = 1; while($q = $questions_result->fetch_assoc()): ?>
                    <div class="q-item">
                        <b>Câu <?php echo $count++; ?>:</b> <?php echo htmlspecialchars($q['question']); ?>
                        <div style="font-size: 12px; color: #10b981; margin-top: 5px;">
                            Đáp án đúng: <?php echo $q['correct_option']; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="color: #94a3b8; text-align: center; margin-top: 50px;">Chưa có câu hỏi nào.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>