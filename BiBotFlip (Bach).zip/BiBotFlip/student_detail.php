<?php
session_start();
include 'config/db.php';

// 🔒 Chỉ admin được vào
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Lấy ID sinh viên
$user_id = intval($_GET['id'] ?? 0);

if ($user_id <= 0) {
    die("User không hợp lệ");
}

// Lấy username
$user = $conn->query("SELECT username FROM users WHERE id = $user_id")->fetch_assoc();

if (!$user) {
    die("Không tìm thấy user");
}

// ================== QUERY CHUẨN ==================
$sql = "
SELECT 
    l.id,
    l.name,

    COUNT(DISTINCT c.id) AS total_cards,

    COUNT(DISTINCT CASE 
        WHEN p.mastery_level >= 3 THEN c.id 
    END) AS mastered

FROM lessons l

LEFT JOIN cards c 
    ON c.lesson_id = l.id

LEFT JOIN user_card_progress p 
    ON p.card_id = c.id 
    AND p.user_id = $user_id

GROUP BY l.id
ORDER BY l.id ASC
";

$result = $conn->query($sql);

if (!$result) {
    die("Lỗi SQL: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chi tiết sinh viên</title>

<style>
body {
    font-family: Arial;
    background: #f8fafc;
    padding: 30px;
}

h1 {
    margin-bottom: 20px;
}

a {
    display: inline-block;
    margin-bottom: 20px;
    text-decoration: none;
    color: #6366f1;
    font-weight: bold;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 12px;
    overflow: hidden;
}

th, td {
    padding: 12px;
    text-align: center;
}

th {
    background: #6366f1;
    color: white;
}

tr:nth-child(even) {
    background: #f1f5f9;
}

.progress-bar {
    background: #e5e7eb;
    height: 10px;
    border-radius: 5px;
    overflow: hidden;
}

.fill {
    background: #6366f1;
    height: 100%;
}
</style>

</head>
<body>

<h1>📘 Chi tiết: <?php echo htmlspecialchars($user['username']); ?></h1>

<a href="admin_dashboard.php">← Quay lại</a>

<table>
<tr>
    <th>Lesson</th>
    <th>Tổng card</th>
    <th>Đã thuộc</th>
    <th>Tiến độ</th>
</tr>

<?php while($row = $result->fetch_assoc()): 

    $total = $row['total_cards'] ?? 0;
    $mastered = $row['mastered'] ?? 0;

    $progress = ($total > 0) 
        ? round(($mastered / $total) * 100) 
        : 0;
?>

<tr>
    <td><?php echo htmlspecialchars($row['name']); ?></td>
    <td><?php echo $total; ?></td>
    <td><?php echo $mastered; ?></td>

    <td>
        <?php echo $progress; ?>%
        <div class="progress-bar">
            <div class="fill" style="width: <?php echo $progress; ?>%"></div>
        </div>
    </td>
</tr>

<?php endwhile; ?>

</table>

</body>
</html>