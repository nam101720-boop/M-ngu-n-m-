<?php 
session_start();
include 'config/db.php';

$user_id = $_SESSION['user_id'];

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

/*
================= FIX CHÍNH =================
Thêm bảng user_card_progress để xác định trạng thái theo từng user
*/
$sql = "SELECT c.*, l.name as lesson_name, f.name as folder_name,
        p.mastery_level
        FROM cards c
        JOIN lessons l ON c.lesson_id = l.id
        JOIN folders f ON l.folder_id = f.id
        LEFT JOIN user_card_progress p 
        ON p.card_id = c.id AND p.user_id = $user_id";

/*
================= FILTER (GIỮ NGUYÊN STYLE LOGIC) =================
Chỉ đổi điều kiện mastery_level sang bảng progress
*/
if ($filter == 'unlearned') { 
    $sql .= " WHERE (p.mastery_level IS NULL OR p.mastery_level = 0)"; 
} 
elseif ($filter == 'mastered') { 
    $sql .= " WHERE p.mastery_level >= 3"; 
} 
elseif ($filter == 'starred') { 
    $sql .= " WHERE c.is_starred = 1"; 
} 
elseif ($filter == 'noted') { 
    $sql .= " WHERE c.notes IS NOT NULL AND c.notes != ''"; 
}

$sql .= " ORDER BY c.created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Flashcard - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --bg: #f8fafc; --text: #1e293b; --star: #f59e0b; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding: 40px; }
        .container { max-width: 1100px; margin: auto; }
        .tabs { display: flex; gap: 10px; margin-bottom: 30px; }
        .tab-item { 
            text-decoration: none; padding: 10px 20px; border-radius: 12px; background: white; 
            color: #64748b; font-weight: 600; border: 1px solid #f1f5f9; 
        }
        .tab-item.active { background: var(--primary); color: white; }
        .tab-item.active.star-tab { background: var(--star); border-color: var(--star); }
        
        .card-table { width: 100%; background: white; border-radius: 20px; border-collapse: collapse; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }
        .card-table th { background: #f8fafc; padding: 15px 20px; text-align: left; color: #94a3b8; font-size: 12px; }
        .card-table td { padding: 20px; border-bottom: 1px solid #f8fafc; }
        
        .star-icon { cursor: pointer; font-size: 18px; color: #cbd5e1; transition: 0.2s; }
        .star-icon.active { color: var(--star); }
    </style>
</head>
<body>
<div class="container">
    <a href="index.php" style="text-decoration:none; color:var(--primary); font-weight:700;"><i class="fa-solid fa-arrow-left"></i> Quay lại</a>
    <h1>Thư viện Flashcard</h1>

    <div class="tabs">
        <a href="all_cards.php?filter=all" class="tab-item <?php echo $filter=='all'?'active':''; ?>">Tất cả</a>
        <a href="all_cards.php?filter=unlearned" class="tab-item <?php echo $filter=='unlearned'?'active':''; ?>">Chưa thuộc</a>
        <a href="all_cards.php?filter=starred" class="tab-item star-tab <?php echo $filter=='starred'?'active':''; ?>">
            <i class="fa-solid fa-star"></i> Đã gắn sao
        </a>
        <a href="all_cards.php?filter=noted" class="tab-item <?php echo $filter=='noted'?'active':''; ?>">Có ghi chú</a>
    </div>

    <table class="card-table">
        <thead>
            <tr>
                <th></th>
                <th>Từ vựng</th>
                <th>Định nghĩa</th>
                <th>Bộ thẻ</th>
                <th>Trạng thái</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>

            <?php $status = $row['mastery_level'] ?? 0; ?>

            <tr>
                <td>
                    <i class="fa-star <?php echo $row['is_starred']?'fa-solid active':'fa-regular'; ?> star-icon" 
                       onclick="toggleStar(this, <?php echo $row['id']; ?>)"></i>
                </td>

                <td style="font-weight:800;"><?php echo $row['term']; ?></td>
                <td><?php echo $row['definition']; ?></td>
                <td style="font-size:12px; color:#94a3b8;"><?php echo $row['folder_name']; ?></td>

                <td>
                    <span style="font-size:11px; font-weight:800; text-transform:uppercase; color:
                        <?php echo $status==0?'#ef4444':'#10b981'; ?>">
                        
                        <?php echo $status==0?'Chưa thuộc':'Đang học'; ?>
                    </span>
                </td>
            </tr>

            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script>
function toggleStar(element, cardId) {
    fetch('update_star.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'card_id=' + cardId
    }).then(() => {
        element.classList.toggle('fa-solid');
        element.classList.toggle('fa-regular');
        element.classList.toggle('active');
    });
}
</script>
</body>
</html>