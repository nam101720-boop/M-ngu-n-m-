<?php
session_start();
include 'config/db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';

$message = "";

if (isset($_POST['send_code'])) {

    $username = trim($_POST['username']);
    $email = trim($_POST['email']);

    if ($username == "" || $email == "") {
        $message = "❌ Vui lòng nhập đầy đủ thông tin!";
    } else {

        // 1. Tìm user
        $sql = "SELECT * FROM users WHERE email=? AND username=?";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("Lỗi prepare: " . $conn->error);
        }

        $stmt->bind_param("ss", $email, $username);

        if (!$stmt->execute()) {
            die("Lỗi execute: " . $stmt->error);
        }

        $result = $stmt->get_result(); // ⚠️ QUAN TRỌNG

        if ($result->num_rows == 0) {
            $message = "❌ Thông tin không đúng!";
        } else {

            $user = $result->fetch_assoc();

            // 2. Tạo mã reset
            $code = rand(100000, 999999);
            $expire = date("Y-m-d H:i:s", strtotime("+10 minutes"));

            $sql = "UPDATE users SET reset_code=?, reset_expire=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $code, $expire, $user['id']);
            $stmt->execute();

            // 3. Gửi mail
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'your_email@gmail.com'; // ⚠️ đổi
                $mail->Password = 'your_app_password';     // ⚠️ đổi
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('your_email@gmail.com', 'BiBotFlip');
                $mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Mã đặt lại mật khẩu';
                $mail->Body = "Mã xác nhận của bạn là: <b>$code</b> (hết hạn sau 10 phút)";

                $mail->send();

                $_SESSION['reset_email'] = $email;

                header("Location: reset_password.php");
                exit();

            } catch (Exception $e) {
                $message = "❌ Không gửi được email!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quên mật khẩu</title>
<style>
body{font-family:sans-serif;background:#f8fafc;display:flex;justify-content:center;align-items:center;height:100vh}
.card{background:white;padding:30px;border-radius:20px;width:350px}
input{width:100%;padding:10px;margin:10px 0;border:1px solid #ddd;border-radius:10px}
button{width:100%;padding:12px;background:#6366f1;color:white;border:none;border-radius:10px}
.msg{color:red;margin-bottom:10px}
</style>
</head>
<body>

<div class="card">
<h2>Quên mật khẩu</h2>

<?php if($message) echo "<div class='msg'>$message</div>"; ?>

<form method="POST">
    <input type="text" name="username" placeholder="Tên đăng nhập" required>
    <input type="email" name="email" placeholder="Email" required>
    <button name="send_code">Gửi mã</button>
</form>

</div>

</body>
</html>