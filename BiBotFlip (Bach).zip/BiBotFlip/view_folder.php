<?php 
session_start();
include 'config/db.php';

$folder_id = intval($_GET['id'] ?? 0);

$user_id = $_SESSION['user_id'] ?? 0;
$user_role = $_SESSION['role'] ?? 'student';

/* =========================
   GET FOLDER
========================= */
$folder = $conn->query("SELECT * FROM folders WHERE id = $folder_id")->fetch_assoc();

if (!$folder) {
    die("Folder không tồn tại");
}

/* =========================
   ADD LESSON
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_lesson'])) {

    $lesson_name = trim($_POST['lesson_name']);

    if (empty($lesson_name)) {
        die("Tên bài học không được để trống");
    }

    $lesson_name = $conn->real_escape_string($lesson_name);

    // mặc định
    $type = 'personal';

    // folder hệ thống
    if ($folder['type'] === 'system') {

        if ($user_role !== 'admin') {
            die("Không có quyền thêm vào folder hệ thống");
        }

        $type = 'system';
    }
    // folder cá nhân
    else {

        if ($user_role === 'admin') {
            $type = $_POST['type'] ?? 'personal';
        }
    }

    $conn->query("
        INSERT INTO lessons (folder_id, name, type, user_id)
        VALUES ($folder_id, '$lesson_name', '$type', $user_id)
    ");

    header("Location: view_folder.php?id=$folder_id");
    exit();
}

/* =========================
   LESSON LIST
========================= */
$sql = "
    SELECT 
        l.*,
        (
            SELECT COUNT(*) 
            FROM cards c 
            WHERE c.lesson_id = l.id
        ) AS card_count

    FROM lessons l

    WHERE l.folder_id = $folder_id

    AND (
        l.type = 'system'
        OR l.user_id = $user_id
        OR '$user_role' = 'admin'
    )

    ORDER BY l.id ASC
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">

<title><?= htmlspecialchars($folder['name']) ?></title>

<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

:root{
    --primary:#6366f1;
    --bg:#f8fafc;
    --text:#1e293b;
    --muted:#64748b;
    --border:#f1f5f9;
    --success:#10b981;
    --danger:#ef4444;
}

body{
    font-family:'Plus Jakarta Sans', sans-serif;
    background:var(--bg);
    margin:0;
    padding:40px 20px;
}

.container{
    max-width:900px;
    margin:auto;
}

.header{
    margin-bottom:40px;
}

.btn-back{
    text-decoration:none;
    color:var(--muted);
    font-weight:600;
}

h1{
    margin:0;
    font-size:32px;
    font-weight:800;
    color:var(--text);
}

.description{
    margin-top:10px;
    color:var(--muted);
    border-left:4px solid var(--primary);
    padding-left:15px;
}

.lesson-list{
    display:flex;
    flex-direction:column;
    gap:20px;
    margin-top:30px;
}

.lesson-card{
    background:white;
    padding:25px;
    border-radius:24px;
    border:1px solid var(--border);
    transition:0.2s;
}

.lesson-card:hover{
    border-color:var(--primary);
    transform:translateY(-2px);
}

.type-badge{
    font-size:11px;
    padding:4px 10px;
    border-radius:6px;
    background:#e0e7ff;
    color:var(--primary);
    font-weight:800;
    display:inline-block;
}

.lesson-title{
    font-size:20px;
    font-weight:700;
    margin:15px 0 8px;
    color:var(--text);
}

.lesson-stats{
    font-size:13px;
    color:var(--muted);
}

.action-group{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:10px;
    margin-top:15px;
}

.btn{
    text-align:center;
    padding:10px;
    border-radius:10px;
    text-decoration:none;
    font-weight:700;
    font-size:13px;
    transition:0.2s;
}

.btn:hover{
    transform:translateY(-2px);
}

.add{
    background:#f1f5f9;
    color:#475569;
}

.study{
    background:#eef2ff;
    color:var(--primary);
}

.practice{
    background:#ecfdf5;
    color:var(--success);
}

.test{
    background:#fff1f2;
    color:var(--danger);
}

/* FORM */

.form-box{
    margin-top:20px;
    background:white;
    padding:20px;
    border-radius:16px;
    border:1px solid var(--border);
}

.form-box form{
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

.form-box input,
.form-box select{
    padding:12px;
    border:1px solid var(--border);
    border-radius:10px;
}

.form-box input[type="text"]{
    flex:1;
}

.submit-btn{
    padding:12px 20px;
    background:var(--primary);
    color:white;
    border:none;
    border-radius:10px;
    font-weight:700;
    cursor:pointer;
}

.empty{
    background:white;
    padding:40px;
    border-radius:20px;
    text-align:center;
    color:var(--muted);
    border:1px dashed var(--border);
}

@media(max-width:768px){

    .action-group{
        grid-template-columns:repeat(2,1fr);
    }

}

</style>

</head>

<body>

<div class="container">

    <div class="header">

        <a href="index.php" class="btn-back">
            ← Quay lại
        </a>

        <h1><?= htmlspecialchars($folder['name']) ?></h1>

        <div class="description">
            <?= htmlspecialchars($folder['description']) ?>
        </div>

        <!-- ================= ADD LESSON ================= -->

        <?php if ($folder['type'] === 'personal' || $user_role === 'admin'): ?>

        <div class="form-box">

            <form method="POST">

                <input 
                    type="text" 
                    name="lesson_name"
                    placeholder="Tên bài học..."
                    required
                >

                <?php if ($user_role === 'admin' && $folder['type'] !== 'system'): ?>

                    <select name="type">
                        <option value="personal">Cá nhân</option>
                        <option value="system">Hệ thống</option>
                    </select>

                <?php else: ?>

                    <input 
                        type="hidden" 
                        name="type" 
                        value="<?= $folder['type'] == 'system' ? 'system' : 'personal' ?>"
                    >

                <?php endif; ?>

                <button type="submit" name="add_lesson" class="submit-btn">
                    + Thêm
                </button>

            </form>

        </div>

        <?php endif; ?>

    </div>

    <!-- ================= LESSON LIST ================= -->

    <div class="lesson-list">

    <?php if ($result && $result->num_rows > 0): ?>

        <?php while($row = $result->fetch_assoc()): ?>

        <div class="lesson-card">

            <span class="type-badge">
                <?= $row['type'] == 'system' ? 'Hệ thống' : 'Cá nhân' ?>
            </span>

            <h3 class="lesson-title">
                <?= htmlspecialchars($row['name']) ?>
            </h3>

            <div class="lesson-stats">
                📦 <?= $row['card_count'] ?> thẻ
            </div>

            <div class="action-group">

                <!-- FIXED -->
                <a 
                    class="btn add" 
                    href="add_card.php?f_id=<?= $folder_id ?>&l_id=<?= $row['id'] ?>"
                >
                    + Thẻ
                </a>

                <a 
                    class="btn study" 
                    href="study_flashcard.php?lesson_id=<?= $row['id'] ?>&f_id=<?= $folder_id ?>"
                >
                    Học
                </a>

                <a 
                    class="btn practice" 
                    href="practice.php?lesson_id=<?= $row['id'] ?>&f_id=<?= $folder_id ?>"
                >
                    Luyện
                </a>

                <a 
                    class="btn test" 
                    href="test.php?lesson_id=<?= $row['id'] ?>&f_id=<?= $folder_id ?>"
                >
                    Thi
                </a>

            </div>

        </div>

        <?php endwhile; ?>

    <?php else: ?>

        <div class="empty">
            Chưa có bài học nào trong folder này
        </div>

    <?php endif; ?>

    </div>

</div>

</body>
</html>