<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Lấy thông tin user
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];

    // Chỉ update fullname + email
    $sql = "UPDATE users SET fullname=?, email=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $fullname, $email, $user_id);

    if ($stmt->execute()) {
        $message = "Cập nhật thành công!";
        $_SESSION['display_name'] = $fullname;
    } else {
        $message = "Có lỗi xảy ra!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chỉnh sửa thông tin</title>
<style>
body{font-family:Arial;background:#f8fafc;padding:40px;}
.box{max-width:500px;margin:auto;background:white;padding:30px;border-radius:20px;}
input{width:100%;padding:10px;margin:10px 0;border:1px solid #ddd;border-radius:10px;}
button{background:#6366f1;color:white;padding:10px;border:none;border-radius:10px;width:100%;}
a{display:inline-block;margin-bottom:15px;text-decoration:none;color:#6366f1;font-weight:700;}
.change-pass{display:block;margin-top:15px;text-align:center;color:#ef4444;}
</style>
</head>
<body>

<div class="box">

<a href="profile.php">← Quay lại</a>

<h2>Chỉnh sửa thông tin</h2>

<?php if($message) echo "<p><b>$message</b></p>"; ?>

<form method="POST">
    <input type="text" name="fullname" value="<?php echo $user['fullname']; ?>" placeholder="Họ tên" required>
    <input type="email" name="email" value="<?php echo $user['email']; ?>" placeholder="Email" required>
    <button type="submit">Cập nhật</button>
</form>

<!-- Nút chuyển sang trang đổi mật khẩu -->
<a href="change_password.php" class="change-pass">Đổi mật khẩu</a>

</div>

</body>
</html>