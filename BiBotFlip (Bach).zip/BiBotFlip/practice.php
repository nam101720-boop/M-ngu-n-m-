<?php 
session_start();
include 'config/db.php';

$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : 0;
$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0;

$user_id = $_SESSION['user_id'] ?? 0;

$sql = "
SELECT 
    c.id,
    c.term,
    c.definition,
    c.example,
    COALESCE(p.mastery_level, 0) AS mastery_level
FROM cards c
LEFT JOIN user_card_progress p 
    ON p.card_id = c.id 
    AND p.user_id = $user_id
WHERE c.lesson_id = $lesson_id
ORDER BY RAND()
";

$result = $conn->query($sql);

$cards = [];

if ($result && $result->num_rows > 0) {
    $cards = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Luyện tập - BiBotFlip</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

:root{
    --primary:#10b981;
    --danger:#ef4444;
    --bg:#f8fafc;
    --white:#fff;
}

body{
    font-family:'Plus Jakarta Sans', sans-serif;
    background:var(--bg);
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    margin:0;
}

.practice-container{
    width:520px;
    background:var(--white);
    padding:35px;
    border-radius:25px;
    text-align:center;
    box-shadow:0 10px 30px rgba(0,0,0,0.05);
}

.top-bar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.exit-btn{
    text-decoration:none;
    color:#64748b;
    font-weight:700;
}

.progress{
    font-weight:700;
    color:#64748b;
}

.hint-def{
    font-size:28px;
    font-weight:800;
    color:#1e293b;
    margin-bottom:25px;
}

.example{
    margin-top:10px;
    color:#64748b;
    font-style:italic;
}

input{
    width:100%;
    padding:16px;
    border-radius:14px;
    border:2px solid #e2e8f0;
    font-size:18px;
    text-align:center;
    outline:none;
    box-sizing:border-box;
}

.success{
    border-color:var(--primary);
    background:#ecfdf5;
}

.error{
    border-color:var(--danger);
    background:#fef2f2;
}

.feedback{
    margin-top:18px;
    font-weight:700;
    min-height:24px;
}

.finish-box{
    text-align:center;
}

.finish-score{
    width:120px;
    height:120px;
    border-radius:50%;
    background:var(--primary);
    color:white;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:30px;
    font-weight:800;
    margin:0 auto 20px;
}

.finish-btn{
    display:inline-block;
    margin-top:20px;
    padding:14px 30px;
    border-radius:14px;
    background:#6366f1;
    color:white;
    text-decoration:none;
    font-weight:700;
}

.empty{
    color:#64748b;
    font-size:18px;
}

</style>
</head>

<body>

<div class="practice-container">

    <div class="top-bar">
        <a href="view_folder.php?id=<?php echo $f_id; ?>" class="exit-btn">
            <i class="fa-solid fa-arrow-left"></i> Quay lại
        </a>

        <div class="progress" id="progress">
            0 / 0
        </div>
    </div>

    <div id="practice-area">

        <div class="hint-def" id="def">
            Đang tải...
        </div>

        <div class="example" id="example"></div>

        <input 
            type="text" 
            id="input" 
            placeholder="Nhập từ tiếng Anh..."
            autocomplete="off"
        >

        <div class="feedback" id="fb"></div>

    </div>

    <div class="finish-box" id="finish-box" style="display:none;">
        <div class="finish-score" id="score-box">
            0/0
        </div>

        <h2>Hoàn thành luyện tập!</h2>

        <a href="view_folder.php?id=<?php echo $f_id; ?>" class="finish-btn">
            Quay lại bài học
        </a>
    </div>

</div>

<script>

const cards = <?php echo json_encode($cards); ?>;

let i = 0;
let correctCount = 0;

const input = document.getElementById("input");
const def = document.getElementById("def");
const fb = document.getElementById("fb");
const example = document.getElementById("example");
const progress = document.getElementById("progress");

function load() {

    if(cards.length === 0){

        def.innerHTML = "Không có flashcard";
        input.style.display = "none";
        progress.innerHTML = "0 / 0";

        return;
    }

    if(i >= cards.length){

        document.getElementById("practice-area").style.display = "none";
        document.getElementById("finish-box").style.display = "block";

        document.getElementById("score-box").innerHTML =
            `${correctCount}/${cards.length}`;

        return;
    }

    input.classList.remove("success", "error");

    const card = cards[i];

    def.innerText = card.definition;

    example.innerText = card.example
        ? `"${card.example}"`
        : "";

    progress.innerHTML = `${i + 1} / ${cards.length}`;

    input.value = "";
    fb.innerHTML = "";

    input.focus();
}

input.addEventListener("keypress", function(e){

    if(e.key === "Enter"){
        check();
    }

});

function check(){

    const card = cards[i];

    let answer = input.value.trim().toLowerCase();

    let correct = card.term
        .split("/")[0]
        .trim()
        .toLowerCase();

    let status = (answer === correct)
        ? "correct"
        : "wrong";

    input.classList.remove("success", "error");

    if(status === "correct"){

        input.classList.add("success");

        fb.innerHTML = "✔ Chính xác";

        correctCount++;

        setTimeout(() => {

            i++;
            load();

        }, 800);

    } else {

        input.classList.add("error");

        fb.innerHTML =
            `✖ Sai — Đáp án: <b>${card.term}</b>`;
    }

    fetch("update_mastery.php", {

        method: "POST",

        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },

        body:
            `user_id=<?php echo $user_id; ?>` +
            `&card_id=${card.id}` +
            `&status=${status}`

    });

}

load();

</script>

</body>
</html>