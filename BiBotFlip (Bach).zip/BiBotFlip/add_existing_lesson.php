<?php
include 'config/db.php';
session_start();

$folder_id = intval($_POST['folder_id']);
$lesson_id = intval($_POST['lesson_id']);
$user_role = $_SESSION['role'] ?? 'student';

// kiểm tra folder
$folder = $conn->query("SELECT * FROM folders WHERE id=$folder_id")->fetch_assoc();
$lesson = $conn->query("SELECT * FROM lessons WHERE id=$lesson_id")->fetch_assoc();

if (!$folder || !$lesson) {
    die("Dữ liệu không hợp lệ");
}

// RULE 1: folder system chỉ admin
if ($folder['type'] === 'system' && $user_role !== 'admin') {
    die("Không có quyền");
}

// RULE 2: folder system chỉ nhận lesson system
if ($folder['type'] === 'system' && $lesson['type'] !== 'system') {
    die("Folder hệ thống chỉ nhận lesson hệ thống");
}

// RULE 3: tránh duplicate
$check = $conn->query("
    SELECT id FROM folder_lessons 
    WHERE folder_id=$folder_id AND lesson_id=$lesson_id
");

if ($check->num_rows == 0) {
    $conn->query("
        INSERT INTO folder_lessons (folder_id, lesson_id)
        VALUES ($folder_id, $lesson_id)
    ");
}

header("Location: view_folder.php?id=$folder_id");
exit;