<?php 
include 'auth.php';
include 'config/db.php'; 
$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : 0;
$cards_sql = "SELECT * FROM cards WHERE lesson_id = $lesson_id";
$cards_res = $conn->query($cards_sql);
$cards = [];
while($row = $cards_res->fetch_assoc()) { $cards[] = $row; }
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Học Flashcard - BiBotFlip</title>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f1f5f9; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        
        /* Hiệu ứng lật thẻ 3D */
        .flashcard-container { width: 400px; height: 250px; perspective: 1000px; cursor: pointer; }
        .flashcard { 
            width: 100%; height: 100%; position: relative; 
            transition: transform 0.6s; transform-style: preserve-3d; 
        }
        .flashcard.flipped { transform: rotateY(180deg); }
        
        .face { 
            position: absolute; width: 100%; height: 100%; 
            backface-visibility: hidden; display: flex; align-items: center; 
            justify-content: center; font-size: 2rem; font-weight: 800;
            border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .front { background: white; color: #6366f1; }
        .back { background: #6366f1; color: white; transform: rotateY(180deg); }

        .controls { margin-top: 30px; display: flex; gap: 20px; }
        button { padding: 12px 25px; border-radius: 12px; border: none; background: white; font-weight: bold; cursor: pointer; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

    <div class="flashcard-container" onclick="this.children[0].classList.toggle('flipped')">
        <div class="flashcard" id="card-inner">
            <div class="face front" id="text-front">English Word</div>
            <div class="face back" id="text-back">Nghĩa Tiếng Việt</div>
        </div>
    </div>

    <div class="controls">
        <button onclick="prevCard()">Trước đó</button>
        <span id="counter">1 / 10</span>
        <button onclick="nextCard()">Tiếp theo</button>
    </div>

    <script>
        const cards = <?php echo json_encode($cards); ?>;
        let currentIndex = 0;

        function updateCard() {
            if(cards.length === 0) return;
            document.getElementById('card-inner').classList.remove('flipped');
            setTimeout(() => {
                document.getElementById('text-front').innerText = cards[currentIndex].term;
                document.getElementById('text-back').innerText = cards[currentIndex].definition;
                document.getElementById('counter').innerText = `${currentIndex + 1} / ${cards.length}`;
            }, 200);
        }

        function nextCard() {
            if (currentIndex < cards.length - 1) { currentIndex++; updateCard(); }
        }

        function prevCard() {
            if (currentIndex > 0) { currentIndex--; updateCard(); }
        }

        updateCard();
    </script>
</body>
</html>