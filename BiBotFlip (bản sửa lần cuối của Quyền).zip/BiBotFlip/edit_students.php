<?php
session_start();
include 'auth.php';
include 'config/db.php';

$id = $_GET['id'];
$res = $conn->query("SELECT * FROM users WHERE id = $id");
$student = $res->fetch_assoc();

if (isset($_POST['update'])) {
    $name = $_POST['fullname'];
    $email = $_POST['email'];
    $conn->query("UPDATE users SET fullname='$name', email='$email' WHERE id=$id");
    header("Location: admin_students.php?msg=updated");
}
?>
<div class="add-box">
    <h2>Chỉnh sửa thông tin</h2>
    <form method="POST">
        <input type="text" name="fullname" value="<?php echo $student['fullname']; ?>" required>
        <input type="email" name="email" value="<?php echo $student['email']; ?>" required>
        <button type="submit" name="update">Cập nhật</button>
    </form>
</div>