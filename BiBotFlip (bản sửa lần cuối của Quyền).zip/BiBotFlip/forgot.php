<?php
include 'config/db.php';

$msg = "";

if (isset($_POST['find'])) {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];

    $sql = "SELECT password FROM users 
            WHERE fullname='$fullname' AND email='$email'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $msg = "Mật khẩu của bạn: <b>" . $row['password'] . "</b>";
    } else {
        $msg = "Không tìm thấy tài khoản!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quên mật khẩu</title>

<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
:root { --primary: #6366f1; --bg: #f8fafc; }

body {
    font-family: 'Plus Jakarta Sans', sans-serif;
    background: var(--bg);
    height: 100vh;
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.card {
    background: white;
    padding: 40px;
    border-radius: 24px;
    box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
    width: 100%;
    max-width: 400px;
}

.logo {
    text-align: center;
    color: var(--primary);
    font-size: 30px;
    font-weight: 800;
    margin-bottom: 30px;
}

.form-group { margin-bottom: 15px; }

.form-group input {
    width: 100%;
    padding: 12px;
    border-radius: 12px;
    border: 2px solid #f1f5f9;
}

.btn {
    width: 100%;
    padding: 14px;
    border: none;
    background: #ef4444;
    color: white;
    border-radius: 12px;
    font-weight: 800;
}

.msg {
    background: #fef2f2;
    color: red;
    padding: 10px;
    border-radius: 10px;
    text-align: center;
    margin-bottom: 10px;
}
</style>
</head>

<body>

<div class="card">
    <div class="logo"><i class="fa-solid fa-bolt"></i> BiBotFlip</div>

    <?php if($msg): ?>
        <div class="msg"><?php echo $msg; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <input type="text" name="fullname" placeholder="Họ tên" required>
        </div>

        <div class="form-group">
            <input type="email" name="email" placeholder="Email" required>
        </div>

        <button name="find" class="btn">Tìm mật khẩu</button>
    </form>

    <br>
    <a href="login.php">← Quay lại đăng nhập</a>
</div>

</body>
</html>