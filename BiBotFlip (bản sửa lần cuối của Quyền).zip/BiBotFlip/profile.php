<?php 
include 'auth.php';
include 'config/db.php'; 

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$display_name = $_SESSION['display_name'];
$initials = $_SESSION['initials'];

$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();

/* FLASHCARD (toàn hệ thống) */
$total_cards = $conn->query("SELECT COUNT(*) as total FROM cards")->fetch_assoc()['total'];

/* USER */
$total_folders_user = $conn->query("SELECT COUNT(*) as total FROM folders WHERE user_id = $user_id")->fetch_assoc()['total'];

/* ADMIN */
if($user_role == 'admin'){
    $total_users = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
    $total_folders = $conn->query("SELECT COUNT(*) as total FROM folders")->fetch_assoc()['total'];
    $students = $conn->query("SELECT * FROM users WHERE role='user'");
}

/* UPDATE */
if(isset($_POST['update'])){
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];

    $conn->query("UPDATE users SET 
        fullname='$fullname',
        email='$email'
        WHERE id=$user_id");

    header("Location: profile.php");
}

/* CHANGE PASS */
if(isset($_POST['change_pass'])){
    $old = $_POST['old_pass'];
    $new = $_POST['new_pass'];

    $check = $conn->query("SELECT * FROM users WHERE id=$user_id AND password='$old'");

    if($check->num_rows > 0){
        $conn->query("UPDATE users SET password='$new' WHERE id=$user_id");
        echo "<script>alert('Đổi mật khẩu thành công');</script>";
    } else {
        echo "<script>alert('Sai mật khẩu cũ');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Hồ sơ cá nhân - BiBotFlip</title>

<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
:root { --primary: #6366f1; --bg: #f8fafc; }

body {
    font-family: 'Plus Jakarta Sans', sans-serif;
    background: var(--bg);
    margin: 0;
}

.container {
    max-width: 1000px;
    margin: 50px auto;
    padding: 20px;
}

.profile-header {
    background: white;
    padding: 30px;
    border-radius: 20px;
    display: flex;
    gap: 20px;
}

.avatar-large {
    width: 100px;
    height: 100px;
    background: var(--primary);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 40px;
    border-radius: 20px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px,1fr));
    gap: 20px;
    margin-top: 30px;
}

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 15px;
    text-align: center;
}

.stat-value {
    font-size: 30px;
    font-weight: bold;
}

.progress-section {
    background: white;
    padding: 25px;
    margin-top: 30px;
    border-radius: 20px;
}
</style>
</head>

<body>

<div class="container">

<a href="index.php">← Quay lại</a>

<div class="profile-header">
    <div class="avatar-large"><?php echo $initials; ?></div>
    <div>
        <h2><?php echo $display_name; ?></h2>
        <p><?php echo $user['email']; ?></p>
    </div>
</div>

<div class="stats-grid">

<?php if($user_role == 'admin'): ?>

<div class="stat-card">
    <div class="stat-value"><?php echo $total_users; ?></div>
    Người dùng
</div>

<div class="stat-card">
    <div class="stat-value"><?php echo $total_folders; ?></div>
    Thư viện
</div>

<div class="stat-card">
    <div class="stat-value"><?php echo $total_cards; ?></div>
    Flashcard
</div>

<?php else: ?>

<div class="stat-card">
    <div class="stat-value"><?php echo $total_cards; ?></div>
    Flashcard hệ thống
</div>

<div class="stat-card">
    <div class="stat-value"><?php echo $total_folders_user; ?></div>
    Thư viện của bạn
</div>

<?php endif; ?>

</div>

<?php if($user_role == 'admin'): ?>
<div class="progress-section">
<h3>Danh sách sinh viên</h3>

<table border="1" width="100%">
<tr>
<th>Họ tên</th>
<th>Email</th>
<th>Thư viện</th>
</tr>

<?php while($row = $students->fetch_assoc()): ?>
<?php
$f = $conn->query("SELECT COUNT(*) as total FROM folders WHERE user_id=".$row['id'])->fetch_assoc()['total'];
?>
<tr>
<td><?php echo $row['fullname']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $f; ?></td>
</tr>
<?php endwhile; ?>

</table>
</div>
<?php endif; ?>

<div class="progress-section">
<h3>Cập nhật thông tin</h3>

<form method="POST">
<input type="text" name="fullname" value="<?php echo $user['fullname']; ?>"><br><br>
<input type="email" name="email" value="<?php echo $user['email']; ?>"><br><br>

<button name="update">Cập nhật</button>
</form>
</div>

<div class="progress-section">
<h3>Đổi mật khẩu</h3>

<form method="POST">
<input type="password" name="old_pass" placeholder="Mật khẩu cũ"><br><br>
<input type="password" name="new_pass" placeholder="Mật khẩu mới"><br><br>

<button name="change_pass">Đổi mật khẩu</button>
</form>
</div>

</div>

</body>
</html>