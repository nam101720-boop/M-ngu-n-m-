<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 1. Chặn nếu chưa đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// 2. Hàm hỗ trợ kiểm tra quyền Admin (Dùng cho các file xử lý Thêm/Xóa/Sửa)
function requireAdmin() {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        // Nếu không phải admin, đá về trang chủ hoặc báo lỗi
        header("Location: index.php?error=no_permission");
        exit();
    }
}

// 3. Hàm kiểm tra nhanh để ẩn/hiện nút trên giao diện
function isAdmin() {
    return (isset($_SESSION['role']) && $_SESSION['role'] === 'admin');
}
?>