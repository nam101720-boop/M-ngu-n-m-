<?php 
include 'auth.php';
include 'config/db.php'; 

$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : 0;
$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0;

// 1. SỬA SQL: Lấy thêm cột ID và IS_STARRED
$sql = "SELECT id, term, definition, example, is_starred FROM cards WHERE lesson_id = $lesson_id";
$result = $conn->query($sql);

$cards = [];
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $cards[] = $row;
    }
} else {
    // DỮ LIỆU DỰ PHÒNG (Để test giao diện nếu database trống)
    $cards = [
        ["id" => 0, "term" => "Colleague", "definition" => "Đồng nghiệp", "example" => "She is a very professional colleague.", "is_starred" => 0],
        ["id" => 0, "term" => "Deadline", "definition" => "Hạn chót", "example" => "I need to finish this report before the deadline.", "is_starred" => 1]
    ];
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>BiBotFlip - Học Tiếng Anh</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --bg: #f8fafc; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        
        .wrapper { width: 450px; height: 320px; perspective: 1000px; }
        .flashcard { width: 100%; height: 100%; position: relative; transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1); transform-style: preserve-3d; cursor: pointer; }
        .flashcard.flipped { transform: rotateY(180deg); }
        
        .face { position: absolute; width: 100%; height: 100%; backface-visibility: hidden; display: flex; flex-direction: column; align-items: center; justify-content: center; border-radius: 30px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); padding: 40px; text-align: center; background: white; border: 1px solid #f1f5f9; box-sizing: border-box; }
        .back { background: var(--primary); color: white; transform: rotateY(180deg); }

        .term { font-size: 42px; font-weight: 800; color: var(--primary); margin: 0; }
        .def { font-size: 30px; font-weight: 700; margin: 0; }
        .ex { font-size: 17px; font-style: italic; margin-top: 20px; opacity: 0.9; line-height: 1.5; }

        .card-tools { position: absolute; top: 25px; right: 25px; display: flex; gap: 15px; z-index: 10; }
        .btn-tool { background: none; border: none; font-size: 22px; cursor: pointer; color: #cbd5e1; transition: 0.2s; }
        .btn-tool:hover { transform: scale(1.2); }
        /* CSS CHO NGÔI SAO VÀNG */
        .active-star { color: #f59e0b !important; }

        .nav-bar { display: flex; align-items: center; gap: 50px; margin-top: 50px; }
        .nav-btn { width: 65px; height: 65px; border-radius: 50%; border: none; background: white; color: var(--primary); font-size: 24px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.05); transition: 0.3s; }
        .nav-btn:hover:not(:disabled) { background: var(--primary); color: white; transform: translateY(-3px); }
        .nav-btn:disabled { visibility: hidden; }

        .btn-exit { position: absolute; top: 30px; left: 30px; text-decoration: none; color: #64748b; font-weight: 700; display: flex; align-items: center; gap: 8px; font-size: 18px; }
    </style>
</head>
<body>

    <a href="view_folder.php?id=<?php echo $f_id; ?>" class="btn-exit">
        <i class="fa-solid fa-xmark"></i> Thoát
    </a>

    <div class="wrapper">
        <div class="flashcard" id="card" onclick="this.classList.toggle('flipped')">
            <div class="face front">
                <div class="card-tools">
                    <button class="btn-tool" onclick="speak(event)"><i class="fa-solid fa-volume-high"></i></button>
                    <button class="btn-tool" id="star-icon" onclick="toggleStar(event)"><i class="fa-solid fa-star"></i></button>
                </div>
                <h1 class="term" id="text-term">...</h1>
            </div>

            <div class="face back">
                <h2 class="def" id="text-def">...</h2>
                <p class="ex" id="text-ex">...</p>
            </div>
        </div>
    </div>

    <div class="nav-bar">
        <button id="btn-prev" class="nav-btn" onclick="prev()"><i class="fa-solid fa-arrow-left"></i></button>
        <div id="counter" style="font-weight: 800; font-size: 22px; color: #1e293b; min-width: 80px; text-align: center;">1 / 1</div>
        <button id="btn-next" class="nav-btn" onclick="next()"><i class="fa-solid fa-arrow-right"></i></button>
    </div>

    <script>
        const cards = <?php echo json_encode($cards); ?>;
        let index = 0;

        function updateUI() {
            if (cards.length === 0) return;

            document.getElementById('card').classList.remove('flipped');

            setTimeout(() => {
                const current = cards[index];
                document.getElementById('text-term').innerText = current.term;
                document.getElementById('text-def').innerText = current.definition;
                document.getElementById('text-ex').innerText = current.example ? `"${current.example}"` : "";
                document.getElementById('counter').innerText = `${index + 1} / ${cards.length}`;

                // SỬA LOGIC HIỂN THỊ SAO: Kiểm tra cột is_starred
                const starIcon = document.getElementById('star-icon');
                if (current.is_starred == 1) {
                    starIcon.classList.add('active-star');
                } else {
                    starIcon.classList.remove('active-star');
                }

                document.getElementById('btn-prev').disabled = (index === 0);
            }, 100);
        }

        // SỬA HÀM TOGGLE STAR: Gửi dữ liệu về Database
        function toggleStar(e) {
            e.stopPropagation();
            const currentCard = cards[index];
            const starIcon = document.getElementById('star-icon');

            // 1. Gửi Ajax về file update_star.php
            fetch('update_star.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'card_id=' + currentCard.id
            })
            .then(response => {
                // 2. Cập nhật giao diện và bộ nhớ tạm (cards array)
                const isActive = starIcon.classList.toggle('active-star');
                cards[index].is_starred = isActive ? 1 : 0;
            });
        }

        function next() {
            if (index < cards.length - 1) {
                index++;
                updateUI();
            } else {
                alert("Bạn đã học xong bài này!");
            }
        }

        function prev() {
            if (index > 0) {
                index--;
                updateUI();
            }
        }

        function speak(e) {
            e.stopPropagation();
            const msg = new SpeechSynthesisUtterance(cards[index].term);
            msg.lang = 'en-US';
            window.speechSynthesis.speak(msg);
        }

        updateUI();
    </script>
</body>
</html>