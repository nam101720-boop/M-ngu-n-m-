<?php

include 'config/db.php';
session_start();

$error = "";

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password' LIMIT 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] == 'admin') {
            $_SESSION['display_name'] = "Quản Trị Viên";
            $_SESSION['initials'] = "AD";
        } else {
            $random_name = "SV" . rand(100000, 999999);
            $_SESSION['display_name'] = $random_name;
            $_SESSION['initials'] = "SV";
        }

        header("Location: index.php");
        exit();
    } else {
        $error = "Sai tài khoản hoặc mật khẩu!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --bg: #f8fafc; }
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background: var(--bg); height: 100vh; margin: 0;
            display: flex; align-items: center; justify-content: center;
        }
        .login-card {
            background: white; padding: 40px; border-radius: 24px;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
            width: 100%; max-width: 400px; border: 1px solid #f1f5f9;
        }
        .logo { 
            text-align: center; color: var(--primary); 
            font-size: 30px; font-weight: 800; margin-bottom: 30px; 
        }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 700; margin-bottom: 8px; color: #1e293b; }
        .form-group input {
            width: 100%; padding: 12px 16px; border: 2px solid #f1f5f9;
            border-radius: 12px; outline: none; box-sizing: border-box;
        }
        .form-group input:focus { border-color: var(--primary); }
        .btn-login {
            width: 100%; background: var(--primary); color: white;
            border: none; padding: 14px; border-radius: 12px;
            font-weight: 800; cursor: pointer; font-size: 16px;
        }
        .error-msg {
            background: #fef2f2; color: #ef4444; padding: 12px;
            border-radius: 10px; margin-bottom: 20px; font-size: 14px; text-align: center;
        }
        .link {
            display: block;
            text-align: center;
            margin-top: 10px;
            font-weight: 600;
            text-decoration: none;
        }
        .register { color: #6366f1; }
        .forgot { color: #ef4444; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="logo"><i class="fa-solid fa-bolt"></i> BiBotFlip</div>
    
    <?php if($error): ?>
        <div class="error-msg"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Tên đăng nhập</label>
            <input type="text" name="username" required>
        </div>
        <div class="form-group">
            <label>Mật khẩu</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit" name="login" class="btn-login">Đăng nhập ngay</button>
    </form>

    <!-- THÊM Ở ĐÂY -->
    <a href="register.php" class="link register">Đăng ký tài khoản</a>
    <a href="forgot.php" class="link forgot">Quên mật khẩu?</a>

</div>

</body>
</html>