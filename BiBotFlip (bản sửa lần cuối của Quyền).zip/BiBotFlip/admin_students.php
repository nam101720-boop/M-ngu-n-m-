<?php 
session_start();
include 'auth.php';
include 'config/db.php'; 

// 1. Kiểm tra quyền Admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// 2. Xử lý Xóa sinh viên
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $conn->query("DELETE FROM users WHERE id = $id AND role = 'student'");
    header("Location: admin_students.php");
    exit();
}

// 3. Truy vấn danh sách sinh viên
$sql = "SELECT * FROM users WHERE role = 'student'";
if (!empty($search)) {
    $sql .= " AND (fullname LIKE '%$search%' OR email LIKE '%$search%')";
}
$sql .= " ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý sinh viên - BiBotFlip</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* CSS GỐC TỪ INDEX.PHP */
        :root {
            --primary: #6366f1;
            --primary-hover: #4f46e5;
            --bg: #f8fafc;
            --sidebar-bg: #ffffff;
            --card-bg: #ffffff;
            --text-title: #1e293b;
            --text-body: #64748b;
            --border: #f1f5f9;
            --danger: #ef4444;
            --success: #10b981;
        }

        * { box-sizing: border-box; transition: all 0.2s ease-in-out; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: var(--bg); margin: 0; display: flex; min-height: 100vh; }

        /* SIDEBAR GỐC */
        .sidebar { width: 280px; background: var(--sidebar-bg); border-right: 1px solid var(--border); display: flex; flex-direction: column; position: fixed; height: 100vh; padding: 25px 15px; z-index: 100; }
        .logo { font-size: 26px; font-weight: 800; color: var(--primary); padding: 0 15px 30px 15px; display: flex; align-items: center; gap: 10px; }
        .sidebar-nav { flex: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .menu-label { font-size: 11px; text-transform: uppercase; color: #94a3b8; font-weight: 700; margin: 20px 0 10px 15px; letter-spacing: 1px; }
        .menu-item { display: flex; align-items: center; padding: 12px 15px; color: var(--text-body); text-decoration: none; border-radius: 12px; margin-bottom: 4px; font-weight: 600; }
        .menu-item i { margin-right: 12px; width: 20px; font-size: 18px; text-align: center; }
        .menu-item:hover, .menu-item.active { background: #f1f5f9; color: var(--primary); }
        .sidebar-footer { margin-top: auto; padding-top: 20px; border-top: 1px solid var(--border); }
        .avatar { width: 40px; height: 40px; background: var(--primary); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; }

        /* MAIN CONTENT */
        .main-content { margin-left: 280px; flex: 1; padding: 40px; }
        .header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 35px; }
        .header-section h1 { font-size: 28px; margin: 0; color: var(--text-title); font-weight: 800; }

        /* SEARCH & BUTTON */
        .action-bar { display: flex; gap: 15px; margin-bottom: 25px; }
        .search-box { flex: 1; background: var(--card-bg); display: flex; padding: 5px; border-radius: 14px; border: 1px solid var(--border); }
        .search-box input { flex: 1; border: none; padding: 10px 15px; outline: none; background: transparent; font-size: 15px; }
        .btn-search { background: var(--primary); color: white; border: none; padding: 10px 20px; border-radius: 10px; cursor: pointer; font-weight: 600; }
        .btn-add { background: var(--success); color: white; border: none; padding: 0 25px; border-radius: 14px; cursor: pointer; font-weight: 700; display: flex; align-items: center; gap: 8px; text-decoration: none;}

        /* TABLE STYLE */
        .table-container { background: var(--card-bg); border-radius: 20px; border: 1px solid var(--border); overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8fafc; padding: 15px 20px; text-align: left; color: #64748b; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; }
        td { padding: 16px 20px; border-top: 1px solid var(--border); color: var(--text-title); font-size: 15px; }
        tr:hover { background: #fcfdfe; }

        .btn-edit { color: var(--primary); margin-right: 12px; font-size: 18px; cursor: pointer; }
        .btn-delete { color: var(--danger); font-size: 18px; cursor: pointer; }

        /* MODAL CƠ BẢN */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
        .modal-content { background: white; margin: 10% auto; padding: 30px; border-radius: 20px; width: 400px; position: relative; }
        .modal-content h2 { margin-top: 0; color: var(--text-title); }
        .modal-content input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid var(--border); border-radius: 10px; }
        .btn-save { width: 100%; padding: 12px; background: var(--primary); color: white; border: none; border-radius: 10px; font-weight: 700; cursor: pointer; margin-top: 10px; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo"><i class="fa-solid fa-bolt"></i> <span>BiBotFlip</span></div>
        <div class="sidebar-nav">
            <a href="index.php" class="menu-item"><i class="fa-solid fa-house"></i> <span>Trang chủ</span></a>
            <div class="menu-label">Quản trị hệ thống</div>
            <a href="admin_students.php" class="menu-item active"><i class="fa-solid fa-user-graduate"></i> <span>Quản lý sinh viên</span></a>
            <a href="admin_questions.php" class="menu-item"><i class="fa-solid fa-file-circle-question"></i> <span>Kho câu hỏi</span></a>
            
            <div class="sidebar-footer">
                <div class="user-profile">
                    <div class="avatar"><?php echo $_SESSION['initials'] ?? 'AD'; ?></div>
                    <div>
                        <span style="font-weight: 700; font-size: 14px; display:block;">Admin</span>
                        <span style="font-size: 11px; color: var(--text-body);">Quản trị viên</span>
                    </div>
                </div>
                <a href="logout.php" class="menu-item" style="color: var(--danger);"><i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Đăng xuất</span></a>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="header-flex">
            <div class="header-section">
                <h1>Quản lý sinh viên</h1>
                <p>Danh sách học viên đang hoạt động trên hệ thống</p>
            </div>
            <button class="btn-add" onclick="openModal('addModal')"><i class="fa-solid fa-plus"></i> Thêm sinh viên</button>
        </div>

        <div class="action-bar">
            <div class="search-box">
                <form action="" method="GET" style="display:flex; width:100%">
                    <input type="text" name="search" placeholder="Tìm sinh viên theo tên hoặc email..." value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit" class="btn-search">Tìm kiếm</button>
                </form>
            </div>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Họ và Tên</th>
                        <th>Email</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>#<?php echo $row['id']; ?></td>
                                <td style="font-weight: 700;"><?php echo htmlspecialchars($row['fullname']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td>
                                    <a class="btn-edit" onclick="openEditModal(<?php echo $row['id']; ?>, '<?php echo $row['fullname']; ?>', '<?php echo $row['email']; ?>')">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <a href="?delete_id=<?php echo $row['id']; ?>" class="btn-delete" onclick="return confirm('Xóa sinh viên này?')">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4" style="text-align:center; padding: 40px; color: var(--text-body);">Không tìm thấy dữ liệu.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="addModal" class="modal">
        <div class="modal-content">
            <h2>Thêm sinh viên</h2>
            <form action="add_student_process.php" method="POST">
                <input type="text" name="fullname" placeholder="Họ và tên" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Mật khẩu mặc định" required>
                <button type="submit" class="btn-save">Lưu sinh viên</button>
                <button type="button" onclick="closeModal('addModal')" style="background:none; border:none; color:var(--text-body); cursor:pointer; width:100%; margin-top:10px;">Hủy bỏ</button>
            </form>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <h2>Chỉnh sửa thông tin</h2>
            <form action="edit_student_process.php" method="POST">
                <input type="hidden" name="id" id="edit_id">
                <input type="text" name="fullname" id="edit_fullname" required>
                <input type="email" name="email" id="edit_email" required>
                <button type="submit" class="btn-save">Cập nhật</button>
                <button type="button" onclick="closeModal('editModal')" style="background:none; border:none; color:var(--text-body); cursor:pointer; width:100%; margin-top:10px;">Hủy bỏ</button>
            </form>
        </div>
    </div>

    <script>
        function openModal(id) { document.getElementById(id).style.display = "block"; }
        function closeModal(id) { document.getElementById(id).style.display = "none"; }
        
        function openEditModal(id, name, email) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_fullname').value = name;
            document.getElementById('edit_email').value = email;
            openModal('editModal');
        }

        // Đóng modal khi click ra ngoài
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = "none";
            }
        }
    </script>
</body>
</html>