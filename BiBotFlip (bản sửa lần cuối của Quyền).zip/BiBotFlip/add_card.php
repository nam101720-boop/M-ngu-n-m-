<?php
include 'auth.php';
include 'config/db.php';

$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0;
$l_id = isset($_GET['l_id']) ? intval($_GET['l_id']) : 0;

if (isset($_POST['submit_card'])) {
    $folder_id = intval($_POST['folder_id']);
    $lesson_id = intval($_POST['lesson_id']);
    $term = $conn->real_escape_string($_POST['term']);
    $definition = $conn->real_escape_string($_POST['definition']);
    $example = $conn->real_escape_string($_POST['example']);
    $image_url = $conn->real_escape_string($_POST['image_url']);

    // INSERT khớp với các cột bạn cung cấp (id tự tăng, mastery_level mặc định 0, created_at tự động)
    $sql = "INSERT INTO cards (folder_id, lesson_id, term, definition, example, image_url, mastery_level) 
            VALUES ($folder_id, $lesson_id, '$term', '$definition', '$example', '$image_url', 0)";

    if ($conn->query($sql) === TRUE) {
        header("Location: view_folder.php?id=" . $folder_id);
        exit();
    } else {
        echo "Lỗi: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm thẻ mới</title>
    <style>
        body { font-family: sans-serif; background: #f8fafc; display: flex; justify-content: center; padding: 40px 0; }
        .form-box { background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); width: 450px; }
        .input-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #475569; }
        input, textarea { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 10px; box-sizing: border-box; }
        button { width: 100%; padding: 15px; background: #10b981; color: white; border: none; border-radius: 12px; cursor: pointer; font-weight: bold; font-size: 16px; }
    </style>
</head>
<body>
    <div class="form-box">
        <h2 style="color: #10b981;">Thêm thẻ ghi nhớ mới</h2>
        <form method="POST">
            <input type="hidden" name="folder_id" value="<?php echo $f_id; ?>">
            <input type="hidden" name="lesson_id" value="<?php echo $l_id; ?>">

            <div class="input-group">
                <label>Từ vựng (Term):</label>
                <input type="text" name="term" required autofocus>
            </div>

            <div class="input-group">
                <label>Định nghĩa (Definition):</label>
                <input type="text" name="definition" required>
            </div>

            <div class="input-group">
                <label>Ví dụ (Example):</label>
                <textarea name="example"></textarea>
            </div>

            <div class="input-group">
                <label>Link ảnh (Image URL):</label>
                <input type="text" name="image_url" placeholder="https://example.com/image.jpg">
            </div>

            <button type="submit" name="submit_card">Lưu thẻ này</button>
            <a href="view_folder.php?id=<?php echo $f_id; ?>" style="display:block; text-align:center; margin-top:15px; color:#64748b; text-decoration:none;">Quay lại</a>
        </form>
    </div>
</body>
</html>