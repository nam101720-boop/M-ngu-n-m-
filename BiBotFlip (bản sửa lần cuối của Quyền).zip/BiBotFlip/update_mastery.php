<?php
include 'auth.php';
include 'config/db.php';
if (isset($_POST['card_id'])) {
    $id = intval($_POST['card_id']);
    $status = $_POST['status'];
    if ($status == 'wrong') {
        $conn->query("UPDATE cards SET mastery_level = 0 WHERE id = $id");
    } else {
        $conn->query("UPDATE cards SET mastery_level = mastery_level + 1 WHERE id = $id AND mastery_level < 5");
    }
}
?>