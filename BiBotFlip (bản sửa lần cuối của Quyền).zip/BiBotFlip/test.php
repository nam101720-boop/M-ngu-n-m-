<?php 
include 'auth.php';
include 'config/db.php'; 

$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : 0;
$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0;

$sql = "SELECT term, definition FROM cards WHERE lesson_id = $lesson_id";
$result = $conn->query($sql);
$cards = $result->fetch_all(MYSQLI_ASSOC);

shuffle($cards);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kiểm tra - BiBotFlip</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --danger: #ef4444; --primary: #6366f1; --bg: #f8fafc; --success: #22c55e; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
        .test-container { width: 550px; background: white; padding: 40px; border-radius: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.05); }
        .question-box { margin-bottom: 30px; text-align: center; }
        .question-text { font-size: 28px; font-weight: 800; color: #1e293b; margin-bottom: 10px; }
        .options-grid { display: grid; grid-template-columns: 1fr; gap: 12px; }
        .option-btn { padding: 18px; border: 2px solid #f1f5f9; border-radius: 16px; background: white; cursor: pointer; text-align: left; font-size: 16px; font-weight: 600; transition: 0.2s; color: #475569; outline: none; }
        .option-btn:hover:not(:disabled) { background: #f8fafc; border-color: var(--primary); color: var(--primary); }
        .progress-header { display: flex; justify-content: space-between; margin-bottom: 20px; font-weight: 700; color: #94a3b8; }
        
        /* Màu khi chọn đúng/sai */
        .option-btn.correct { background: #dcfce7 !important; border-color: var(--success) !important; color: #15803d !important; }
        .option-btn.wrong { background: #fee2e2 !important; border-color: var(--danger) !important; color: #b91c1c !important; }
        .option-btn:disabled { cursor: default; opacity: 0.8; }

        .result-screen { text-align: center; display: none; }
        .score-circle { width: 120px; height: 120px; border-radius: 50%; background: var(--primary); color: white; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: 800; margin: 0 auto 20px; }
        .btn-exit { position: absolute; top: 30px; left: 30px; text-decoration: none; color: #64748b; font-weight: 700; }
        .btn-finish { display: inline-block; padding: 15px 40px; background: var(--primary); color: white; border-radius: 15px; text-decoration: none; font-weight: 700; margin-top: 20px; }
    </style>
</head>
<body>

    <a href="view_folder.php?id=<?php echo $f_id; ?>" class="btn-exit"><i class="fa-solid fa-xmark"></i> Thoát kiểm tra</a>

    <div class="test-container" id="test-content">
        <div class="progress-header">
            <span id="current-pos">Câu 1</span>
            <span id="score-temp">Đúng: 0</span>
        </div>
        <div class="question-box">
            <p style="color: #64748b; font-size: 14px; text-transform: uppercase;">Chọn nghĩa đúng của từ:</p>
            <div class="question-text" id="q-term">Đang tải...</div>
        </div>
        <div class="options-grid" id="options"></div>
    </div>

    <div class="test-container result-screen" id="result-screen">
        <div class="score-circle" id="final-score">0/0</div>
        <h2 id="result-msg">Hoàn thành!</h2>
        <p id="result-subtext">Cố gắng luyện tập thêm nhé.</p>
        <a href="view_folder.php?id=<?php echo $f_id; ?>" class="btn-finish">Quay lại danh sách</a>
    </div>

    <script>
        const allData = <?php echo json_encode($cards); ?>;
        let currentIndex = 0;
        let correctCount = 0;

        function renderQuestion() {
            if (currentIndex >= allData.length) {
                showResult();
                return;
            }

            const current = allData[currentIndex];
            document.getElementById('q-term').innerText = current.term.split('/')[0].trim();
            document.getElementById('current-pos').innerText = `Câu ${currentIndex + 1} / ${allData.length}`;
            
            // Tạo đáp án
            let choices = [current.definition];
            let otherDefs = allData
                .filter(item => item.definition !== current.definition)
                .map(item => item.definition);
            
            otherDefs.sort(() => Math.random() - 0.5);
            choices = choices.concat(otherDefs.slice(0, 3));
            choices.sort(() => Math.random() - 0.5);

            const optionsGrid = document.getElementById('options');
            optionsGrid.innerHTML = '';
            
            choices.forEach(choice => {
                const btn = document.createElement('button');
                btn.className = 'option-btn';
                btn.innerText = choice;
                // Gán sự kiện click đúng cách
                btn.onclick = function() { handleAnswer(this, choice === current.definition); };
                optionsGrid.appendChild(btn);
            });
        }

        function handleAnswer(selectedBtn, isCorrect) {
            const allButtons = document.querySelectorAll('.option-btn');
            allButtons.forEach(btn => btn.disabled = true); // Khóa nút

            if (isCorrect) {
                selectedBtn.classList.add('correct');
                correctCount++;
            } else {
                selectedBtn.classList.add('wrong');
                // Hiện đáp án đúng cho người dùng thấy
                allButtons.forEach(btn => {
                    if (btn.innerText === allData[currentIndex].definition) {
                        btn.classList.add('correct');
                    }
                });
            }

            document.getElementById('score-temp').innerText = `Đúng: ${correctCount}`;

            setTimeout(() => {
                currentIndex++;
                renderQuestion();
            }, 1200);
        }

        function showResult() {
            document.getElementById('test-content').style.display = 'none';
            document.getElementById('result-screen').style.display = 'block';
            document.getElementById('final-score').innerText = `${correctCount}/${allData.length}`;
            // Logic đánh giá giữ nguyên...
        }

        renderQuestion();
    </script>
</body>
</html>