<?php 
include 'auth.php';
include 'config/db.php'; 
$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : 0;
$f_id = isset($_GET['f_id']) ? intval($_GET['f_id']) : 0;

$cards = $conn->query("SELECT * FROM cards WHERE lesson_id = $lesson_id")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Luyện Nghe & Phản Xạ - BiBotFlip</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #f59e0b; --bg: #fffcf2; } /* Màu vàng cam cho năng lượng phản xạ */
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        
        .wrapper { width: 450px; height: 320px; perspective: 1000px; }
        .flashcard { width: 100%; height: 100%; position: relative; transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1); transform-style: preserve-3d; cursor: pointer; }
        .flashcard.flipped { transform: rotateY(180deg); }
        .face { position: absolute; width: 100%; height: 100%; backface-visibility: hidden; display: flex; flex-direction: column; align-items: center; justify-content: center; border-radius: 30px; box-shadow: 0 15px 35px rgba(245, 158, 11, 0.2); padding: 40px; text-align: center; background: white; border: 2px solid #fef3c7; box-sizing: border-box; }
        .back { background: var(--primary); color: white; transform: rotateY(180deg); }

        .listen-icon { font-size: 80px; color: var(--primary); margin-bottom: 20px; animation: pulse 2s infinite; }
        @keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.1); } 100% { transform: scale(1); } }

        .term-hidden { filter: blur(8px); transition: 0.3s; font-size: 30px; font-weight: 800; }
        .term-hidden:hover { filter: blur(0); } /* Rê chuột vào mới thấy chữ nếu nghe không ra */

        .nav-btn { width: 65px; height: 65px; border-radius: 50%; border: none; background: white; color: var(--primary); font-size: 24px; cursor: pointer; box-shadow: 0 8px 20px rgba(0,0,0,0.05); transition: 0.3s; }
        .nav-btn:hover:not(:disabled) { background: var(--primary); color: white; }
        
        .btn-exit { position: absolute; top: 30px; left: 30px; text-decoration: none; color: #78350f; font-weight: 700; font-size: 18px; }
    </style>
</head>
<body>

    <a href="view_folder.php?id=<?php echo $f_id; ?>" class="btn-exit">
        <i class="fa-solid fa-chevron-left"></i> Thoát luyện nghe
    </a>

    <div class="wrapper" onclick="document.getElementById('card').classList.toggle('flipped')">
        <div class="flashcard" id="card">
            <div class="face front">
                <div class="listen-icon"><i class="fa-solid fa-circle-play"></i></div>
                <p style="color: #92400e; font-weight: 600;">Nghe và đoán nghĩa...</p>
                <div id="f-term" class="term-hidden">English Word</div>
            </div>
            <div class="face back">
                <h2 id="b-def" style="font-size: 32px; margin: 0;">Nghĩa</h2>
                <p id="b-ex" style="font-size: 18px; margin-top: 20px; font-style: italic; opacity: 0.9;">Ví dụ</p>
                <button onclick="speak(); event.stopPropagation();" style="margin-top:20px; background:white; border:none; padding:10px 20px; border-radius:20px; color:var(--primary); font-weight:800; cursor:pointer;">
                    <i class="fa-solid fa-volume-high"></i> Nghe lại
                </button>
            </div>
        </div>
    </div>

    <div style="display: flex; align-items: center; gap: 50px; margin-top: 50px;">
        <button class="nav-btn" onclick="prev()"><i class="fa-solid fa-arrow-left"></i></button>
        <div id="counter" style="font-weight: 800; font-size: 22px; color: #78350f;">1 / 1</div>
        <button class="nav-btn" onclick="next()"><i class="fa-solid fa-arrow-right"></i></button>
    </div>

    <script>
        const cards = <?php echo json_encode($cards); ?>;
        let index = 0;

        function speak() {
            const msg = new SpeechSynthesisUtterance(cards[index].term.split('/')[0].trim());
            msg.lang = 'en-US';
            msg.rate = 0.9; // Đọc hơi chậm một chút để dễ nghe
            window.speechSynthesis.speak(msg);
        }

        function update() {
            if(cards.length === 0) return;
            document.getElementById('card').classList.remove('flipped');
            
            setTimeout(() => {
                document.getElementById('f-term').innerText = cards[index].term;
                document.getElementById('b-def').innerText = cards[index].definition;
                document.getElementById('b-ex').innerText = cards[index].example || "";
                document.getElementById('counter').innerText = `${index + 1} / ${cards.length}`;
                
                // TỰ ĐỘNG PHÁT ÂM THANH KHI SANG THẺ MỚI
                speak();
            }, 200);
        }

        function next() { if(index < cards.length - 1) { index++; update(); } }
        function prev() { if(index > 0) { index--; update(); } }

        // Chạy lần đầu
        update();
    </script>
</body>
</html>