<?php
session_start();
include 'auth.php';
include 'config/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin' || !isset($_GET['id'])) {
    header("Location: admin_students.php");
    exit();
}

$id = $_GET['id'];
$sql = "DELETE FROM users WHERE id = $id AND role = 'student'";

if ($conn->query($sql) === TRUE) {
    header("Location: admin_students.php?msg=deleted");
} else {
    echo "Lỗi xóa: " . $conn->error;
}
?>