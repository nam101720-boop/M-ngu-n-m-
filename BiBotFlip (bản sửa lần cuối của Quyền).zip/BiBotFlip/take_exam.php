<?php 
include 'auth.php';
include 'config/db.php'; 

$exam_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 1. Lấy thông tin đề thi
$exam_query = $conn->query("SELECT * FROM exams WHERE id = $exam_id");
$exam = $exam_query->fetch_assoc();

if (!$exam) {
    die("Không tìm thấy đề thi!");
}

// 2. Lấy danh sách câu hỏi (Xáo trộn ngẫu nhiên để chống gian lận)
$questions_query = $conn->query("SELECT * FROM exam_questions WHERE exam_id = $exam_id ORDER BY RAND()");
$questions = [];
while($row = $questions_query->fetch_assoc()) {
    $questions[] = $row;
}

if (empty($questions)) {
    die("Đề thi này chưa có câu hỏi nào. Vui lòng quay lại sau!");
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?php echo $exam['title']; ?> - BiBotFlip Exam</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #6366f1; --bg: #f8fafc; --text: #1e293b; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding: 20px; }
        
        .exam-container { max-width: 800px; margin: 40px auto; background: white; padding: 40px; border-radius: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.05); }
        
        /* Header thi */
        .exam-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; border-bottom: 2px solid #f1f5f9; padding-bottom: 20px; }
        .timer { background: #fee2e2; color: #ef4444; padding: 10px 20px; border-radius: 12px; font-weight: 800; font-size: 18px; display: flex; align-items: center; gap: 8px; }
        
        /* Câu hỏi */
        .question-box { display: none; }
        .question-box.active { display: block; animation: fadeIn 0.5s; }
        .q-text { font-size: 22px; font-weight: 700; color: var(--text); margin-bottom: 25px; line-height: 1.4; }
        
        /* Đáp án */
        .options { display: grid; grid-template-columns: 1fr; gap: 12px; }
        .option-item { 
            padding: 18px 25px; border: 2px solid #f1f5f9; border-radius: 15px; 
            cursor: pointer; transition: 0.3s; display: flex; align-items: center; gap: 15px; font-weight: 600;
        }
        .option-item:hover { border-color: var(--primary); background: #f5f3ff; }
        .option-item.selected { background: var(--primary); color: white; border-color: var(--primary); }
        .option-label { width: 30px; height: 30px; background: #eee; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; color: var(--text); }
        .selected .option-label { background: rgba(255,255,255,0.2); color: white; }

        /* Điều hướng */
        .exam-footer { display: flex; justify-content: space-between; margin-top: 40px; }
        .btn-nav { padding: 12px 25px; border-radius: 12px; border: none; font-weight: 700; cursor: pointer; transition: 0.3s; }
        .btn-prev { background: #e2e8f0; color: #64748b; }
        .btn-next { background: var(--primary); color: white; }
        .btn-submit { background: #10b981; color: white; display: none; }

        /* Kết quả */
        #result-screen { display: none; text-align: center; padding: 40px; }
        .score-circle { width: 150px; height: 150px; border-radius: 50%; background: var(--primary); color: white; display: flex; flex-direction: column; align-items: center; justify-content: center; margin: 0 auto 20px; }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body>

<div class="exam-container" id="exam-ui">
    <div class="exam-header">
        <div>
            <h2 style="margin:0;"><?php echo $exam['title']; ?></h2>
            <span id="progress-text" style="color:#94a3b8; font-weight:600;">Câu hỏi 1 / <?php echo count($questions); ?></span>
        </div>
        <div class="timer"><i class="fa-solid fa-clock"></i> <span id="time-left">00:00</span></div>
    </div>

    <form id="quiz-form">
        <?php foreach($questions as $index => $q): ?>
        <div class="question-box <?php echo $index === 0 ? 'active' : ''; ?>" data-index="<?php echo $index; ?>">
            <p class="q-text"><?php echo ($index + 1) . ". " . htmlspecialchars($q['question']); ?></p>
            <div class="options">
                <label class="option-item">
                    <input type="radio" name="q<?php echo $q['id']; ?>" value="A" style="display:none;" data-correct="<?php echo $q['correct_option']; ?>">
                    <span class="option-label">A</span> <?php echo htmlspecialchars($q['option_a']); ?>
                </label>
                <label class="option-item">
                    <input type="radio" name="q<?php echo $q['id']; ?>" value="B" style="display:none;" data-correct="<?php echo $q['correct_option']; ?>">
                    <span class="option-label">B</span> <?php echo htmlspecialchars($q['option_b']); ?>
                </label>
                <label class="option-item">
                    <input type="radio" name="q<?php echo $q['id']; ?>" value="C" style="display:none;" data-correct="<?php echo $q['correct_option']; ?>">
                    <span class="option-label">C</span> <?php echo htmlspecialchars($q['option_c']); ?>
                </label>
                <label class="option-item">
                    <input type="radio" name="q<?php echo $q['id']; ?>" value="D" style="display:none;" data-correct="<?php echo $q['correct_option']; ?>">
                    <span class="option-label">D</span> <?php echo htmlspecialchars($q['option_d']); ?>
                </label>
            </div>
        </div>
        <?php endforeach; ?>

        <div class="exam-footer">
            <button type="button" class="btn-nav btn-prev" onclick="changeQuestion(-1)" id="prev-btn" disabled>Câu trước</button>
            <button type="button" class="btn-nav btn-next" onclick="changeQuestion(1)" id="next-btn">Câu tiếp theo</button>
            <button type="button" class="btn-nav btn-submit" onclick="submitExam()" id="submit-btn">Nộp bài thi</button>
        </div>
    </form>
</div>

<div class="exam-container" id="result-screen">
    <div class="score-circle">
        <span style="font-size: 40px; font-weight: 800;" id="final-score">0</span>
        <span style="font-size: 14px;">Điểm số</span>
    </div>
    <h2 id="result-msg">Hoàn thành bài thi!</h2>
    <p style="color: #64748b;" id="correct-count">Bạn trả lời đúng 0 / 0 câu.</p>
    <a href="online_exams.php" class="btn-nav btn-next" style="display:inline-block; margin-top:20px; text-decoration:none;">Quay lại danh sách đề</a>
</div>

<script>
    let currentQ = 0;
    const totalQ = <?php echo count($questions); ?>;
    let timeLeft = <?php echo $exam['duration']; ?> * 60;
    
    // Xử lý đếm ngược
    const timerDisplay = document.getElementById('time-left');
    const countdown = setInterval(() => {
        let mins = Math.floor(timeLeft / 60);
        let secs = timeLeft % 60;
        timerDisplay.innerText = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        if (timeLeft <= 0) {
            clearInterval(countdown);
            submitExam(); // Tự nộp bài
        }
        timeLeft--;
    }, 1000);

    // Xử lý chọn đáp án (đổi màu label)
    document.querySelectorAll('.option-item').forEach(item => {
        item.addEventListener('click', function() {
            const parent = this.parentElement;
            parent.querySelectorAll('.option-item').forEach(i => i.classList.remove('selected'));
            this.classList.add('selected');
        });
    });

    function changeQuestion(step) {
        const boxes = document.querySelectorAll('.question-box');
        boxes[currentQ].classList.remove('active');
        currentQ += step;
        boxes[currentQ].classList.add('active');

        // Cập nhật giao diện
        document.getElementById('progress-text').innerText = `Câu hỏi ${currentQ + 1} / ${totalQ}`;
        document.getElementById('prev-btn').disabled = (currentQ === 0);
        
        if (currentQ === totalQ - 1) {
            document.getElementById('next-btn').style.display = 'none';
            document.getElementById('submit-btn').style.display = 'block';
        } else {
            document.getElementById('next-btn').style.display = 'block';
            document.getElementById('submit-btn').style.display = 'none';
        }
    }

    function submitExam() {
        clearInterval(countdown);
        let correct = 0;
        const form = document.getElementById('quiz-form');
        const inputs = form.querySelectorAll('input[type="radio"]:checked');

        inputs.forEach(input => {
            if (input.value === input.getAttribute('data-correct')) {
                correct++;
            }
        });

        // Tính điểm hệ 10
        const score = ((correct / totalQ) * 10).toFixed(1);

        // Hiển thị kết quả
        document.getElementById('exam-ui').style.display = 'none';
        document.getElementById('result-screen').style.display = 'block';
        document.getElementById('final-score').innerText = score;
        document.getElementById('correct-count').innerText = `Bạn trả lời đúng ${correct} / ${totalQ} câu.`;
        
        if (score >= 8) document.getElementById('result-msg').innerText = "Xuất sắc! 🎉";
        else if (score >= 5) document.getElementById('result-msg').innerText = "Làm tốt lắm! 👍";
        else document.getElementById('result-msg').innerText = "Cần cố gắng thêm nhé! 💪";
    }
</script>

</body>
</html>