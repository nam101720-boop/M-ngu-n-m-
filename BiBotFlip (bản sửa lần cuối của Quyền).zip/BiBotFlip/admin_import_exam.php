<?php 
include 'auth.php';
include 'config/db.php'; 

if (isset($_POST['import_submit'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $desc = $conn->real_escape_string($_POST['description']);
    $duration = intval($_POST['duration']);

    // 1. Tạo đề thi mới
    $sql_exam = "INSERT INTO exams (title, description, duration) VALUES ('$title', '$desc', '$duration')";
    
    if ($conn->query($sql_exam)) {
        $exam_id = $conn->insert_id;
        $file = $_FILES['exam_file']['tmp_name'];

        // 2. Đọc file CSV
        if (($handle = fopen($file, "r")) !== FALSE) {
            // Bỏ qua dòng tiêu đề đầu tiên nếu có
            fgetcsv($handle, 1000, ","); 

            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                // $data[0]: Câu hỏi, $data[1]: A, $data[2]: B, $data[3]: C, $data[4]: D, $data[5]: Đáp án đúng
                $q = $conn->real_escape_string($data[0]);
                $a = $conn->real_escape_string($data[1]);
                $b = $conn->real_escape_string($data[2]);
                $c = $conn->real_escape_string($data[3]);
                $d = $conn->real_escape_string($data[4]);
                $correct = strtoupper(trim($data[5]));

                $sql_q = "INSERT INTO exam_questions (exam_id, question, option_a, option_b, option_c, option_d, correct_option) 
                          VALUES ($exam_id, '$q', '$a', '$b', '$c', '$d', '$correct')";
                $conn->query($sql_q);
            }
            fclose($handle);
            echo "<script>alert('Đã nhập đề thi thành công!'); window.location='online_exams.php';</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Import Đề thi - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f8fafc; padding: 50px; }
        .import-box { max-width: 600px; margin: auto; background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 15px rgba(0,0,0,0.05); }
        input, textarea { width: 100%; padding: 12px; margin: 10px 0 20px 0; border: 1px solid #e2e8f0; border-radius: 10px; display: block; box-sizing: border-box;}
        .btn-import { background: #10b981; color: white; border: none; padding: 15px; border-radius: 10px; font-weight: 700; cursor: pointer; width: 100%; }
        .note { font-size: 13px; color: #64748b; background: #f1f5f9; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="import-box">
    <h2><i class="fa-solid fa-file-import"></i> Nhập đề thi từ file CSV</h2>
    
    <div class="note">
        <b>Định dạng file .csv:</b><br>
        Câu hỏi, Đáp án A, Đáp án B, Đáp án C, Đáp án D, Đáp án đúng (A/B/C/D)
    </div>

    <form method="POST" enctype="multipart/form-data">
        <label>Tên đề thi:</label>
        <input type="text" name="title" required>

        <label>Mô tả:</label>
        <textarea name="description" rows="2"></textarea>

        <label>Thời gian (phút):</label>
        <input type="number" name="duration" value="30">

        <label>Chọn file CSV:</label>
        <input type="file" name="exam_file" accept=".csv" required>

        <button type="submit" name="import_submit" class="btn-import">Tải lên và Tạo đề thi</button>
    </form>
    <br>
    <a href="online_exams.php" style="color: #64748b; text-decoration: none;">Hủy bỏ</a>
</div>

</body>
</html>